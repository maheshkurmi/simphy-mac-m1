

/**
 * A image object for canvas2d context
 * 
 * @author Mahesh kurmi
 */
public class Image {

	/**Name of the resource attachd to this imagei*/
	public String src;
	
	 
    /** the width of the image in pixels (read only)*/
    public int width;
    
    /** the height of the image in pixels (read only)*/
    public int height;
    
	/**
	 * Create new Empty Image ofzeero width and zero height
	 * @see {@link #src} property of image to load image into it
	 */
	public Image(){
	}
	
	
	/**
	 * Create new Image from resource
	 * @param src Name of resource already loaded
	 */
	public Image(String src){
		
	}
	
	
	/**
	 * Changes the image content
	 * @param src Name of resource already loaded
	 */
	public void setSrc(String src){
		
	}
	
	/**
	 * Returns name of resource associated with image
	 * @return
	 */
	public String getSrc(){
		return null;
	}
	
    /**
     * Returns the width in pixels of the image
     * @return the width in pixels of the image
     */
    public int getWidth(){
    	return 0;
    }
    
    /**
     * Returns the height in pixels of the image
     * @return the height in pixels of the image
     */
    public int getHeight(){
    	return 0;
    }
    
	/**
	 * Creates and returns copy of this image, Note that only refernce of texturedata is
	 * copied not the textureData itself
	 * @return {Image} copy of image
	 */
	public Image createCopy() {
		return null;
	}

	
	/**
	 * Returns Color used to tint Color
	 * @return {String} hexadecimal representation of color
	 */
	public String getTintColor() {
		return null;
	}

	/**
	 * Sets Color used to tint the image
	 * @param color {Color|String} Color Object or css color string  ex.<br>
	 * 	<ol> 
	 * 	<li> Common color name "red", "green" </li>
	 *	<li> Hexadecimal representation of color such as #FF0096 or 0xFF0096 </li>
	 * 	<li> Color functions "rgb(255,0,0)","hsl(180, 50%, 50%)","rgba(255,255,120,1)" </li>
	 */
	public void setTintColor(Object color) {
	}
 
}
