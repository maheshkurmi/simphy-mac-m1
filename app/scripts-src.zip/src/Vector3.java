



/** Encapsulates a 3D vector. Allows chaining methods by returning a reference to itself 
 * For example:
 * <pre>
 * Vector3 a = new Vector3();
 * a.zero().add(1, 2,3).multiply(2);
 * </pre>*/
public class Vector3 {
	/** The magnitude of the x component of this {@link Vector3} */
	public float x;

	/** The magnitude of the y component of this {@link Vector3} */
	public float y;

	/** The magnitude of the z component of this {@link Vector3} */
	public float z;
	
	/**
	 * Returns projection of this vector in 2D xy plane
	 * @return new {@link Vector2} 
	 */
	public Vector2 xy() {
		return null;
	}

	/**
	 * Returns a copy of this vector. If a target vector is specified then this
	 * vector is copied into this target vector. If it is null then a new fresh
	 * vector is created.
	 * 
	 * @param {Vector3} target Optional target vector, can be null
	 * @return {Vector3} A copy of this vector
	 */
	public Vector3 clone(Vector3 target) {
		return null;

	}

	
	/**
	 * Sets this {@link Vector3} to the given {@link Vector3}.
	 * 
	 * @param vector the {@link Vector3} to set this {@link Vector3} to
	 * @return {@link Vector3} this vector for chaining
	 */
	public Vector3 set(Vector3 vector) {
		return null;
	}



	/**
	 * Sets this {@link Vector3} to the given {@link Vector3}.
	 * 
	 * @param x the x component of the {@link Vector3} to set this {@link Vector3}
	 *          to
	 * @param y the y component of the {@link Vector3} to set this {@link Vector3}
	 *          to
	 * @param z the z component of the {@link Vector3} to set this {@link Vector3}
	 *          to
	 * @return {@link Vector3} this vector for chaining
	 */
	public Vector3 set(float x, float y, float z) {
		return null;
	}
	
	/** Sets the components from the array. The array must have at least 3 elements
	 *
	 * @param values The array
	 * @return this vector for chaining */
	public Vector3 set (final float[] values) {
		return null;
	}

	/** Sets the components of the given vector and z-component
	 *
	 * @param vector The vector
	 * @param z The z-component
	 * @return This vector for chaining */
	public Vector3 set (final Vector2 vector, float z) {
		return null;
	}

	
	
	
	/** Sets the components from the given spherical coordinate
	 * @param radius {number} - the radius, or the Euclidean distance (straight-line distance) from the point to the origin.
	 * @param phi {Number} The polar angle between x-axis in radians [-pi, pi]
	 * @param theta {Number}The equatorial angle between z-axis in radians [0, 2pi]
	 * @return This vector for chaining */
	public Vector3 setFromSpherical (float radius,float phi, float theta) {
		return null;
	}
	
	/**
	 * Sets this vector from the cylindrical coordinates radius, theta and y.
	 * @param radius {Number} distance from the origin to a point in the x-z plane
	 * @param theta {Number} counterclockwise angle in the x-z plane measured in radians from the positive z-axis
	 * @param y {Number} height above the x-z plane. Default is 0.
	 * @return This vector for chaining 
	 */
	public Vector3 setFromCylindricalCoords(float radius,float theta,float y ) {
		return null;
	}


	/**
	 * Returns a unit {@link Vector3} of this {@link Vector3}.
	 * <p>
	 * This method requires the length of this {@link Vector3} is not zero.
	 * 
	 * @return {@link Vector3} 
	 */
	public Vector3 getNormalized() {
		return null;
	}

	/**
	 * Converts this {@link Vector3} into a unit {@link Vector3} and returns the
	 * magnitude before normalization.
	 * <p>
	 * This method requires the length of this {@link Vector3} is not zero.
	 * 
	 * @return float
	 */
	public float normalize() {
		return 0;
	}

	/**
	 * Returns the distance from this point to the given point.
	 * 
	 * @param x the x coordinate of the point
	 * @param y the y coordinate of the point
	 * @param z the z coordinate of the point
	 * @return float
	 */
	public float distance(float x, float y, float z) {
		return 0;
	}

	/**
	 * Returns the distance from this point to the given point.
	 * 
	 * @param point the point
	 * @return float
	 */
	public float distance(Vector3 point) {
		return 0;
	}

	/**
	 * Returns the distance from this point to the given point squared.
	 * 
	 * @param x the x coordinate of the point
	 * @param y the y coordinate of the point
	 * @param z the z coordinate of the point
	 * @return float
	 */
	public float distanceSquared(float x, float y, float z) {
		return 0;
	}

	/**
	 * Returns the distance from this point to the given point squared.
	 * 
	 * @param point the point
	 * @return float
	 */
	public float distanceSquared(Vector3 point) {
		return 0;
	}

	/**
	 * Returns true if the x and y components of this {@link Vector3} are the same
	 * as the given {@link Vector3}.
	 * 
	 * @param vector the {@link Vector3} to compare to
	 * @return boolean
	 */
	public boolean equals(Object obj) {
		return true;

	}

	/**
	 * Returns true if the x, y and z components of this {@link Vector3} are the
	 * same as the given x, y and z components.
	 * 
	 * @param x the x coordinate of the {@link Vector3} to compare to
	 * @param y the y coordinate of the {@link Vector3} to compare to
	 * @param z the z coordinate of the {@link Vector3} to compare to
	 * @return boolean
	 */
	public boolean equals(float x, float y, float z) {
		return true;
	}

	/** Compares this vector with the other vector, using the supplied epsilon for fuzzy equality testing.
	 * @param other
	 * @param epsilon
	 * @return whether the vectors have fuzzy equality. */
	public boolean epsilonEquals (final Vector3 other, float epsilon) {
		return true;
	}
	
	/** Compares this vector with the other vector, using the supplied epsilon for fuzzy equality testing.
	 * @return whether the vectors are the same. */
	public boolean epsilonEquals (float x, float y, float z, float epsilon) {
		return true;
	}

	/** @return Whether this vector is a unit length vector */
	public boolean isUnit () {
		return true;
	}

	/** @return Whether this vector is a unit length vector within the given margin. */
	public boolean isUnit (final float margin) {
		return true;
	}

	/**
	 * Returns true if this {@link Vector3} is the zero {@link Vector3}.
	 * 
	 * @return boolean
	 */
	public boolean isZero() {
		return true;
	}

	/** @return Whether the length of this vector is smaller than the given margin */
	public boolean isZero (final float margin) {
		return true;
	}


	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return null;
	}

	/**
	 * Returns the magnitude of this {@link Vector3}.
	 * 
	 * @return float
	 */
	public float getMagnitude() {
		return 0;
	}

	/**
	 * Returns the magnitude of this {@link Vector3} squared.
	 * 
	 * @return float
	 */
	public float getMagnitudeSquared() {
		return 0;
	}

	/**
	 * Sets the magnitude of the {@link Vector3}.
	 * 
	 * @param magnitude the magnitude
	 * @return {@link Vector3} this vector for chaining
	 */
	public Vector3 setMagnitude(float magnitude) {
		return null;
	}

	
	/** Limits the length of this vector, based on the desired maximum length.
	 * @param limit desired maximum length for this vector
	 * @return this vector for chaining */
	public Vector3 limit (float limit) {
		return null;
	};

	/**
	 * If this vector's x, y or z value is greater than v's x, y or z value, replace that value with the corresponding min value.
	 * @param v {Vector3} other vector
	 * @return this vector 
	 */
	public Vector3 min (Vector3 v ) {

		return null;
	}

	/**
	 * If this vector's x, y or z value is less than v's x, y or z value, replace that value with the corresponding max value.
	 * @param v {Vector3} other vector
	 * @return this vector 
	 */
	public Vector3 max (Vector3 v ) {
		return null;
	}

	
	
	/** Clamps this vector's length to given min and max values
	 * @param min Min length
	 * @param max Max length
	 * @return This vector for chaining */

	public Vector3 clamp (float min, float max) {
		return null;
	}

	/**
	 * Adds the given {@link Vector3} to this {@link Vector3}.
	 * 
	 * @param vector the {@link Vector3}
	 * @return {@link Vector3} this vector for chaining
	 */
	public Vector3 add(Vector3 vector) {
		return null;
	}

	/**
	 * Adds the given {@link Vector3} to this {@link Vector3}.
	 * 
	 * @param x the x component of the {@link Vector3}
	 * @param y the y component of the {@link Vector3}
	 * @param z the z component of the {@link Vector3}
	 * @return {@link Vector3} this vector for chaining
	 */
	public Vector3 add(float x, float y, float z) {
		return null;
	}

	/**
	 * Adds this {@link Vector3} and the given {@link Vector3} returning a new
	 * {@link Vector3} containing the result.
	 * 
	 * @param vector the {@link Vector3}
	 * @return new {@link Vector3}
	 */
	public Vector3 sum(Vector3 vector) {
		return null;
	}

	/**
	 * Adds this {@link Vector3} and the given {@link Vector3} returning a new
	 * {@link Vector3} containing the result.
	 * 
	 * @param x the x component of the {@link Vector3}
	 * @param y the y component of the {@link Vector3}
	 * @param z the z component of the {@link Vector3}
	 * @return new {@link Vector3}
	 */
	public Vector3 sum(float x, float y, float z) {
		return null;
	}

	/**
	 * Subtracts the given {@link Vector3} from this {@link Vector3}.
	 * 
	 * @param vector the {@link Vector3}
	 * @return {@link Vector3} this vector  for chaining
	 */
	public Vector3 subtract(Vector3 vector) {
		return null;
	}

	/**
	 * Subtracts the given {@link Vector3} from this {@link Vector3}.
	 * 
	 * @param x the x component of the {@link Vector3}
	 * @param y the y component of the {@link Vector3}
	 * @param z the z component of the {@link Vector3}
	 * @return {@link Vector3} this vector for chaining
	 */
	public Vector3 subtract(float x, float y, float z) {
		return null;
	}

	/**
	 * Subtracts the given {@link Vector3} from this {@link Vector3} returning a new
	 * {@link Vector3} containing the result.
	 * 
	 * @param vector the {@link Vector3}
	 * @return new {@link Vector3}
	 */
	public Vector3 difference(Vector3 vector) {
		return null;
	}

	/**
	 * Subtracts the given {@link Vector3} from this {@link Vector3} returning a new
	 * {@link Vector3} containing the result.
	 * 
	 * @param x the x component of the {@link Vector3}
	 * @param y the y component of the {@link Vector3}
	 * @param z the z component of the {@link Vector3}
	 * @return new {@link Vector3}
	 */
	public Vector3 difference(float x, float y, float z) {
		return null;
	}

	/**
	 * Creates a {@link Vector3} from this {@link Vector3} to the given
	 * {@link Vector3}.
	 * 
	 * @param vector the {@link Vector3}
	 * @return new {@link Vector3}
	 */
	public Vector3 to(Vector3 vector) {
		return null;
	}

	/**
	 * Creates a {@link Vector3} from this {@link Vector3} to the given
	 * {@link Vector3}.
	 * 
	 * @param x the x component of the {@link Vector3}
	 * @param y the y component of the {@link Vector3}
	 * @param z the z component of the {@link Vector3}
	 * @return new {@link Vector3}
	 */
	public Vector3 to(float x, float y, float z) {
		return null;
	}

	/**
	 * Multiplies this {@link Vector3} by the given scalar.
	 * 
	 * @param scalar the scalar
	 * @return {@link Vector3} this vector for chaining
	 */
	public Vector3 multiply(float scalar) {
		return null;
	}

	/**
	 * Multiplies this {@link Vector3} by the given scalar returning a new
	 * {@link Vector3} containing the result.
	 * 
	 * @param scalar the scalar
	 * @return new {@link Vector3}
	 */
	public Vector3 product(float scalar) {
		return null;
	}
	
	

	/** First scale a supplied vector, then add it to this vector.
	 * @param vec {@link Vector3}  addition vector
	 * @param scale {float} the value by which the addition vector will be scaled 
	 * @return {@link Vector3} this vector for chaining
	 */
	public Vector3 addScaledVector (Vector3 vec, float scale) {
		return null;
	}
	

	
	
	/** Linearly interpolates between this vector and the target vector by alpha which is in the range [0,1]. The result is stored
	 * in this vector.
	 * @param target {@link Vector3} The target vector
	 * @param alpha The interpolation coefficient
	 * @return {@link Vector3} This vector for chaining. */
	public Vector3 lerp (final Vector3 target, float alpha) {
		return null;
	}
	
	
	/**
	 * Returns the dot product of the given {@link Vector3} and this
	 * {@link Vector3}.
	 * 
	 * @param vector the {@link Vector3}
	 * @return float
	 */
	public float dot(Vector3 vector) {
		return 0;
	}

	/**
	 * Returns the dot product of the given {@link Vector3} and this
	 * {@link Vector3}.
	 * 
	 * @param x the x component of the {@link Vector3}
	 * @param y the y component of the {@link Vector3}
	 * @param z the z component of the {@link Vector3}
	 * @return float
	 */
	public float dot(float x, float y, float z) {
		return 0;
	}

	/**
	 * Returns the cross product of the this {@link Vector3} and the given
	 * {@link Vector3}.
	 * 
	 * @param vector the {@link Vector3}
	 * @return new {@link Vector3}
	 */
	public Vector3 cross(Vector3 vector) {
		return null;
	}

	/**
	 * Returns the cross product of the this {@link Vector3} and the given
	 * {@link Vector3}.
	 * 
	 * @param x the x component of the {@link Vector3}
	 * @param y the y component of the {@link Vector3}
	 * @param z the z component of the {@link Vector3}
	 * @return new {@link Vector3}
	 */
	public Vector3 cross(float x, float y, float z) {
		return null;
	}

	/**
	 * Returns true if the given {@link Vector3} is orthogonal (perpendicular) to
	 * this {@link Vector3}.
	 * <p>
	 * If the dot product of this vector and the given vector is zero then we know
	 * that they are perpendicular
	 * 
	 * @param vector the {@link Vector3}
	 * @return boolean
	 */
	public boolean isOrthogonal(Vector3 vector) {
		return true;
	}

	/**
	 * Returns true if the given {@link Vector3} is orthogonal (perpendicular) to
	 * this {@link Vector3}.
	 * <p>
	 * If the dot product of this vector and the given vector is zero then we know
	 * that they are perpendicular
	 * 
	 * @param x the x component of the {@link Vector3}
	 * @param y the y component of the {@link Vector3}
	 * @param z the z component of the {@link Vector3}
	 * @return boolean
	 */
	public boolean isOrthogonal(float x, float y, float z) {
		return true;
	}

	/**
	 * Returns true if the given {@link Vector3} is orthogonal (perpendicular) to
	 * this {@link Vector3}.
	 * <p>
	 * If the dot product of this vector and the given vector is zero then we know
	 * that they are perpendicular
	 * 
	 * @param vector the {@link Vector3}
	 * @return boolean
	 */
	public boolean isCollinear(Vector3 vector) {
		return true;
	}
	
	
	/**
	 * Returns true if the given {@link Vector3} is orthogonal (perpendicular) to
	 * this {@link Vector3}.
	 * <p>
	 * If the dot product of this vector and the given vector is zero then we know
	 * that they are perpendicular
	 * 
	 * @param x the x component of the {@link Vector3}
	 * @param y the y component of the {@link Vector3}
	 * @param z the z component of the {@link Vector3}
	 * @return boolean
	 */
	public boolean isCollinear(float x, float y, float z) {
		return true;
	}

	/**
	 * Projects this vector onto vector v
	 * @param v
	 * @return this vector after projection for chaining
	 */
	public Vector3 projectOnVector(Vector3 v ) {
		return null;
	}

	/**
	 *Projects this vector onto a plane by subtracting this vector projected onto the plane's normal from this vector.
	 * @param planeNormal {Vector3}  the normal to the reflecting plane
	 * @return this vector after projection for chaining
	 */
	public Vector3 projectOnPlane(Vector3 planeNormal ) {
		return null;
	}

	/**
	 *Reflect this vector off of plane orthogonal to normal. Normal is assumed to have unit length.
	 * @param planeNormal {Vector3}  the normal to the reflecting plane
	 * @return this vector after reflection for chaining
	 */
	public Vector3 reflect (Vector3 planeNormal ) {
		return null;
	}

	/**
	 * Returns the angle between this vector and vector v in radians.
	 * @param v {Vector3} 
	 * @return {Number} Angle in radians
	 */
	public float angleTo(Vector3 v ) {
		return 0;
	}
	
	/**
	 * Negates this {@link Vector3}.
	 * 
	 * @return {@link Vector3} this vector
	 */
	public Vector3 negate() {
		return null;
	}

	/**
	 * Returns a {@link Vector3} which is the negative of this {@link Vector3}.
	 * 
	 * @return new {@link Vector3}
	 */
	public Vector3 getNegative() {
		return null;
	}

	/**
	 * Rotates this vector by the given angle in radians around the given axis.
	 *
	 * @param axis    the axis need not be normalized
	 * @param degrees the angle in radians
	 * @return {@link Vector3} this vector for chaining
	 */
	public Vector3 rotate(final Vector3 axis, float radians) {
		return null;
	}

	/**
	 * Returns new Vector after rotating by the given angle in radians around the given axis.
	 *
	 * @param axis    the axis need not be normalized
	 * @param degrees the angle in radians
	 * @return new {@link Vector3} this vector for chaining
	 */
	public Vector3 getRotated(final Vector3 axis, float radians) {
		return null;
	}


	/**
	 * Multiplies this vector (with an implicit 1 in the 4th dimension) and m, and
	 * divides by perspective.
	 * 
	 * @param m {Matrix4} 
	 * @return transformed vector for chaining
	 */
	public Vector3 applyMatrix4(Matrix4 m) {

		return null;
	}

	/**
	 * Applies a Quaternion transform to this vector.
	 * @param m {Matrix4} 
	 * @return transformed vector for chaining
	 */
	public Vector3 applyQuaternion(Quaternion q) {
		return null;
	}
	


}
