package geom;

public class DynamicCurve2D extends Curve2D {
	
	protected DynamicCurve2D(){
	}
	
	
	/**
	 * removes all vertices from curve
	 */
	public void reset() {
		
	}
	
	/**
	 * Sets maximum number of points in locus
	 * @param maxPoints must be >0
	 */
	public void setMaxPoints(int maxPoints) {
		
	}
	
	/**
	 * Returns maximum number of points in locus
	 */
	public int getMaxPoints() {
		return 0;
	}




	

}
