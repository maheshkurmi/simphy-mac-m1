package geom;

import script.Vector2;

public  class Line2D extends Curve2D {
	
	/**
	 * default x axis
	 */
	public Line2D() {
		
	}



	/**
	 * Returns the point through which line is passing
	 * @return {Vector2}
	 */
	public Vector2 getPoint() {
		return null;
	}
	
	/**
	 * returns unit vector parallel to the line
	 * @return {Vector2}
	 */
	public Vector2 getDirection() {
		return null;
	}
	
	/**
	 * returns the slope of the line
	 * @return {Number}
	 */
	public double getSlope() {
		return 0;
	}
	
	/**
	 * Returns the visible length of the line 
	 * @return {Number}
	 */
	public double getLength() {
		return 0;
	}




}
