package geom;

import script.Vector2;

public class Circle2D extends Curve2D{
	
	protected Circle2D(){
		
	}
	

	
	/**
	 * Returns the radius of this circle
	 * @return {Number} the radius of circle
	 */
	public double getRadius() {
		return 0;
	}
	
	/**
	 * Returns the center of this circle
	 * @return {Vector2} the radius of circle
	 */
	public Vector2 getCenter() {
		return null;
	}

	

}
