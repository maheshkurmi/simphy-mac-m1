package geom;

public class FunctionExplicit2D extends Curve2D {
	
	
	public FunctionExplicit2D(String expr){
		
	}
	
	/**
	 * Set expressions for each component
	 * 
	 * @param expr Expression in terms of variable x 
	 * 			ex:<code> sin(x); x*x </code> 
	 */
	public void setExpression(String expr){
		
	}

	/**
	 * return expression for the function
	 * @return
	 */
	public String getExpression(){
		return null;
	}


	/**
	 * Returns local maxima or local minima point in specified range (in domain [start, end]) <br>
	 * Note: small the range greater will be the accuracy
	 * @param start 
	 * @param end
	 * @return {Number} x coordinate for the critical point f any else return NaN
	 */
	public  double getCriticalPoint(double start,double end ){
		return 0;
	}
	
	/**
	 * returns true if f(x) is continous at x
	 * @param x
	 * @return true if f(x) is continuous at x
	 */
	public boolean isContinuousAt(double x){
		return false;
	}
	
	/**
	 * returns Y coordinate for the given x coordinate
	 * @param x
	 * @return {number} returns value of function for given x if x is in its domain else returns null
	 */
	public double getY(double x) {
		return 0;
	}
	
	/**
	 * Returns the root of function in interval (guess-range , guess+range)
	 * Note: Smaller the range greater will be the accuracy
	 * @param guess 
	 * @param range
	 * @return {Number} root of function if exists in given rangle else returns null
	 */
	public double getRoot( double guess, double range){
	    return Double.NaN;
	}
	

	/**
	 * returns true if f(x) is Differentiable at x
	 * @param x
	 * @return true if f(x) is Differentiable at x
	 */
	public boolean isDifferentiableAt(double x){
		return false;
	}



}
