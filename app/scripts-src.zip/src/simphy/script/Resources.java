package simphy.script;

import simphy.script.canvas.Context;
import simphy.script.canvas.Image;


/**
 * Class for read only access to resources currently loaded in simulations
 * Resources can only be added manually from front end
 * @author mahesh
 *
 */
public class Resources {
	/**
	 * Do not allow its instance creation
	 */
	private Resources() {

	}

	/**
	 * Return File with the name
	 * @param {String}name of File
	 * @return {File}
	 */
	public static File getFile(String name){
		return null;
	}


	/**
	 * returns array containing names of all loaded fonts
	 * @return {Font[]}
	 */
	public static Font[] getAllFonts(){
		return null;
	}
	
	/**
	 * Returns Font with the name 
	 * @param {String} name of Font
	 * @return {Font}
	 */
	public static Font getFont(String name){
		return null;
		//return null;
	}

	
	/**
	 * Returns array containing all loaded animations / images 
	 * @return {Array} array of currently loaded images in resource folder
	 */
	public static Image[] getAllAnimations(){
		return null;
	}
	
	
	/**
	 * Returns Image identified by the name 
	 * @param name {String} name of image to be returned
	 * @return {Image} image object if available else null 
	 * @throws SimphyScriptException 
	 */
	public static Image getAnimation(String name){
		return null;
	}
	
	
	/**
	 * Plays animation until it stops, centered at position v in world coordinates
	 * @param animName {String} Name of animation
	 * @param v {String}  Position in world coordinate
	 * @throws SimphyScriptException 
	 */
	public static void playAnimation(String animName, Vector2 v){
	}
	
	/**
	 * Plays animation until it stops, centered at point (x,y) in world coordinates
	 * @param animName {String}
	 * @param x {Number}
	 * @param y {Number}
	 */
	public static void playAnimation(String animName, double x, double y) {
	}
	
	
	/**
	 * Plays animation on {@link Context} until it stops, keeping top left of animation at point (x,y) in current context coordinates <br>
	 * <b>Note1:</b> x,y are pixel coordinates if no transform is set on context, else actual location depends on current transform on context<br>
	 * <b>Note2:</b> animations are always drawn over the top of current drawing, to clear animations call #context.clear()
	 * @param ctx {Context} context on which animation is to be rendered
	 * @param animName {String} animation to be rendered
	 * @param x {Number}
	 * @param y {Number}
	 */
	public static void playAnimation(Context context,String animName, double x, double y){
	}
	
	/**
	 * returns array containing all loaded sounds
	 * @return {Sound[]}
	 */
	public static Audio[] getAllSounds(){
		return null;
	}
	
	/**
	 * Return sound source with the name
	 * @param {String}name of sound
	 * @return {Sound}
	 */
	public static Audio getSound(String name){
		return null;
	}
	
	/**
	 * Plays sound source once with the name
	 * @param {String}name
	 */
	public static void playSound(String name){
		
	}
	
	/**
	 * Plays sound source  with the name
	 * @param {String}name
	 * @param {boolean}looping true if sound is to be repeated continuously
	 */
	public static void playSound(String name,boolean looping){
	
	}
	
	/**
	 * Stops all sounds
	 */
	public static void stopAllSounds(){
		
	}
	
	
	
}
