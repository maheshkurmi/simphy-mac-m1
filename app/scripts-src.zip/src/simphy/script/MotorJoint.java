package simphy.script;

/**
 * Implementation a motor joint.
 * <p>
 * A motor joint uses a motor to apply forces and torques to move the joined 
 * bodies together.
 * <p>
 * The motor is limited by a maximum force and torque.  By default these are
 * zero and will need to be set before the joint will function properly.
 * Larger values will allow the motor to apply more force and torque to the
 * bodies.  This can have two effects.  The first is that the bodies will
 * move to their correct positions faster.  The second is that the bodies
 * will be moving faster and may overshoot more causing more oscillation.
 * Use the {@link #setCorrectionFactor(double)} method to help reduce the
 * oscillation. 
 * <p>
 * The linear and angular targets are the target distance and angle that the 
 * bodies should achieve relative to each other's position and rotation.  By 
 * default, the linear target will be the distance between the two body centers
 * and the angular target will be the relative rotation of the bodies.  Use the
 * {@link #setLinearTarget(Vector2)} and {@link #setAngularTarget(double)} 
 * methods to set the desired relative translation and rotate between the 
 * bodies.
 * <p>
 * This joint is ideal for character movement as it allows direct control of 
 * the motion using targets, but yet still allows interaction with the 
 * environment.  The best way to achieve this effect is to have the second body
 * be an infinite mass body that doesn't collide with anything.  Then, simply 
 * set the current position and rotation of the infinite mass body.  The 
 * character body will move and rotate smoothly, participating in any collision
 * or with other joints to match the infinite mass body.
 */
public class MotorJoint extends Joint {

	/**
	 * Returns the desired linear distance along the x and y coordinates from 
	 * body1's world center.
	 * <p>
	 * To get the world linear target:
	 * <pre>
	 * joint.getBody1().getWorldVector(joint.getLinearTarget());
	 * </pre>
	 * @return {@link Vector2}
	 */
	public Vector2 getLinearTarget() {
		return null;
	}
	
	/**
	 * Sets the desired linear distance along the x and y coordinates from 
	 * body1's world center.
	 * @param target the desired distance along the x and y coordinates
	 */
	public void setLinearTarget(Vector2 target) {
		
	}
	
	/**
	 * Returns the desired angle between the bodies.
	 * @return double
	 */
	public double getAngularTarget() {
		return 0;
	}
	
	/**
	 * Sets the desired angle between the bodies.
	 * @param target the desired angle between the bodies
	 */
	public void setAngularTarget(double target) {
		
	}
	
	/**
	 * Returns the correction factor.
	 * @return double
	 */
	public double getCorrectionFactor() {
		return 0;
	}
	
	/**
	 * Sets the correction factor.
	 * <p>
	 * The correction factor controls the rate at which the bodies perform the
	 * desired actions.  The default is 0.3.
	 * <p>
	 * A value of zero means that the bodies do not perform any action.
	 * @param correctionFactor the correction factor in the range [0, 1]
	 */
	public void setCorrectionFactor(double correctionFactor) {
		
	}
	
	/**
	 * Returns the maximum torque this constraint will apply in newton-meters.
	 * @return double
	 */
	public double getMaximumTorque() {
		return 0;
	}
		
	/**
	 * Sets the maximum torque this constraint will apply in newton-meters.
	 * @param maximumTorque the maximum torque in newton-meters; in the range [0, &infin;]
	 * @throws IllegalArgumentException if maxTorque is less than zero
	 */
	public void setMaximumTorque(double maximumTorque) {
		
	}

	/**
	 * Returns the maximum force this constraint will apply in newtons.
	 * @return double
	 */
	public double getMaximumForce() {
		return 0;
	}
	
	/**
	 * Sets the maximum force this constraint will apply in newtons.
	 * @param maximumForce the maximum force in newtons; in the range [0, &infin;]
	 * @throws IllegalArgumentException if maxForce is less than zero
	 */
	public void setMaximumForce(double maximumForce) {
		
	}
}
