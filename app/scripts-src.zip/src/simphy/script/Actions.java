package simphy.script;


public class Actions {
	/**
	 * Do not allow its instance creation
	 */
	private Actions(){
		
	}
	
	
	
	/** Linear interpolation */
	public static final String linear= "linear" ;

	/**Slow then uniform then slow */
	public static final String fade= "fade" ;
	
	/** Quadratic interpolation */
	public static final String POW= "pow2" ;
	/** Fast, then slow quadratic interpolation */
	public static final String POW2IN = "pow2In";
	/** Slow, then falst quadratic interpolation  */
	public static final String pow2Out = "pow2Out";
	
	
	/** Cubic interpolation */
	public static final String pow3 ="pow3";
	/** Fast, then slow cubic interpolation */
	public static final String pow3In = "pow3In";
	/** Fast, then slow cubic interpolation */
	public static final String pow3Out = "pow3Out";

	/** exponential growth for half part and asymptotical growth for another half */
	public static final String exp5 = "exp5";
	/** exponential growt*/
	public static final String expIn = "exp5In";
	/**asymptotical growth*/
	public static final String expOut = "exp5Out";

	/**A simple elastic interaction, similar to a spring oscillating back and forth*/
	public static final String elastic = "elastic";
	/**Elastic in Interpolation*/
	public static final String elasticIn = "elasticIn";
	/**Elastic out Interpolation*/
	public static final String elasticOut = "elasticOut";

	/**Swing interploation in and out symmetrically*/
	public static final String swing = "swing";
	/**Swing In Interploation */ 
	public static final String swingIn = "swingIn";
	/**Swing Out Interploation*/ 
	public static final String swingOut = "swingOut";

	/**Bounce Interpolation in and out symmetrically*/
	public static final String bounce = "bounce";
	/**Bounce In Interpolation*/
	public static final String bounceIn = "bounceIn";
	/**Bounce Out Interpolation*/
	public static final String bounceOut = "bounceOut";

	/**Circular Interpolation in and out*/
	public static final String circle = "circle";
	/**Circular In Interpolation */
	public static final String circleIn = "circleIn";
	/**Circular Out Interpolation */
	public static final String circleOut = "circleOut";

	/**Sinusoidal Interpolation in and out symmetrically. (Sine interpolation from -90 to 90*/
	public static final String sine = "sine";
	
	/**Sinusoidal In Interpolation (Sine interpolation from -90 to 0)*/
	public static final String sineIn = "sineIn";
	
	/**Sinusoidal Out Interpolation in  (Sine interpolation from 0 to 90*/
	public static final String sineOut = "sineOut";

	/** Moves the actor instantly. 
	 * @param x {Number} x coordiate of final position
	 * @param y {Number} y coordiate of final position
	 * @return {Action} created action
	 * */
	 public static TemporalAction moveTo (float x, float y) {
		return null;
	}

	 /**
	  * Moves actor to specified point in specified time
	  * @param x {Number} x coordiate of final position
	  * @param y {Number} y coordiate of final position
	  * @param duration {Number} interval in seconds
	  * @return {Action} created action
	  */
	 public static TemporalAction moveTo (float x, float y, float duration) {
		return moveTo(x, y, duration, null);
	}

	 /**
	  * Moves actor to specified point in specified time
	  * @param x {Number} x coordiate of final position
	  * @param y {Number} y coordiate of final position
	  * @param duration {Number} interval in seconds
	  * @param interpolation {String} (can be obtained from actions.[interpolation name], ex. actions.bounceIn, actions.linear etc)
	  * @return {Action} created action
	  */
	 public static TemporalAction moveTo (float x, float y, float duration, String interpolation) {
		return null;
	}

	/**
	 * Displaces the actor instantly. 
	 * @param amountX {Number} displacement along x direction
	 * @param amountY {Number} displacement along x direction
	 * @return {Action} created action
	 */
	 public static TemporalAction moveBy (float amountX, float amountY) {
		return null;
	}

	 /**
	 * Displaces the actor in specified duration with linear interpolation
	 * @param amountX {Number} displacement along x direction
	 * @param amountY {Number} displacement along x direction
	 * @param duration {Number} interval in seconds
	 * @return {Action} created action
	 */
	 public static TemporalAction moveBy (float amountX, float amountY, float duration) {
		return null;
	}

	 /**
	  * Displaces the actor in specified duration 
	  * @param amountX {Number} displacement along x direction
	  * @param amountY {Number} displacement along x direction
	  * @param duration {Number} interval in seconds
	  * @param interpolation {String} (can be obtained from actions.[interpolation name], ex. actions.bounceIn, actions.linear etc)
	  * @return {Action} created action
	  */
	 public static TemporalAction moveBy (float amountX, float amountY, float duration, String interpolation) {
		 return null;
	}

	/** 
	 * Scales the actor instantly. 
	 * @param sx {Number} final scale in x direction (must be +ve)
	 * @param sy {Number} final scale in y direction (must be +ve)
 	 * @return {Action} created action
	 */
	 public static TemporalAction scaleTo (float sx, float sy) {
		 return null;
	}

	 /**
	  * Scales body to specified scale with linear interpolation
	  * @param sx {Number} final scale in x direction (must be +ve)
	  * @param sy {Number} final scale in y direction (must be +ve)
	  * @param duration {Number} interval in seconds
	  * @return {Action} created action
	  */
	 public static TemporalAction scaleTo (float sx, float sy, float duration) {
		 return null;
	}

	/**
	 * Scales body to specified scale with specified interpolation
	 * @param sx {Number} final scale in x direction (must be +ve)
	 * @param sy {Number} final scale in y direction (must be +ve)
	 * @param duration {Number} interval in seconds
	 * @param interpolation {String} (can be obtained from actions.[interpolation name], ex. actions.bounceIn, actions.linear etc)
	  * @return {Action} created action
	 */
	 public static TemporalAction scaleTo (float sx, float sy, float duration, String interpolation) {
		 return null;
	}

	/** 
	 * Scales the actor by specified factor instantly. 
	 * @param sx {Number} scale factor in x direction (must be +ve)
	 * @param sy {Number} scale factor in y direction (must be +ve)
 	 * @return {Action} created action
	 */
	 public static TemporalAction scaleBy (float sx, float sy) {
		 return null;
	}

	 /**
	  * Scales actor by specified factor in specified duration 
	  * @param sx {Number} scale factor in x direction (must be +ve)
	  * @param sy {Number} scale factor in y direction (must be +ve)
	  * @param duration {Number} interval in seconds
	  * @return {Action} created action
	  */
	 public static TemporalAction scaleBy (float sx, float sy, float duration) {
		 return null;
	}

	 /**
	  * Scales the actor by specified factor in specified duration 
	  * @param sx {Number} scale factor in x direction (must be +ve)
	  * @param sy {Number} scale factor in y direction (must be +ve)
	  * @param duration {Number} interval in seconds
	  * @param interpolation {String} (can be obtained from actions.[interpolation name], ex. actions.bounceIn, actions.linear etc)
	  * @return {Action} created action
	  */

	 public static TemporalAction scaleBy (float sx, float sy, float duration, String interpolation) {
		 return null;
	}

	/** Sets Rotation of the actor instantly.
	 *	@param rotation {Number} in radians (ACW as positive)
	  * @return {Action} created action
	 */
	 public static TemporalAction rotateTo (float rotation) {
		 return null;
	}

	 /**
	  * Sets Rotation the actor in specified duration with linear interpolation
	  * @param rotation {Number} in radians ACW as positive 
	  * @param duration {Number} interval in seconds
	  * @return {Action} created action
	  */
	 public static  TemporalAction rotateTo (float rotation, float duration) {
		 return null;
	}

	 /**
	  * sets Rotation of the actor in specified duration with specified interpolation
	  * @param rotation {Number} in radians ACW as positive 
	  * @param duration {Number} interval in seconds
	  * @param interpolation {String} (can be obtained from actions.[interpolation name], ex. actions.bounceIn, actions.linear etc)
	  * @return {Action} created action
	  */
	 public static TemporalAction rotateTo (float rotation, float duration, String interpolation) {
		 return null;
	}

	/** Rotates the actor instantly. 
	 *  @param rotationAmount {Number} in radians ACW as positive 
	 * 	@return {Action} created action
	 */
	 public static TemporalAction rotateBy (float rotationAmount) {
		 return null;
	}

	 /**
	  * Rotates the actor in specified duration with linear interpolation
	  * @param rotationAmount {Number} in radians ACW as positive 
	  * @param duration {Number} interval in seconds
	  * @return {Action} created action
	  */
	public static TemporalAction rotateBy (float rotationAmount, float duration) {
		return null;
	}

	 /**
	  * Rotates the actor in specified duration 
	  * @param rotationAmount {Number} in radians ACW as positive 
	  * @param duration {Number} interval in seconds
	  * @param interpolation {String} (can be obtained from actions.[interpolation name], ex. actions.bounceIn, actions.linear etc)
	  * @return {Action} created action
	  */
	 public static TemporalAction rotateBy (float rotationAmount, float duration, String interpolation) {
		 return null;
	}

	/** Sets the actor's color instantly. 
	 * @param color {Color} color to set
	 * @return {Action} created action
	 */
	 public static TemporalAction color (Color color) {
		 return null;
	}

	/** Transitions from the color at the time this action starts to the specified color. 
	 * @param color {Color} final color to set
	 * @param duration {Number} interval in seconds
	 * @return {Action} created action
	 */
	 public static TemporalAction color (Color color, float duration) {
		return null;
	}

	/** Transitions from the color at the time this action starts to the specified color.
	 * @param color {Color} final color to set
	 * @param duration {Number} interval in seconds
     * @param interpolation {String} (can be obtained from actions.[interpolation name], ex. actions.bounceIn, actions.linear etc)
	 * @return {Action} created action
	 */
	 public static TemporalAction color (Color color, float duration, String interpolation) {
		 return null;
	}

	/** Sets the actor's alpha instantly.
	  * @param alpha {Number} transparent in 0 to 1 (1 means fully opaque)
	  * @return {Action} created action
	  */
	 public static TemporalAction alpha (float alpha) {
		 return null;
	}

	/** Transitions from the alpha at the time this action starts to the specified alpha.
	 *  @param alpha {Number} transparent in 0 to 1 (1 means fully opaque)
	 *  @param duration {Number} interval in seconds
 	 * 	@return {Action} created action
 	 */
	 public static TemporalAction alpha (float alpha, float duration) {
		 return null;
	}

	/** Transitions from the alpha at the time this action starts to the specified alpha.
	  * @param alpha {Number} transparent in 0 to 1 (1 means fully opaque)
	  * @param duration {Number} interval in seconds
	  * @param interpolation {String} (can be obtained from actions.[interpolation name], ex. actions.bounceIn, actions.linear etc)
	  * @return {Action} created action
	  */
	 public static TemporalAction alpha (float alpha, float duration, String interpolation) {
		 return null;
	}

	/** Transitions from the alpha at the time this action starts to an alpha of 0. 
	 * @param duration {Number} interval in seconds
	 * @return {Action} created action
	 */
	 public static TemporalAction fadeOut (float duration) {
		 return null;
	}

	/** Transitions from the alpha at the time this action starts to an alpha of 0.
	  * @param duration {Number} interval in seconds
	  * @param interpolation {String} (can be obtained from actions.[interpolation name], ex. actions.bounceIn, actions.linear etc)
	  * 	@return {Action} created action
	 */
	 public static TemporalAction fadeOut (float duration, String interpolation) {
		 return null;
	}

	/** Transitions from the alpha at the time this action starts to an alpha of 1. 
	  * @param duration {Number} interval in seconds
 	  * @return {Action} created action
 	  */
	 public static TemporalAction fadeIn (float duration) {
		 return null;
	}

	/** Transitions from the alpha at the time this action starts, to an alpha of 1. 
	  * @param duration {Number} interval in seconds
	  * @param interpolation {String} (can be obtained from actions.[interpolation name], ex. actions.bounceIn, actions.linear etc)
 	  * @return {Action} created action
 	  */
	 public static TemporalAction fadeIn (float duration, String interpolation) {
		 return null;
	}

	 /**
	  * instantly makes actor visible
	  * @return {Action} created action
	  */
	 public static Action show () {
		return null;
	}

	 /**
	  * Instantly hides actor
	  * @return {Action} created action
	  */
	 public static Action hide () {
		 return null;
	}

	 /**
	  * Instantly makes actor visible or hiddedn
	  * @param visible {boolean}
	  * @return {Action} created action
	  */
	 public static Action visible (boolean visible) {
		 return null;
	}

	 /**
	  * Runs specified script function (already defined in script)instantly with the actor body passed as an arguement <br>
	  * Ex. to change color of body to red, use following code in script <br>
	  * <pre>
	  * function changeColorToRed(body){
	  * 	body.setFillColor("red");
	  * }
	  * 
	  * disc.setAction(actions.runFunction(changeColorToRed));
	  * </pre>
	  * This action can be very useful if combined with other actions
	  * @param callback Function alrady defined in script
	  * @return {Action} created action
	  */
	 public static Action runFunction (Object callback) {
		 return null;
	}
	
	 /**
	  * Removes actor of the action instantly
	  * @return {Action} created action
	  */
	 public static Action removeActor () {
		return null;
	}

	 /**
	  * Adds body instantly
	  * @param actorTobeAdded {body}
	  * @return {Action} created action
	  */
	 public static Action addActionable (Actionable actorTobeAdded) {
		 return null;
	}

	 /**
	  * Addds body instantly at specified location
	  * @param actorTobeAdded {Actionable}
	  * @param location {Vector2} location at which body should be loaded
	  * @return {Action} created action
	  */
	 public static Action addActionable (Actionable actorTobeAdded, Vector2 location) {
		 return null;
	}

	 /**
	  * Adds actor instantly setting its position and velocity 
	  * @param actorTobeAdded {Actionable}
	  * @param location {Vector2}
	  * @param linearVelocity {Vector2} 
	  * @param angularVelocity {Number}
	  * @return {Action} created action
	  */
	 public static Action addActionable(Actionable actorTobeAdded, Vector2 location, Vector2 linearVelocity, double angularVelocity){
		 return null;
	}
	 
	 /**
	  * Removes specified body instantly
	  * @param removedActor {Actor} body to be removed
	  * @return {Action} created action
	  */
	public static Action removeActor (Actionable removedActor) {
		return null;
	}

	/**
	 * delays execution of given action for specific amount of time
	  * @param duration {Number} interval in seconds
	  * @return {Action} created action
	 */
	 public static Action delay (float duration) {
		 return null;
	}

	 /**
	  * delays execution of given action for specific amount of time and runs action just after this delay
	  * @param duration {Number} interval in seconds
	  * @param delayedAction {Action} action to be invoked after specified delay
	  * @return {Action} created action
	  */
	 public static Action delay (float duration, Action delayedAction) {
		 return null;
	}

	/**
	 * execute given actions in sequence - one after another
	 * @param action1 first action
	 * @param action2 second action
	  * @return {Action} created action
	 */
	 public static MultiAction sequence (Action action1, Action action2) {
		 return null;
	}

	 /**
	  * execute given actions in sequence - one after another
	  * @param action1 {Action} first action
	  * @param action2 {Action} second action
	  * @param action3 {Action} third action
	  * @return {Action} created action
	  */
	 public static MultiAction sequence (Action action1, Action action2, Action action3) {
		return null;
	}

	 /**
	  * execute given actions in sequence - one after another
	  * @param action1 {Action} first action
	  * @param action2 {Action} second action
	  * @param action3 {Action} third action
	  * @param action4 {Action} fourth action
	  * @return {Action} created action
	  */
	 public static MultiAction sequence (Action action1, Action action2, Action action3, Action action4) {
		 return null;
	}

	 /**
	  * execute given actions in sequence - one after another
	  * @param actions {Action[]} Array of actions to be execulated in order
	  * @return {Action} created action
	  */
	 public static MultiAction sequence (Action... actions) {
		 return null;
	}
	 
	/**
	 * Creates empty sequence action, New actions can abe added to this action
	 * by addAction() method of returned object
	  * @return {MultiAction} created action
	 */
	 public static MultiAction sequence () {
		 return null;
	}

	 /**
	  * execute given actions in parallel - all actions at once
	  * @param action1 {Action} 
	  * @param action2 {Action}
	  * @return {MultiAction} created action
	  */
	 public static MultiAction parallel (Action action1, Action action2) {
		 return null;
	}


	 /**
	  * execute given actions in parallel - all actions at once
	  * @param action1 {Action}
	  * @param action2 {Action}
	  * @param action3 {Action}
	  * @return {MultiAction} created action
	  */
	 public static MultiAction parallel (Action action1, Action action2, Action action3) {
		 return null;
	}

	 /**
	  * execute given actions in parallel - all actions at once
	  * @param action1 {Action}
	  * @param action2 {Action}
	  * @param action3 {Action}
	  * @param action4 {Action}
	  * @return {MultiAction} created action
	  */
	 public static MultiAction parallel (Action action1, Action action2, Action action3, Action action4) {
		 return null;
	}

	 /**
	  * execute given actions in parallel - all actions at once
	  * @param actions {Action[]} Array of actions to be executed simulteneously
	  * @return {MultiAction} created action
	  */
	 public static MultiAction parallel (Action... actions) {
		 return null;
	}

	 /**
	  * Creates Empty paralllel action, 
	  * New Actions can be added to this action by method addAction(Action) of returned object
	  * @return {MultiAction} created action
	  */
	 public static MultiAction parallel () {
		 return null;
	}

	 /**
	  * repeats given action n-times
	  * @param count No of times action should repeat (must be +ve)
	  * @param repeatedAction  {Action} action to be repeated
	  * @return {MultiAction} created action
	  */
	 public static Action repeat (int count, Action repeatedAction) {
		 return null;
	}

	 /**
	  * repeats given action forever
	  * @param repeatedAction  {Action} action to be repeated
	  * @return {Action} created action
	  */
	 public static Action forever (Action repeatedAction) {
		 return null;
	}

	
	 /**
	  * Invokes action on specified actor 
	  * @param targetAction {Action} action to be invoked
	  * @param targetActor {Actionable} target on which action is to be invoked
	  * @return {Action} created action
	  */
	 public static Action invokeAction (Action targetAction,Actionable targetActor) {
		 return null;
	}
	 
	 
	/*
	 public static AddListenerAction addListener (EventListener listener, boolean capture) {
		AddListenerAction addAction = action(AddListenerAction.class);
		addAction.setListener(listener);
		addAction.setCapture(capture);
		return addAction;
	}

	 public static AddListenerAction addListener (EventListener listener, boolean capture, Actor targetActor) {
		AddListenerAction addAction = action(AddListenerAction.class);
		addAction.setTarget(targetActor);
		addAction.setListener(listener);
		addAction.setCapture(capture);
		return addAction;
	}

	 public static RemoveListenerAction removeListener (EventListener listener, boolean capture) {
		RemoveListenerAction addAction = action(RemoveListenerAction.class);
		addAction.setListener(listener);
		addAction.setCapture(capture);
		return addAction;
	}

	 public static RemoveListenerAction removeListener (EventListener listener, boolean capture, Actor targetActor) {
		RemoveListenerAction addAction = action(RemoveListenerAction.class);
		addAction.setTarget(targetActor);
		addAction.setListener(listener);
		addAction.setCapture(capture);
		return addAction;
	}
	*/
}
