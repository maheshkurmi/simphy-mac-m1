package simphy.script;



/** Actions attach to {@link Body} and perform some task, often over time.*/

 public  class Action  {

	/** Updates the action based on time. Typically this is called each frame by {@link Simphy.update#(float)}.
	 * @param delta Time in seconds since the last frame.
	 * @return true if the action is done. This method may continue to be called after the action is done. */
	public  boolean act(float delta){return false;};

	
	/** Sets the state of the action so it can be run again. */
	public  void restart () {
	}

	/** Sets the actor this action is attached to. This also sets the {@link #setActor(Body) target} actor if it is null. This
	 * method is called automatically when an action is added to an actor. This method is also called with null when an action is
	 * removed from an actor.
	 * @param actor {Body} 
	 */
	public  void setActor (Actionable actor) {}

	/** @return null if the action is not attached to an actor. */
	public  Body getActor () {
		return null;
	}

	/** Resets the optional state of this action to as if it were newly created, allowing the action to be pooled and reused. State
	 * required to be set for every usage of this action or computed during the action does not need to be reset.
	 * <p>
	 * The default implementation calls {@link #restart()}.
	 * <p>
	 * If a subclass has optional state, it must override this method, call super, and reset the optional state. */
	public  void reset () {}

	
	/**
	 * Returns copy of the action with actor set to null
	 * @return {Action}*/
	public   Action Copy(){return null;};
	
	/**
	 * Sets interpolation of the action
	 * @param name canbe 
	 */
	public void setInterpolation (String name) {
	}
	
}
