package simphy.script.geom;

import simphy.script.Vector2;

/**
 * 
 * @author mahesh
 *
 */
public  class Shape2D {
	/** {String} the identifier name of shape*/
	public String name = null;

	/** {String} The outline pattern of shape, can be any of "solid","dotted","dashed","dash-dot"*/
	public String strokePattern = null;
	
	/** {String} the current strokeColor, used to fill shape ex "red", rgba(255,255,255.0.3), #FFFFFF */
	public String fillStyle = null;

	/** {String} the current strokeColor, used to render shape outlines ex "red", rgba(255,255,255.0.3), #FFFFFF */
	public String strokeStyle = null;

	/** {number} the current stroke width (>0) used to stroke shapes in pixel, default value is 1.5 */
	public double lineWidth=0;

	/** {Boolean} flag to show/hide the shape*/
	public boolean visible = false;

	/** {Boolean} flag to show/hide the shape equation*/
	public boolean showEqn = false;
	
	/** {Boolean} flag to show/hide the shape name*/
	public boolean showName = false;
	
	
	/**
	 * returns array of Parents needed for construction of this shape for the shape if any, else returns null
	 * 
	 * @return
	 */
	public Shape2D[] getParents() {
		return null;
	}

	/**
	 * returns arrays of parameters needed for construction of this shape for shape if any, else returns null
	 * @return
	 */
	public String[]  getParams(){
		return null;
		
	}


	/**
	 * @return the expression/info for the shape
	 */
	public  String getEquation() {return null;};

	/**
	 * returns info fothe shape
	 * 
	 * @return
	 */
	public  String getShapeInfo() {return null;};

	
	/**
	 * Returns true if the specified point  lies on the shape, with precision given by
	 * {@link #ACCURACY}
	 * @param pt {Vector2 } 
	 * @return {Boolean}  
	 */
	public  boolean contains(Vector2 pt) {return false; };

	/**
	 * Returns shortest distance of shape from the specified pt
	 * @param pt {Vector2} 
	 * @return {Number}
	 */
	public  double distance(Vector2 pt) {return 0;};


	/**
	 * returns info for the shape
	 * 
	 * @return
	 */
	public String getInfo() {
		return null;
	}


	/**
	 * Returns true if shape is valid
	 * @return
	 */
	public boolean isDefined() {
		return false;
	}

	/**
	 * retruns true if shape can be moved freely by mouse drag or arrow keys
	 * @return
	 */
	public boolean isFreeToMove() {
		return false;
	}

    
}
