package simphy.script.geom;

import simphy.script.Vector2;

/**
 * 
 * @author mahesh
 *
 */
public class Curve2D extends Shape2D{
	
	  /**
     * Returns the projection position(nearest point) of the point on the shape,
     * by computing angle with horizontal 
     * @see #point(double)
     */
 
	public  double project(Vector2 pt) {return 0;};	
	
	 /**
     * Get the position of the curve from internal parametric representation,
     * depending on the parameter t. This parameter is between the two limits t0
     * and t1.
     */
    public  Vector2 point(double t) {return null;} ;

	
    /**
     * Returns the parameter of the first point of the curve.
     */
    public double t0() {
        return 0;
    }
    
    /**
     * Returns the parameter of the last point of the curve.
     */
    public double t1() {
        return 1;
    }

    /**
     * Returns the unit Vector along tangent to curve
     */
    public Vector2 getTangentVector(double t) {
    	return null;
    }

  
    /**
     * returns the slope of the curve
     * @param t
     * @return {Number}
     */
 	public double getDerivative (double t){
 	  return 0;
 	}
 	
 	/**
 	 * Returns double derivative on the curve at point specified by parameter t
 	 * @param t
 	 * @return {Number}
 	 */
	public double getDoubleDerivative (double t){
		return 0;
	}
}
