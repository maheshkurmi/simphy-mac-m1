package simphy.script.geom;

public class ParametricCurve2D extends DynamicCurve2D {

	
	/**
	 * Returns x Expression as a function of 't' for this parametric curve
	 * @return {String}
	 */
	public String getExpressionX(){
		return null;
	}
	
	/**
	 * Returns y Expression as a function of 't' for this parametric curve
	 * @return {String}
	 */
	public String getExpressionY(){
		return null;
	}
	
	
	/**
	 * Sets expression for the field, the expression can be a function of position <b>x</b>, <b>y</b> or polar coordinates  <b>r</b> and  <b>th</b>(theta)
	 * @param xExpr expression for x component of field 
	 * @param yExpr expression for y component of field 
	 */
	public void setExpressions(String xExpr,String yExpr){
	
	}
	
	
	
}
