package simphy.script.geom;



/**
 * 
 * @author Mahesh
 *
 */
public class Point2D extends Shape2D {
	/** the x coordinate of current location of point*/
	public double x;
	/** the y coordinate of current location of point*/
	public double y;
	/**
	 * Creates point at origin
	 */
	public Point2D(){
	}

}
