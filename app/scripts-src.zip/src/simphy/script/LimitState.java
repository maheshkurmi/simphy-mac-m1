package simphy.script;

/**
 * Enumeration for the limit states a joint can have.
 */
public enum LimitState {
	/** The state if the upper and lower limits are equal within tolerance */
	EQUAL,
	
	/** The state if the joint has reached or passed the lower limit */
	AT_LOWER,
	
	/** The state if the joint has reached or passed the upper limit */
	AT_UPPER,
	
	/** The state if the joint limits are disabled or if the joint is between the limits */
	INACTIVE;
}

