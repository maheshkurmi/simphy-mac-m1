package simphy.script;

/**
 * Implementation of a weld joint.
 * <p>
 * A weld joint joins two bodies together as if they were a single body with
 * two fixtures.  Both their relative linear and angular motion are constrained
 * to keep them attached to each other.  The system as a whole can rotate and 
 * translate freely.
 * <p>
 * Using a frequency greater than zero allows the joint to function as a
 * torsion spring about the anchor point.  A good starting point is a frequency
 * of 8.0 and damping ratio of 0.3 then adjust as necessary.
 */
public class WeldJoint extends Joint{
	/**
	 * Returns true if this distance joint is a spring distance joint.
	 * @return boolean
	 */
	public boolean isSpring() {
		return false;
	}
	
	/**
	 * Returns true if this distance joint is a spring distance joint
	 * with damping.
	 * @return boolean
	 */
	public boolean isSpringDamper() {
		return false;
	}
	
	/**
	 * Returns the damping ratio.
	 * @return double
	 */
	public double getDampingRatio() {
		return 0;
	}
	
	/**
	 * Sets the damping ratio.
	 * <p>
	 * Larger values reduce the oscillation of the spring.
	 * @param dampingRatio the damping ratio; in the range [0, 1]
	 * @throws IllegalArgumentException if damping ration is less than zero or greater than 1
	 */
	public void setDampingRatio(double dampingRatio) {
	}
	
	/**
	 * Returns the spring frequency.
	 * @return double
	 */
	public double getFrequency() {
		return 0;
	}
	
	/**
	 * Sets the spring frequency.
	 * <p>
	 * Larger values increase the stiffness of the spring.
	 * @param frequency the spring frequency in hz; must be greater than or equal to zero
	 * @throws IllegalArgumentException if frequency is less than zero
	 */
	public void setFrequency(double frequency) {
	}
	
	/**
	 * Returns the reference angle.
	 * <p>
	 * The reference angle is the angle calculated when the joint was created from the
	 * two joined bodies.  The reference angle is the angular difference between the
	 * bodies.
	 * @return double
	 */
	public double getReferenceAngle() {
		return 0;
	}
	
	/**
	 * Sets the reference angle.
	 * <p>
	 * This method can be used to set the reference angle to override the computed
	 * reference angle from the constructor.  This is useful in recreating the joint
	 * from a current state.
	 * @param angle the reference angle in radians
	 * @see #getReferenceAngle()
	 */
	public void setReferenceAngle(double angle) {
	}
}
