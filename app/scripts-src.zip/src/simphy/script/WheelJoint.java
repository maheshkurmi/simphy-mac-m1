package simphy.script;

/**
 * Implementation of a wheel joint.
 * <p>
 * A wheel joint is used to simulate a vehicle's wheel and suspension.  The 
 * wheel is allowed to rotate freely about the given anchor point.  The 
 * suspension is allowed to translate freely along the given axis.  The whole
 * system can translate and rotate freely.
 * <p>
 * By default the frequency and damping ratio are set to 8.0 and 0.0 
 * respectively.  By definition this joint requires a frequency greater than 
 * zero to perform properly.  If a wheel without suspension is required, use 
 * a {@link RevoluteJoint} instead.
 * <p>
 * This joint also supports a motor.  The motor is an angular motor about the
 * anchor point.  The motor speed can be positive or negative to indicate a
 * clockwise or counter-clockwise rotation.  The maximum motor torque must be 
 * greater than zero for the motor to apply any motion.
 */
public class WheelJoint extends Joint  {
		
	/**
	 * Returns the linear speed along the axis between the two joined bodies
	 * @return double
	 */
	public double getLinearSpeed() {
		return 0;
	}
	
	/**
	 * Returns the current angular speed between the two joined bodies.
	 * @return double
	 * @since 3.2.1
	 */
	public double getAngularSpeed() {
		return 0;
	}
		
	/**
	 * Returns the current linear translation along the joint axis.
	 * @return double
	 */
	public double getLinearTranslation() {
		return 0;
	}
	
	/**
	 * Returns the current angular translation between the joined bodies.
	 * @return double
	 */
	public double getAngularTranslation() {
		return 0;
	}

	/**
	 * Returns true if this wheel joint is a spring wheel joint.
	 * @return boolean
	 */
	public boolean isSpring() {
		return false;
	}
	
	/**
	 * Returns true if this wheel joint is a spring wheel joint
	 * with damping.
	 * @return boolean
	 */
	public boolean isSpringDamper() {
		return false;
	}
	
	/**
	 * Returns the damping ratio.
	 * @return double
	 */
	public double getDampingRatio() {
		return 0;
	}
	
	/**
	 * Sets the damping ratio.
	 * <p>
	 * Larger values reduce the oscillation of the spring.
	 * @param dampingRatio the damping ratio; in the range [0, 1]
	 * @throws IllegalArgumentException if damping ration is less than zero or greater than 1
	 */
	public void setDampingRatio(double dampingRatio) {
	}
	
	/**
	 * Returns the spring frequency.
	 * @return double
	 */
	public double getFrequency() {
		return 0;
	}
	
	/**
	 * Sets the spring frequency.
	 * <p>
	 * Larger values increase the stiffness of the spring.
	 * @param frequency the spring frequency in hz; must be greater than zero
	 * @throws IllegalArgumentException if frequency is less than or equal to zero
	 */
	public void setFrequency(double frequency) {
	}
	
	/**
	 * Returns true if the motor is enabled.
	 * @return boolean
	 */
	public boolean isMotorEnabled() {
		return false;
	}
	
	/**
	 * Enables or disables the motor.
	 * @param motorEnabled true if the motor should be enabled
	 */
	public void setMotorEnabled(boolean motorEnabled) {
	}
	
	/**
	 * Returns the target motor speed in radians / second.
	 * @return double
	 */
	public double getMotorSpeed() {
		return 0;
	}
	
	/**
	 * Sets the target motor speed.
	 * @param motorSpeed the target motor speed in radians / second
	 * @see #setMaximumMotorTorque(double)
	 */
	public void setMotorSpeed(double motorSpeed) {
	}
	
	/**
	 * Returns the maximum torque the motor can apply to the joint
	 * to achieve the target speed.
	 * @return double
	 */
	public double getMaximumMotorTorque() {
		return 0;
	}
	
	/**
	 * Sets the maximum torque the motor can apply to the joint
	 * to achieve the target speed.
	 * @param maximumMotorTorque the maximum torque in newtons-meters; in the range [0, &infin;]
	 * @throws IllegalArgumentException if maxMotorTorque is less than zero
	 * @see #setMotorSpeed(double)
	 */
	public void setMaximumMotorTorque(double maximumMotorTorque) {
	}
	
	/**
	 * Returns the applied motor torque.
	 * @param invdt the inverse delta time from the time step
	 * @return double
	 */
	public double getMotorTorque(double invdt) {
		return 0;
	}
	
	/**
	 * Returns the axis in which the joint is allowed move along in world coordinates.
	 * @return {@link Vector2}
	 */
	public Vector2 getAxis() {
		return null;
	}
	
	
	
}
