package simphy.script;

import simphy.script.geom.Circle2D;
import simphy.script.geom.Curve2D;
import simphy.script.geom.DynamicCurve2D;
import simphy.script.geom.FunctionExplicit2D;
import simphy.script.geom.Line2D;
import simphy.script.geom.ParametricCurve2D;
import simphy.script.geom.Point2D;
import simphy.script.geom.Shape2D;

public   class Geometry {
	// make it singleton
	private static Geometry instance = null;

	/**
	 * Do not allow its instance creation
	 */
	private Geometry() {

	}

	/**
	 * Return instance of this singleton class
	 * 
	 * @return 
	 */
	protected static Geometry getInstance() {
		if (instance == null) {
			instance = new Geometry();
		}
		return instance;
	}
	

	/**
	 * Returns list  of currently active shapes in simulation
	 * @return {Array} array of shapes
	 */
	public static  Shape2D[] getAllShapes() {
		return null;
	}
	

	/**
	 * Adds the specified shape to simulation
	 * @param {Shape2D} shape
	 */
	public static  void addShape(Shape2D shape) {
	}

	/**
	 * Adds the specified  shapes to simulation
	 * @param {Shape2D ...} multiple shapes or array of shapes
	 */
	public static  void addShapes(Shape2D... shapes) {
	}

	/**
	 * Remove the specified component from its parent list
	 * @param {Shape2D} shape
	 * @param widget
	 */
	public static  void removeShape(Shape2D shape) {
	}


	/**
	 * Remove the specified shapes from simulation (Note that all dependent shapes are also removed)
	 * @param {Shape2D ...} multiple shapes or array of shapes
	 */
	public static  void removeShapes(Shape2D... shapes) {
		
	}
	/**
	 * removes all shapes from the simulation
	 */
	public static  void removeAll(){
	}
	
	
	/**
	 * Returns the closest shape at specified world coordinates, returns null if no shape is found 
	 * @param {Number} x
	 * @param {Number} y
	 * @return {Shape2D}
	 */
	public static Shape2D getShapeAtPoint(double x,double y) {
		return null;
	}

	/**
	 * Returns currently selected shape (shape receiving current keyboard events)
	 * @return {Shape2D} focused shape if any else returns null
	 */
	public static  Shape2D getSelectedShape(){
		return null;
	}
	
	/**
	 * Returns first shape identified with specified name, returns null if no shape is found 
	 * @param {String} name
	 * @return {Shape2D}
	 */
	public static  Shape2D getShape(String name) {
		return null;
	}
	
	/**
	 * Returns first Point identified with specified name, returns null if no point is found with this name
	 * @param {String} name
	 * @return {Point2D}
	 */
	public static  Point2D getPoint(String name) {
		return null;
	}
	
	/**
	 * Returns first Circle identified with specified name, returns null if no circle is found with this name
	 * @param {String} name
	 * @return {Circle}
	 */
	public static  Circle2D getCircle(String name) {
		return null;
	}
	
	/**
	 * Returns first Linear shape identified with specified name, returns null if no line is found with this name
	 * @param {String} name
	 * @return {Line2D}
	 */
	public static  Line2D getLine(String name) {
		return null;
	}
	/**
	 * Returns first Curve identified with specified name, returns null if no curve is found with this name
	 * @param {String} name
	 * @return {Curve2D}
	 */
	public static  Curve2D getCurve(String name) {
		return null;
	}
	
	/**
	 * Returns first function identified with specified name, returns null if no circle is function with this name
	 * @param {String} name
	 * @return {FunctionExplicit2D}
	 */
	public static  FunctionExplicit2D getFunction(String name) {
		return null;
	}
	
	/**
	 * Returns first Paramteric Curve identified with specified name, returns null if no curve is found with this name
	 * @param {String} name
	 * @return {ParamtericCurve2D}
	 */
	public static  ParametricCurve2D getParametricCurve(String name) {
		return null;
	}
	
	/**
	 * Returns first DynamicCurve identified with specified name, returns null if no curve is found with this name
	 * @param {String} name
	 * @return {Circle}
	 */
	public static  DynamicCurve2D getDynamicCurve(String name) {
		return null;
	}
	/**
	 * Creates point from given coordinates
	 * @param x can be a number or a valid expression
	 * @param y can be a number or a valid expression
	 * @return {Point2D}
	 */
	public static  Point2D createPoint(double x, double y) {
		return null;
	}
		
	
	/**
	 * Creates point on the curve at point corresponding to specified parameter 
	 * @param curve {Curve2D} curve at which this point lies
	 * @param t {Number} parameter
	 * @return {Point2D}
	 */
	public static  Point2D createPoint(Curve2D curve, Number t) {
		return null;
	}
		
	/**
	 * Creates point from given coordinates
	 * @param body {Body}
	 * @param x {Number} x coordinate of point in local coordinates of body
	 * @param y {Number} y coordinate of point in local coordinates of body
	 * @return {Point2D}
	 */
	public static  Point2D createPoint(Body body,double x, double y) {
		return null;
	}
		
	
	/**
	 * Creates circle with center at specified point and specified radius
	 * @param center {Point2D} 
	 * @param x  {Number} x coordinate of center
	 * @param y  {Number} y coordinate of center
	 * @param r  {Number} radius of circle (must be >0)
	 * @return {Circle2D}
	 */
	public static  Circle2D createCircle(double x,double y,double r) {
		return null;
	}
	
	/**
	 * Creates circle with center at specified point and specified radius
	 * @param center {Point2D} center of circle
	 * @param r  {Number} number or an expression for the radius
	 * @return {Circle2D}
	 */
	public static  Circle2D createCircle(Point2D center,double r) {
		return null;
	}
	
	/**
	 * Creates Circle passing through 3 specified points
	 * @param p1 {Point2D}
	 * @param p2 {Point2D}
	 * @param p3 {Point2D}
	 * @return {Circle2D}
	 */
	public static  Circle2D createCircle(Point2D p1,Point2D p2,Point2D p3) {
		return null;
	}
	
	/**
	 * Creates a line through specified point and slope
	 * @param x  {Number} x coordinate of point through which line passes
	 * @param y  {Number} y coordinate of point through which line passes
	 * @param slope  {Number} slope of line
	 * @return {Line2D}
	 */
	public static  Line2D createLine(double x, double y, double slope) {
		return null;
	}
	
	/**
	 * Creates a line through 2 specified points
	 * @param pt1 {Point2D}
	 * @param pt2 {Point2D}
	 * @return {Line2D}
	 */
	public static  Line2D createLine(Point2D pt1,Point2D pt2) {
		return null;
	}
	
	/**
	 * Creates a tangent on the curve at specified pt (If pt does not lie on curve tangent is drawn on the projection of point on curve)
	 * @param curve {Curve2D}
	 * @param pt {Point2D}
	 * @return {Line2D}
	 */
	public static  Line2D createTangent(Curve2D curve,Point2D pt) {
		return null;
	}
	
	/**
	 * Creates a normal on the curve at specified pt (If pt does not lie on curve tangent is drawn on the projection of point on curve)
	 * @param curve {Curve2D}
	 * @param pt {Point2D}
	 * @return {Line2D}
	 */
	public static  Line2D createNormal(Curve2D curve,Point2D pt) {
		return null;
	}
	
	/**
	 * Creates a line Segment through 2 specified points
	 * @param pt1 {Point2D}
	 * @param pt2 {Point2D}
	 * @return {Line2D}
	 */
	public static  Line2D createLineSegment(Point2D pt1,Point2D pt2) {
		return null;
	}
	
	/**
	 * Creates a ray through 2 specified points
	 * @param pt1 {Point2D} starting point of ray
	 * @param pt2 {Point2D} 
	 * @return {Line2D}
	 */
	public static  Line2D createRay(Point2D pt1,Point2D pt2) {
		return null;
	}
	
	/**
	 * Creates a Vector through 2 specified points
	 * @param pt1 {Point2D} Starting point of vector
	 * @param pt2 {Point2D} End point of vector
	 * @return {Line2D}
	 */
	public static  Line2D createVector(Point2D pt1,Point2D pt2) {
		return null;
	}
	
	
	/**
	 * Creates an explicit function of x	
	 * @param expr {String} Expression as a function of x
	 * @return {FunctionExplict2D}
	 */
	public static  FunctionExplicit2D createFunction(String expr) {
		return null;
	}
	
	/**
	 * Creates parametric curve with parameter t ranging from 0 to 1
	 * @param xExpr {String}
	 * @param yExpr {String}
	 * @return {DynamicCurve2D}
	 */
	public static  ParametricCurve2D createParametricCurve(String xExpr, String yExpr) {
		return null;
	}
	
	/**
	 * Creates curve representing locus of specified point 
	 * @param pt {Point2D} point whose locus is to be traced
	 * @return {DynamicCurve2D}
	 */
	public static  DynamicCurve2D createLocus(Point2D pt) {
		return null;
	}
	

	
	
}
