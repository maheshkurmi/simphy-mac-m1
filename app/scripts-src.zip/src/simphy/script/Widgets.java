package simphy.script;

import simphy.script.canvas.Canvas;
import simphy.script.widgets.ActionItemWidget;
import simphy.script.widgets.Button;
import simphy.script.widgets.CheckBox;
import simphy.script.widgets.ComboBox;
import simphy.script.widgets.Desktop;
import simphy.script.widgets.Dialog;
import simphy.script.widgets.ItemWidget;
import simphy.script.widgets.Label;
import simphy.script.widgets.ListBox;
import simphy.script.widgets.Menu;
import simphy.script.widgets.MenuBar;
import simphy.script.widgets.Node;
import simphy.script.widgets.Panel;
import simphy.script.widgets.PasswordField;
import simphy.script.widgets.Plotter;
import simphy.script.widgets.ProgressBar;
import simphy.script.widgets.SelectableItemWidget;
import simphy.script.widgets.Slider;
import simphy.script.widgets.SpinBox;
import simphy.script.widgets.SplitPane;
import simphy.script.widgets.TabbedPane;
import simphy.script.widgets.Table;
import simphy.script.widgets.TextArea;
import simphy.script.widgets.TextField;
import simphy.script.widgets.ToggleButton;
import simphy.script.widgets.TreeView;
import simphy.script.widgets.Widget;
/**
 * Class to manage gui in simphy via scripting Actual gui is not exposed to
 * scripting. All gui related tasks are done through this wrapper class
 * @author mahesh
 */
public  class Widgets {
	/**
	 * Do not allow its instance creation
	 */
	private Widgets(){
		
	}
	
	/**
	 * Parse gui from XML configuration file and returns widget root widget, so make sure there is only one root widget in xml definition
	 * Note that widget is not added to gui, ti add widget call {@link #addWidget(Widget)}
	 * @param xml XML configuration file for gui definition
	 * @return {Widget} parsed widget if done successfully else null
	 * @throws SimphyScriptException 
	 */
	
	public static Widget parse(String xml) throws Exception{
		return null;
	}
	/**
	 * Adds the specified component to the root desktop
	 * 
	 * @param widget
	 */
	public static void addWidget(Widget widget) {
		
	}

	/**
	 * Remove the specified component from its parent list
	 * 
	 * @param widget
	 */
	public static void removeWidget(Widget widget) {
		
	}

	/**
	 * removes all widgets from gui except built-in toolbars and navigation bar
	 */
	public static void removeAll(){
		
	}
	
	/**
	 * Returns currently focused gui widget (widget recieving current keyboard events)
	 * @return {Widget} focused widget if any else returns null
	 */
	public static Widget getFocusedWidget(){
		return null;
	}
	
	/**
	 * Request focus for the given component
	 * @param widget {Widget} widget requesting focus
	 */
	public static void setFocusedWidget(Widget widget){
		
	}
	
	/**
	 * Sets App toolbars  visible or hidden
	 * @param index {Integer} index of toolbar [0 to 3]
	 * @param visible
	 */
	public static  void setToolBarShown(int index, boolean visible){
		
	}

	/**
	 * returns true of toolbar at specified index is visible
	 * @param index
	 * @return
	 */
	public static boolean isToolBarShown(int index) {
		return false;
	}
	
	/**
	 * Sets Navigation bar at bottom of app visible or hidden
	 * @param navBarShown
	 */
	public static  void setSimulationControlsShown(boolean navBarShown) {
		
	}
	
	/**
	 * returns true if navigation bar at bottom of app is visible
	 * @return
	 */
	public static  boolean isSimulationControlsShown() {
		return false;
	}

	/**
	 * Refreshes whole gui, should be called whenever layout needs to be calculated again ex. setting font etc
	 */
	public static void reValidateGui() {
		

	}

	/**
	 * Finds the first component from the root desktop by a specified name value
	 * 
	 * @param name
	 *            Name of the widget
	 * @return the first suitable widget, or null
	 */
	public static Widget getWidget(String name) {
		return null;
	}

	
	/**
	 * Searches Label widget in gui identified by name
	 * @param name
	 * @return {Label} widget if found else returns null
	 */
	public static Label getLabel(String name) {
		return null;
	}
	
	/**
	 * Searches Button widget in gui identified by name
	 * @param name
	 * @return {Button} widget if found else returns null
	 */
	public static Button getButton(String name) {
		return null;
	}
		
	/**
	 * Searches Slider widget in gui identified by name
	 * @param name
	 * @return {Slider} widget if found else returns null
	 */
	public static Slider getSlider(String name) {
		return null;
	}

	/**
	 * Searches Progressbar widget in gui identified by name
	 * @param name
	 * @return {Progressbar} widget if found else returns null
	 */
	public static ProgressBar getProgressBar(String name) {
		return null;
	}
	
	/**
	 * Searches Spinbox widget in gui identified by name
	 * @param name
	 * @return {Spinbox} widget if found else returns null
	 */
	public static SpinBox getSpinBox(String name) {
		return null;
	}

	/**
	 * Searches Togglebutton widget in gui identified by name
	 * @param name
	 * @return {Togglebutton} widget if found else returns null
	 */
	public static ToggleButton getToggleButton(String name) {
		return null;
	}

	/**
	 * Searches Checkbox widget in gui identified by name
	 * @param name
	 * @return {Checkbox} widget if found else returns null
	 */
	public static CheckBox getCheckBox(String name) {
		return null;
	}

	/**
	 * Searches TextField widget in gui identified by name
	 * @param name
	 * @return {TextField} widget if found else returns null
	 */
	public static TextField getTextField(String name) {
		return null;
	}

	/**
	 * Searches PasswordField widget in gui identified by name
	 * @param name
	 * @return {PasswordField} widget if found else returns null
	 */
	public static PasswordField getPasswordField(String name) {
		return null;
	}
	
	/**
	 * Searches TextArea widget in gui identified by name
	 * @param name
	 * @return {TextArea} widget if found else returns null
	 */
	public static TextArea getTextArea(String name) {
		return null;
	}
	
	/**
	 * Searches ListBox widget in gui identified by name
	 * @param name
	 * @return {ListBox} widget if found else returns null
	 */
	public static ListBox getListBox(String name) {
		return null;
	}
	
	/**
	 * Searches ComboBox widget in gui identified by name
	 * @param name
	 * @return {ComboBox} widget if found else returns null
	 */
	public static ComboBox getComboBox(String name) {
		return null;
	}
	
	/**
	 * Searches Node widget in gui identified by name
	 * @param name
	 * @return {Node} widget if found else returns null
	 */
	public static Node getNode(String name) {
		return null;
	}
	
	/**
	 * Searches TreeView widget in gui identified by name
	 * @param name
	 * @return {TreeView} widget if found else returns null
	 */
	public static TreeView getTreeView(String name) {
		return null;
	}
	
	/**
	 * Searches Table widget in gui identified by name
	 * @param name
	 * @return {Table} widget if found else returns null
	 */
	public static Table getTable(String name) {
		return null;
	}
	
	/**
	 * Searches SplitPane widget in gui identified by name
	 * @param name
	 * @return {SplitPane} widget if found else returns null
	 */
	public static Panel getPanel(String name) {
		return null;
	}
	
	/**
	 * Searches SplitPane widget in gui identified by name
	 * @param name
	 * @return {SplitPane} widget if found else returns null
	 */
	public static SplitPane getSplitPane(String name) {
		return null;
	}
	
	/**
	 * Searches TabbedPane widget in gui identified by name
	 * @param name
	 * @return {TabbedPane} widget if found else returns null
	 */
	public static TabbedPane getTabbedPane(String name) {
		return null;
	}
	
	/**
	 * Searches Dialog widget in gui identified by name
	 * @param name
	 * @return {Dialog} widget if found else returns null
	 */
	public static Dialog getDialog(String name) {
		return null;
	}
	
	/**
	 * Searches Desktop widget in gui identified by name
	 * @param name
	 * @return {Desktop} widget if found else returns null
	 */
	public static Desktop getDesktop(String name) {
		return null;
	}
	
	/**
	 * Searches MenuBar widget in gui identified by name
	 * @param name
	 * @return {MenuBar} widget if found else returns null
	 */
	public static MenuBar getMenuBar(String name) {
		return null;
	}
	
	/**
	 * Searches Menu widget in gui identified by name
	 * @param name
	 * @return {Menu} widget if found else returns null
	 */
	public static Menu getMenu(String name) {
		return null;
	}
	
	/**
	 * Searches MenuItem widget in gui identified by name
	 * @param name
	 * @return {MenuItem} widget if found else returns null
	 */
	public static ActionItemWidget getMenuItem(String name) {
		return null;
	}
	
	/**
	 * Searches Canvas widget in gui identified by name
	 * @param name
	 * @return {Canvas} widget if found else returns null
	 */
	public static Canvas getCanvas(String name) {
		return null;
	}
	
	/**
	 * Searches Plotter widget in gui identified by name
	 * @param name
	 * @return {Plotter} widget if found else returns null
	 */
	public static Plotter getPlotter(String name) {
		return null;
	}
	
	/**
	 * Returns Graph Window identified by name
	 * @param name
	 * @return {Grapher} widget if found else returns null
	 */
	public static Grapher getGraph(String name) {
		
		return null;
	}
	
	/**
	 * Returns Timer Window identified by name
	 * @param name
	 * @return {Timer} widget if found else returns null
	 */
	public static Timer getTimer(String name) {
		
		return null;
	}
	
	/**
	 * Create short one liner display for text 
	 * @param text
	 * @return
	 */
	public static ItemWidget createLabel(String text) {
		return null;
	}

	/**
	 * Creates push button with texton it
	 * @param text {String}
	 * @return
	 */
	public static Button createButton(String text) {
		return null;
	}

	/**
	 * Creates a two state push button will can toggled on or off
	 * @param text
	 * @return
	 */
	public static ToggleButton createToggleButton(String text) {
		return null;
	}
	
	/**
	 * Creates tick box that can toggled by the user to indicate an affirmative or negative choice.
	 * You can set group property for check box to behave like radio button
	 * @param text
	 * @return
	 */
	public static SelectableItemWidget createCheckBox(String text) {
		return null;
	}

	/**
	 * Creates horizontal Slider with given min and max values
	 * @param value
	 * @param min
	 * @param max
	 * @return
	 */
	public static ProgressBar createSlider(double value, double min, double max) {
		return null;
	}

	/**
	 * Creates Spinner widget which is a textbox that accepts a range of values
	 * @param value
	 * @param min
	 * @param max
	 * @return
	 */
	public static ProgressBar createSpinBox(double value, double min, double max) {
		return null;
	}

	/**
	 * creates progressbar which contains a bar visually indicating progress.
	 * @param value
	 * @param min
	 * @param max
	 * @return
	 */
	public static ProgressBar createProgressBar(double value, double min, double max) {
		return null;
	}

	/**
	 * creates one line text input box which allows the editing of a single line of text
	 * @param text
	 * @return
	 */
	public static TextField createTextField(String text) {
		return null;
	}

	/**
	 * Creates TextField component, but does not show the original characters.
	 * @param text
	 * @return
	 */
	public static TextField createPasswordField(String text) {
		return null;
	}

	/**
	 * Creates multi-line area that displays plain text, and internally handles scrolling.
	 * @param text
	 * @return
	 */
	public static TextArea createTextArea(String text) {
		return null;
	}

	/**
	 * creates list which allows the user to select one or more objects from a list, and internally handles scrolling.
	 * @return
	 */
	public static ListBox createListBox() {
		return null;
	}

	/**
	 * Creates Empty list which allows the user to select one or more objects from a list, and internally handles scrolling.
	 * @param arr {Array} array of objects to be added as items of list
	 * @return
	 */
	public static ListBox createListBox(Object[] arr) {
		return null;
	}
	
	/**
	 * Creates empty comboBox, a combination of a text field and drop-down list
	 * @return
	 */
	public static ComboBox createComboBox() {
		return null;
	}

	/**
	 * Creates ComboBox, a combination of a text field and drop-down list
	 * @param arr {Array} array of objects to be added as items in drop down list of combobox
	 * @return
	 */
	public static ComboBox createComboBox(Object[] arr) {
		return null;
	}
	
	/**
	 * Creates Panel, a container with a layout manager used to contain other elements
	 * @return
	 */
	public static Panel createPanel() {
		return null;
	}

	/**
	 * Create horizontal SplitPane which is used to divide two components with draggable divider
	 * @return
	 */
	public static SplitPane createSplitPane() {
		return null;
	}

	/**
	 * Creates draggable Dialog window
	 * @param title
	 * @return
	 */
	public static Dialog createDialog(String title) {
		return null;
	}

	/**
	 * Desktop is the root pane, it contains components (mainly panels, these fill the available space), dialogs (centered), combolists, popupmenus, and tooltips. 
	 * You can add only components and dialogs to desktop, the last will be on the top.
	 * @return
	 */
	public static Desktop createDesktop() {
		return null;
	}

	/**
	 * Creates is a horizontal or a vertical separator line. generally used in menu
	 * @return
	 */
	public static Widget createSeparator() {
		return null;
	}

	/**
	 * Creates TabbePane which has several components, such as panels, share the same space.
	 * The user chooses which component to view by selecting the tab corresponding to the desired component
	 * @return
	 */
	public static TabbedPane createTabbedPane() {
		return null;
	}

	/**
	 * Creates an empty table which presents data in a two-dimensional table format, allows to select rows, has header/column, and internally handles scrolling
	 * @return
	 */
	public static Table createTable() {
		return null;
	}

	/**
	 * /**
	 * Creates  table which presents data in a two-dimensional table format, allows to select rows, has header/column, and internally handles scrolling
	 * @param data {Array[][]} 2D array of objects to be dispalyed in table
	 * @param columns {String[]} Array with name of columns
	 * @return
	 */
	public static Table createTable(Object[][] data, String[] columns) {
		return null;
	}
	
	/**
	 * Creates Tree which displays a set of hierarchical data, contains nodes and a node could have subnodes. It internally handles scrolling	
	 * @return
	 */
	public static TreeView createTree() {
		return null;
	}

	/**
	 * Creates menu bar which can be added to top or botton of panel or dialog
	 * @return
	 */
	public static MenuBar createMenuBar() {
		return null;
	}

	/**
	 * Creates popup menu ready to be used with widgets
	 * @return
	 */
	public static Menu createPopUpMenu() {
		return null;
	}

	/*
	 * Creates new Canvas Element which has several methods for drawing over it
	 * @param name
	 * @return

	public static Canvas createCanvas(String name) {
		return null;
	}
		 */
	
	/**
	 * Converts widget to  Label if possible else returns null
	 * @param widget
	 * @return {Label} 
	 */
	public static Label asLabel(Widget widget) {
		return null;
	}
	
	/**
	 * Converts widget to  Button if possible else returns null
	 * @param widget
	 * @return {Button} 
	 */
	public static Button asButton(Widget widget) {
		return null;
	}
		
	/**
	 * Converts widget to  Slider if possible else returns null
	 * @param widget
	 * @return {Slider} 
	 */
	public static Slider asSlider(Widget widget) {
		return null;
	}

	/**
	 * Converts widget to  Progressbar if possible else returns null
	 * @param widget
	 * @return {Progressbar} 
	 */
	public static ProgressBar asProgressBar(Widget widget) {
		return null;
	}
	
	/**
	 * Converts widget to  Spinbox if possible else returns null
	 * @param widget
	 * @return {Spinbox} 
	 */
	public static SpinBox asSpinBox(Widget widget) {
		return null;
	}

	/**
	 * Converts widget to  Togglebutton if possible else returns null
	 * @param widget
	 * @return {Togglebutton} 
	 */
	public static ToggleButton asToggleButton(Widget widget) {
		return null;
	}

	/**
	 * Converts widget to  Checkbox if possible else returns null
	 * @param widget
	 * @return {Checkbox} 
	 */
	public static CheckBox asCheckBox(Widget widget) {
		return null;
	}

	/**
	 * Converts widget to  TextField if possible else returns null
	 * @param widget
	 * @return {TextField} 
	 */
	public static TextField asTextField(Widget widget) {
		return null;
	}

	/**
	 * Converts widget to  PasswordField if possible else returns null
	 * @param widget
	 * @return {PasswordField} 
	 */
	public static PasswordField asPasswordField(Widget widget) {
		return null;
	}
	
	/**
	 * Converts widget to  TextArea if possible else returns null
	 * @param widget
	 * @return {TextArea} 
	 */
	public static TextArea asTextArea(Widget widget) {
		return null;
	}
	
	/**
	 * Converts widget to  ListBox if possible else returns null
	 * @param widget
	 * @return {ListBox} 
	 */
	public static ListBox asListBox(Widget widget) {
		return null;
	}
	
	/**
	 * Converts widget to  ComboBox if possible else returns null
	 * @param widget
	 * @return {ComboBox} 
	 */
	public static ComboBox asComboBox(Widget widget) {
		return null;
	}
	
	/**
	 * Converts widget to  Node if possible else returns null
	 * @param widget
	 * @return {Node} 
	 */
	public static Node asNode(Widget widget) {
		return null;
	}
	
	/**
	 * Converts widget to  TreeView if possible else returns null
	 * @param widget
	 * @return {TreeView} 
	 */
	public static TreeView asTreeView(Widget widget) {
		return null;
	}
	
	/**
	 * Converts widget to  Table if possible else returns null
	 * @param widget
	 * @return {Table} 
	 */
	public static Table asTable(Widget widget) {
		return null;
	}
	
	/**
	 * Converts widget to  SplitPane if possible else returns null
	 * @param widget
	 * @return {SplitPane} 
	 */
	public static Panel asPanel(Widget widget) {
		return null;
	}
	
	/**
	 * Converts widget to  SplitPane if possible else returns null
	 * @param widget
	 * @return {SplitPane} 
	 */
	public static SplitPane asSplitPane(Widget widget) {
		return null;
	}
	
	/**
	 * Converts widget to  TabbedPane if possible else returns null
	 * @param widget
	 * @return {TabbedPane} 
	 */
	public static TabbedPane asTabbedPane(Widget widget) {
		return null;
	}
	
	/**
	 * Converts widget to  Dialog if possible else returns null
	 * @param widget
	 * @return {Dialog} 
	 */
	public static Dialog asDialog(Widget widget) {
		return null;
	}
	
	/**
	 * Converts widget to  Desktop if possible else returns null
	 * @param widget
	 * @return {Desktop} 
	 */
	public static Desktop asDesktop(Widget widget) {
		return null;
	}
	
	/**
	 * Converts widget to  MenuBar if possible else returns null
	 * @param widget
	 * @return {MenuBar} 
	 */
	public static MenuBar asMenuBar(Widget widget) {
		return null;
	}
	
	/**
	 * Converts widget to  Menu if possible else returns null
	 * @param widget
	 * @return {Menu} 
	 */
	public static Menu asMenu(Widget widget) {
		return null;
	}
	
	/**
	 * Converts widget to  MenuItem if possible else returns null
	 * @param widget
	 * @return {MenuItem} 
	 */
	public static ActionItemWidget asMenuItem(Widget widget) {
		return null;
	}
	
	/*
	 * Converts widget to  Canvas if possible else returns null
	 * @param widget
	 * @return {Canvas} 
	
	public static Canvas asCanvas(Widget widget) {
		return null;
	}
	 */

}
