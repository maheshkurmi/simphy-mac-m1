package simphy.script;

/**
 * Implementation of a prismatic joint.
 * <p>
 * A prismatic joint constrains the linear motion of two bodies along an axis
 * and prevents relative rotation.  The whole system can rotate and translate 
 * freely.
 * <p>
 * The initial relative rotation of the bodies will remain unchanged unless 
 * updated by calling {@link #setReferenceAngle(double)} method.  The bodies
 * are not required to be aligned in any particular way.
 * <p>
 * The world space anchor point can be any point but is typically a point on
 * the axis of allowed motion, usually the world center of either of the joined
 * bodies.
 * <p>
 * The limits are linear limits along the axis.  The limits are checked against
 * the separation of the local anchor points, rather than the separation of the
 * bodies.  This can have the effect of offsetting the limit values.  The best
 * way to describe the effect is to examine the "0 to 0" limit case.  This case
 * specifies that the bodies should not move along the axis, forcing them to 
 * stay at their <em>initial location</em> along the axis.  So if the bodies 
 * were initially separated when they were joined, they will stay separated at
 * that initial distance.
 * <p>
 * This joint also supports a motor.  The motor is a linear motor along the
 * axis.  The motor speed can be positive or negative to indicate motion along
 * or opposite the axis direction.  The maximum motor force must be greater 
 * than zero for the motor to apply any motion.
 */
public class PrismaticJoint extends Joint  {
	
	/**
	 * Returns the current joint speed.
	 * @return double
	 */
	public double getJointSpeed() {
		return 0;
	}
	
	/**
	 * Returns the current joint translation.
	 * @return double
	 */
	public double getJointTranslation() {
		return 0;
	}
	
	/**
	 * Returns true if the motor is enabled.
	 * @return boolean
	 */
	public boolean isMotorEnabled() {
		return false;
	}
	
	/**
	 * Enables or disables the motor.
	 * @param motorEnabled true if the motor should be enabled
	 */
	public void setMotorEnabled(boolean motorEnabled) {
	}
	
	/**
	 * Returns the target motor speed in meters / second.
	 * @return double
	 */
	public double getMotorSpeed() {
		return 0;
	}
	
	/**
	 * Sets the target motor speed.
	 * @param motorSpeed the target motor speed in meters / second
	 * @see #setMaximumMotorForce(double)
	 */
	public void setMotorSpeed(double motorSpeed) {
		
	}
	
	/**
	 * Returns the maximum force the motor can apply to the joint
	 * to achieve the target speed.
	 * @return double
	 */
	public double getMaximumMotorForce() {
		return 0;
	}
	
	/**
	 * Sets the maximum force the motor can apply to the joint
	 * to achieve the target speed.
	 * @param maximumMotorForce the maximum force in newtons; must be greater than zero
	 * @throws IllegalArgumentException if maxMotorForce is less than zero
	 * @see #setMotorSpeed(double)
	 */
	public void setMaximumMotorForce(double maximumMotorForce) {
	}
	
	/**
	 * Returns the applied motor force.
	 * @param invdt the inverse delta time
	 * @return double
	 */
	public double getMotorForce(double invdt) {
		return 0;
	}
	
	/**
	 * Returns true if the limit is enabled.
	 * @return boolean
	 */
	public boolean isLimitEnabled() {
		return false;
	}
	
	/**
	 * Enables or disables the limits.
	 * @param limitEnabled true if the limit should be enabled.
	 */
	public void setLimitEnabled(boolean limitEnabled) {
	}
	
	/**
	 * Returns the lower limit in meters.
	 * @return double
	 */
	public double getLowerLimit() {
		return 0;
	}
	
	/**
	 * Sets the lower limit.
	 * @param lowerLimit the lower limit in meters
	 * @throws IllegalArgumentException if lowerLimit is greater than the current upper limit
	 */
	public void setLowerLimit(double lowerLimit) {
	
	}
	
	/**
	 * Returns the upper limit in meters.
	 * @return double
	 */
	public double getUpperLimit() {
		return 0;
	}

	/**
	 * Sets the upper limit.
	 * @param upperLimit the upper limit in meters
	 * @throws IllegalArgumentException if upperLimit is less than the current lower limit
	 */
	public void setUpperLimit(double upperLimit) {
		
	}
	
	/**
	 * Sets the upper and lower limits.
	 * <p>
	 * The lower limit must be less than or equal to the upper limit.
	 * @param lowerLimit the lower limit in meters
	 * @param upperLimit the upper limit in meters
	 * @throws IllegalArgumentException if lowerLimit is greater than upperLimit
	 */
	public void setLimits(double lowerLimit, double upperLimit) {
		
	}
	
	/**
	 * Sets the upper and lower limits and enables the limits.
	 * <p>
	 * The lower limit must be less than or equal to the upper limit.
	 * @param lowerLimit the lower limit in meters
	 * @param upperLimit the upper limit in meters
	 * @throws IllegalArgumentException if lowerLimit is greater than upperLimit
	 */
	public void setLimitsEnabled(double lowerLimit, double upperLimit) {
		
	}
	
	/**
	 * Returns the axis in which the joint is allowed move along in world coordinates.
	 * @return {@link Vector2}
	 */
	public Vector2 getAxis() {
		return null;
	}
	
	/**
	 * Returns the reference angle.
	 * <p>
	 * The reference angle is the angle calculated when the joint was created from the
	 * two joined bodies.  The reference angle is the angular difference between the
	 * bodies.
	 * @return double
	 */
	public double getReferenceAngle() {
		return 0;
	}
	
	/**
	 * Sets the reference angle.
	 * <p>
	 * This method can be used to set the reference angle to override the computed
	 * reference angle from the constructor.  This is useful in recreating the joint
	 * from a current state.
	 * <p>
	 * This can also be used to override the initial angle between the bodies.
	 * @param angle the reference angle
	 * @see #getReferenceAngle()
	 */
	public void setReferenceAngle(double angle) {
		
	}

	/**
	 * Returns the current state of the limit.
	 * @return {@link LimitState}
	 */
	public LimitState getLimitState() {
		return null;
	}
	

}
