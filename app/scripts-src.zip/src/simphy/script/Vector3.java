package simphy.script;



/**
 * This class represents a vector or point in 3D space.
 * <p>
 * Used to solve 3x3 systems of equations.
 * @see Vector2
 * @since 1.2.0
 */
public class Vector3 {
	/** The magnitude of the x component of this {@link Vector3} */
	public float x;
	
	/** The magnitude of the y component of this {@link Vector3} */
	public float y;
	
	/** The magnitude of the z component of this {@link Vector3} */
	public float z;
	
	/** Default constructor. */
	public Vector3() {}

	/**
	 * Copy constructor.
	 * @param vector the {@link Vector3} to copy from
	 */
	public Vector3(Vector3 vector) {
		this.x = vector.x;
		this.y = vector.y;
		this.z = vector.z;
	}
	
	/**
	 * Optional constructor.
	 * @param x the x component
	 * @param y the y component
	 * @param z the z component
	 */
	public Vector3(float x, float y, float z) {
		this.x = x;
		this.y = y;
		this.z = z;
	}


	/**
	 * Returns a copy of this vector. If a target vector is specified then this
	 * vector is copied into this target vector. If it is null then a new
	 * fresh vector is created.
	 * 
	 * @param {Vector3} target
	 *            Optional target vector, can be null
	 * @return {Vector3} A copy of this vector
	 */
	public Vector3 copy(Vector3 target) {
		return null;
	}
	
	/**
	 * Sets this {@link Vector3} to the given {@link Vector3}.
	 * @param vector the {@link Vector3} to set this {@link Vector3} to
	 * @return {@link Vector3} this vector
	 */
	public Vector3 set(Vector3 vector) {
		return null;
	}
	
	/**
	 * Sets this {@link Vector3} to the given {@link Vector3}.
	 * @param x the x component of the {@link Vector3} to set this {@link Vector3} to
	 * @param y the y component of the {@link Vector3} to set this {@link Vector3} to
	 * @param z the z component of the {@link Vector3} to set this {@link Vector3} to
	 * @return {@link Vector3} this vector
	 */
	public Vector3 set(float x, float y, float z) {
		return null;
	}
	

	
	/**
	 * Returns the distance from this point to the given point.
	 * @param x the x coordinate of the point
	 * @param y the y coordinate of the point
	 * @param z the z coordinate of the point
	 * @return float
	 */
	public float distance(float x, float y, float z) {
		return 0;
	}
	
	/**
	 * Returns the distance from this point to the given point.
	 * @param point the point
	 * @return float
	 */
	public float distance(Vector3 point) {
		return 0;
	}
	
	
	/**
	 * Returns the distance from this point to the given point squared.
	 * @param point the point
	 * @return float
	 */
	public float distanceSquared(Vector3 point) {
		return 0;
	}
	


	/**
	 * Returns true if the x, y and z components of this {@link Vector3}
	 * are the same as the given x, y and z components.
	 * @param x the x coordinate of the {@link Vector3} to compare to
	 * @param y the y coordinate of the {@link Vector3} to compare to
	 * @param z the z coordinate of the {@link Vector3} to compare to
	 * @return boolean
	 */
	public boolean equals(float x, float y, float z) {
		return this.x == x && this.y == y && this.z == z;
	}
	
	
	/**
	 * Returns the magnitude of this {@link Vector3}.
	 * @return float
	 */
	public float getMagnitude() {
		// the magnitude is just the pathagorean theorem
		return 0;
	}
	
	/**
	 * Returns the magnitude of this {@link Vector3} squared.
	 * @return float
	 */
	public float getMagnitudeSquared() {
		return 0;
	}
	
	/**
	 * Sets the magnitude of the {@link Vector3}.
	 * @param magnitude  the magnitude
	 * @return {@link Vector3} this vector
	 */
	public Vector3 setMagnitude(float magnitude) {
		return this;
	}
	
	/**
	 * Adds the given {@link Vector3} to this {@link Vector3}.
	 * @param vector the {@link Vector3}
	 * @return {@link Vector3} this vector
	 */
	public Vector3 add(Vector3 vector) {
		return this;
	}
	
	/**
	 * Adds the given {@link Vector3} to this {@link Vector3}.
	 * @param x the x component of the {@link Vector3}
	 * @param y the y component of the {@link Vector3}
	 * @param z the z component of the {@link Vector3}
	 * @return {@link Vector3} this vector
	 */
	public Vector3 add(float x, float y, float z) {
		return this;
	}
	
	/**
	 * Adds this {@link Vector3} and the given {@link Vector3} returning
	 * a new {@link Vector3} containing the result.
	 * @param vector the {@link Vector3}
	 * @return {@link Vector3}
	 */
	public Vector3 sum(Vector3 vector) {
		return null;
	}
	
	/**
	 * Adds this {@link Vector3} and the given {@link Vector3} returning
	 * a new {@link Vector3} containing the result.
	 * @param x the x component of the {@link Vector3}
	 * @param y the y component of the {@link Vector3}
	 * @param z the z component of the {@link Vector3}
	 * @return {@link Vector3}
	 */
	public Vector3 sum(float x, float y, float z) {
		return null;
	}
	
	/**
	 * Subtracts the given {@link Vector3} from this {@link Vector3}.
	 * @param vector the {@link Vector3}
	 * @return {@link Vector3} this vector
	 */
	public Vector3 subtract(Vector3 vector) {
		return null;
	}
	
	/**
	 * Subtracts the given {@link Vector3} from this {@link Vector3}.
	 * @param x the x component of the {@link Vector3}
	 * @param y the y component of the {@link Vector3}
	 * @param z the z component of the {@link Vector3}
	 * @return {@link Vector3} this vector
	 */
	public Vector3 subtract(float x, float y, float z) {
		return this;
	}
	
	/**
	 * Subtracts the given {@link Vector3} from this {@link Vector3} returning
	 * a new {@link Vector3} containing the result.
	 * @param vector the {@link Vector3}
	 * @return {@link Vector3}
	 */
	public Vector3 difference(Vector3 vector) {
		return null;
	}
	
	/**
	 * Subtracts the given {@link Vector3} from this {@link Vector3} returning
	 * a new {@link Vector3} containing the result.
	 * @param x the x component of the {@link Vector3}
	 * @param y the y component of the {@link Vector3}
	 * @param z the z component of the {@link Vector3}
	 * @return {@link Vector3}
	 */
	public Vector3 difference(float x, float y, float z) {
		return null;
	}
	
	/**
	 * Creates a {@link Vector3} from this {@link Vector3} to the given {@link Vector3}.
	 * @param vector the {@link Vector3}
	 * @return {@link Vector3}
	 */
	public Vector3 to(Vector3 vector) {
		return null;
	}
	
	/**
	 * Creates a {@link Vector3} from this {@link Vector3} to the given {@link Vector3}.
	 * @param x the x component of the {@link Vector3}
	 * @param y the y component of the {@link Vector3}
	 * @param z the z component of the {@link Vector3}
	 * @return {@link Vector3}
	 */
	public Vector3 to(float x, float y, float z) {
		return null;
	}
		
	/**
	 * Multiplies this {@link Vector3} by the given scalar.
	 * @param scalar the scalar
	 * @return {@link Vector3} this vector
	 */
	public Vector3 multiply(float scalar) {
		return this;
	}
	
	/**
	 * Multiplies this {@link Vector3} by the given scalar returning
	 * a new {@link Vector3} containing the result.
	 * @param scalar the scalar
	 * @return {@link Vector3}
	 */
	public Vector3 product(float scalar) {
		return null;
	}
	
	/**
	 * Returns the dot product of the given {@link Vector3}
	 * and this {@link Vector3}.
	 * @param vector the {@link Vector3}
	 * @return float
	 */
	public float dot(Vector3 vector) {
		return 0;
	}
	
	/**
	 * Returns the dot product of the given {@link Vector3}
	 * and this {@link Vector3}.
	 * @param x the x component of the {@link Vector3}
	 * @param y the y component of the {@link Vector3}
	 * @param z the z component of the {@link Vector3}
	 * @return float
	 */
	public float dot(float x, float y, float z) {
		return 0;
	}
	
	/**
	 * Returns the cross product of the this {@link Vector3} and the given {@link Vector3}.
	 * @param vector the {@link Vector3}
	 * @return {@link Vector3}
	 */
	public Vector3 cross(Vector3 vector) {
		return null;
	}
	
	/**
	 * Returns the cross product of the this {@link Vector3} and the given {@link Vector3}.
	 * @param x the x component of the {@link Vector3}
	 * @param y the y component of the {@link Vector3}
	 * @param z the z component of the {@link Vector3}
	 * @return {@link Vector3}
	 */
	public Vector3 cross(float x, float y, float z) {
		return null;
	}
	
	/**
	 * Returns true if the given {@link Vector3} is orthogonal (perpendicular)
	 * to this {@link Vector3}.
	 * <p>
	 * If the dot product of this vector and the given vector is
	 * zero then we know that they are perpendicular
	 * @param vector the {@link Vector3}
	 * @return boolean
	 */
	public boolean isOrthogonal(Vector3 vector) {
		return false;
	}
	
	/**
	 * Returns true if the given {@link Vector3} is orthogonal (perpendicular)
	 * to this {@link Vector3}.
	 * <p>
	 * If the dot product of this vector and the given vector is
	 * zero then we know that they are perpendicular
	 * @param x the x component of the {@link Vector3}
	 * @param y the y component of the {@link Vector3}
	 * @param z the z component of the {@link Vector3}
	 * @return boolean
	 */
	public boolean isOrthogonal(float x, float y, float z) {
		return  false;
	}
	
	/**
	 * Returns true if this {@link Vector3} is the zero {@link Vector3}.
	 * @return boolean
	 */
	public boolean isZero() {
		return false;
	}

	/** 
	 * Negates this {@link Vector3}.
	 * @return {@link Vector3} this vector
	 */
	public Vector3 negate() {
		return this;
	}
	
	/**
	 * Returns a {@link Vector3} which is the negative of this {@link Vector3}.
	 * @return {@link Vector3}
	 */
	public Vector3 getNegative() {
		return null;
	}
	
	/**
	 * Returns a unit {@link Vector3} of this {@link Vector3}.
	 * <p>
	 * This method requires the length of this {@link Vector3} is not zero.
	 * @return {@link Vector3}
	 */
	public Vector3 getNormalized() {
		return null;
	}
	
	/**
	 * Converts this {@link Vector3} into a unit {@link Vector3} and returns
	 * the magnitude before normalization.
	 * <p>
	 * This method requires the length of this {@link Vector3} is not zero.
	 * @return float
	 */
	public float normalize() {
		return 0;
	}
	


}
