package simphy.script.widgets;

/**
 * Wrapper Widget for [slider, Progressbar, SpinBox]
 * @author mahesh
 *
 */
public class SpinBox extends ProgressBar{

	
	@Override
	public void setStep(double step){
		
	}
	
	@Override
	public double getStep(){
		return 0;
	}
	

}
