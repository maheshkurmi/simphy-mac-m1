package simphy.script.widgets;
/**
 * Wrapper class for ToggleButton, RadioButton, Checkbox, Item(list), checkboxmenuItem
 * @author mahesh
 *
 */
public class SelectableItemWidget extends ActionItemWidget{

	
	
	/**
	 * Sets selected/checked state of the widget
	 * @param selected
	 */
	public void setSelected(boolean selected){
	
	}
	
	/**
	 * returns true if widget is in selected/checked state
	 * @return
	 */
	public boolean isSelected(){
		return true;
	}

	/**
	 * Sets selected/checked state of widget
	 * @param value
	 */
	public void setValue(boolean value){
		
	}
	
	/**
	 * returns true if widget is selected/checked
	 * @return
	 */
	public Object getValue(){
		return true;
	}
}
