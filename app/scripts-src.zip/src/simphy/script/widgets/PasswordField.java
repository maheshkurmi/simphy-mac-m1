package simphy.script.widgets;

/**
 * 
 * @author mahesh
 *
 */
public class PasswordField extends TextField{

	
	
}
