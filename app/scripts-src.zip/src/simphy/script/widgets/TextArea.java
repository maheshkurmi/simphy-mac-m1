package simphy.script.widgets;

/**
 * 
 * @author mahesh
 *
 */
public class TextArea extends TextField{



	/**
	 * If set to true the lines will be wrapped at word boundaries (whitespace) if they are too long to fit within the allocated width.
	 */
	public boolean isWrap(){
		return true;
	}
	
	/**
	 * If set to true the lines will be wrapped at word boundaries (whitespace) if they are too long to fit within the allocated width.
	 *@param wrap
	 */
	public void setWrap(boolean wrap){
		
	}
	
	
	/**
	 * The number of visible rows for this textarea.
	 * @param rows
	 */
	public void setRows(int rows){
		
	}
	
	/**
	 * returns The number of visible rows for this textarea.
	 */
	public int getRows(){
		return 0;
	}
	
	/**
	 * returns Start index of the selection.
	 */
	public int getStart(){
		return 0;
	}
	
	
	/**
	 * returns end index of the selection.
	 */
	public int getEnd(){
		return 0;
	}
	
	/**
	 * Sets selection in text
	 */
	public void setSelection(int start, int end){
		
	}
	
	
	/**
	 * Sets if the combobox has an editable field
	 * @param lines {Boolean} 
	 */
	public void setEditable(boolean editable){
		
	}
	
	/**
	 * return true if the combobox has an editable field
	 */
	public boolean isEditable(){
		return true;
 	}
	
	@Override
	public void setOnPerform(String methodText){
		
	}
 
	/**
	 * Returns method text associated with 'action' for this widget
	 * @return Method Text if assigned else null
	 */
	@Override
	public String getOnPerform(){
		return null;
	}
	
 
}
