package simphy.script.widgets;
  
public class TreeView extends Widget{
    	
    	/**
    	 * Ensures that the node is expanded if true, otherwise collapsed.
    	 * @param expanded
    	 */
    	public void setExpanded(int index, boolean expanded){
    		
    	}
    	
    	/**
    	 * returns true if the node is expanded, otherwise false.
    	 * @return {boolean}
    	 */
    	public boolean getExpanded(int index){
    		return false;
    	}
    	
    	/**
    	 * Sets selection mode of this tree
    	 *  For the default single value the selection can only contain one path at a time, 
    	 *  for interval the selection can only be contiguous (of the currently visible nodes), and for the multiple value the selection can contain any number of nodes that are not necessarily contiguous.
    	 * @param multiSelect single|interval|multiple
    	 */
    	public void setSelectionMode(String multiSelect){
    		
    	}
    	
    	/**
    	 * Returns selection mode of this tree
    	 * @return
    	 */
    	public String getSelectionMode(){
    		return null;
    	}
  
      	/**
    	 * Sets if lines are drawn separating the list items.
    	 * @param lines {Boolean} separator lines are drawn if true
    	 */
    	public void setDrawSeparatorLines(boolean lines){
    		
    	}
    	
    	/**
    	 * return if lines are drawn separating the list items.
    	 */
    	public boolean isDrawSeparatorLines(){
    		return false;
     	}

      	/**
    	 * To specify to draw lines detailing the relationships between nodes.
    	 * @param angles {Boolean} separator lines are drawn if true
    	 */
    	public void setAnglesDrawn(boolean angles){
    		
    	}
    	
    	/**
    	 * return true if lines detailing the relationships between nodes are drawn
    	 */
    	public boolean isAnglesDrawn(){
    		return false;
     	}

      	 /**
         * Returns the currently selected index for this tree.
         * Returns -1 if there is no currently selected tab.
         *
         * @return the index of the selected tab
         * @see #setSelectedIndex
         */
       	public int getSelectedIndex(){
       		return 0;
    	}
    	
       
        /**
         * Sets the selected index for this tree. The index must be
         * a valid tab index 
         * @param index  the index to be selected
         * @exception IndexOutOfBoundsException if index is out of range
         *            {@code (index < -1 || index >= tab count)}
         * @return active tab index (0 corresponds to first tab, 1 corresponds to secos tab and so on..)
    	 */
    	public void setSelectedIndex(int index){
    	}
    	
    	/**
    	 * Returns first selected Node
    	 * @return
    	 */
    	public Node getSelectedNode(){
       		
    		return null;
    	}
    	
  
       	/**
       	 * Returns nodes at top level of this tree at specified index
       	 * @return
       	 * @see getAllNodes()
       	 */
    	public Node getNodeAtIndex(int index){
    		return null;
    	}
    	
    	
    	/**
       	 * Returns nodes at top level of this  tree
       	 * Other roots can be obtained by calling getAllNodes at recursively at subnodes
       	 * @return
       	 * @see getNodeAtIndex()
       	 */
    	public Node[] getAllNodes(){
    		return null;
    	}
    	
    	
    	
    	/**
    	 * Add new Node to the top level of this tree
    	 * @param text
    	 * @return
    	 */
    	public Node addNode(Object value){
    		return addNode(value,null);
    	}
    	
    	/**
    	 * Add new Node to the top level of this tree
    	 * @param text
    	 * @param icon
    	 * @return
    	 */
    	public Node addNode(Object value, String icon){
    		return null;
    	}
    	
    	/**
    	 * Removes Node at top level of this tree at specified index, along with all its child nodes
    	 * @param index
    	 */
    	public void removeNode(int index){
    		
    	}

    	/**
    	 * Removes all Nodes contained in this tree along with all their children
     	 */
    	public void removeAll(){
    		
     	}

    	/**
    	 * Sets method to be invoked whenever node is clicked <br>
    	 * @param methodText {String} method in specific format as <strong> MethodName(parameters) </strong>
    	 * <h3>MathodName:</h3> Name of Global method already defined in script
    	 * <h3>parameters:</h3> The event description may contain parameters (in brackets, separated by comma or whitespace characters) as follows:
    	 * <ul>
    	 * <li> <b> this </b> =The source widget (the object on which the event occurred)
    	 * <li> <b> widget name </b> =Another widget in gui identified by the given name
    	 * <li> <b> item </b> =The component part on which the event occurred, valid for list item, tree node, table row, combobox choice, and tabbedpane tab
    	 * <li> <b> this/name/item .attribute </b> =component's or item's attribute value, defined by the this, widget name, or item string, dot, and the attribute key. 
    			Ex. <code> onSelectionChange(this, item.text, this.value) </code>
    	 * <li> <b> constant string </b> =The source widget (the object on which the event occurred)
    	 * <li> <b> constant value </b> =The source widget (the object on which the event occurred)
    	 * <li> <b> constant number </b> =Long numbers end with 'L' character (it ignors case), floats width 'F', doubles have to include a dot character, otherwise it is expected as integer.	 * </ul>
    	 */
    	public void setAction(String methodText) {
    	}

      	/**
    	 * Returns method text associated with event method 'onAction' for this widget
    	 * 
    	 * @return Method Text if assigned else null
    	 */
    	public String getAction() {
    		return "";
    	}
    	/**
    	 * Sets method to be invoked when a node is double clicked <br>
    	 * @param methodText {String} method in specific format as <strong> MethodName(parameters) </strong>
    	 * <h3>MathodName:</h3> Name of Global method already defined in script
    	 * <h3>parameters:</h3> The event description may contain parameters (in brackets, separated by comma or whitespace characters) as follows:
    	 * <ul>
    	 * <li> <b> this </b> =The source widget (the object on which the event occurred)
    	 * <li> <b> widget name </b> =Another widget in gui identified by the given name
    	 * <li> <b> item </b> =The component part on which the event occurred, valid for list item, tree node, table row, combobox choice, and tabbedpane tab
    	 * <li> <b> this/name/item .attribute </b> =component's or item's attribute value, defined by the this, widget name, or item string, dot, and the attribute key. 
    			Ex. <code> onSelectionChange(this, item.text, this.value) </code>
    	 * <li> <b> constant string </b> =The source widget (the object on which the event occurred)
    	 * <li> <b> constant value </b> =The source widget (the object on which the event occurred)
    	 * <li> <b> constant number </b> =Long numbers end with 'L' character (it ignors case), floats width 'F', doubles have to include a dot character, otherwise it is expected as integer.	 * </ul>
    	 */
    	public void setOnPerform(String methodText){
    	}
     
    	/**
    	 * Returns method text associated with 'action' for this widget
    	 * @return Method Text if assigned else null
    	 */
    	public String getOnPerform(){
    		return null;
    	}
 
     	/**
    	 * Sets method to be invoked whenever a node in the tree has been collapsed. <br>
    	 * @param methodText {String} method in specific format as <strong> MethodName(parameters) </strong>
    	 * <h3>MathodName:</h3> Name of Global method already defined in script
    	 * <h3>parameters:</h3> The event description may contain parameters (in brackets, separated by comma or whitespace characters) as follows:
    	 * <ul>
    	 * <li> <b> this </b> =The source widget (the object on which the event occurred)
    	 * <li> <b> widget name </b> =Another widget in gui identified by the given name
    	 * <li> <b> item </b> =The component part on which the event occurred, valid for list item, tree node, table row, combobox choice, and tabbedpane tab
    	 * <li> <b> this/name/item .attribute </b> =component's or item's attribute value, defined by the this, widget name, or item string, dot, and the attribute key. 
    			Ex. <code> onSelectionChange(this, item.text, this.value) </code>
    	 * <li> <b> constant string </b> =The source widget (the object on which the event occurred)
    	 * <li> <b> constant value </b> =The source widget (the object on which the event occurred)
    	 * <li> <b> constant number </b> =Long numbers end with 'L' character (it ignors case), floats width 'F', doubles have to include a dot character, otherwise it is expected as integer.	 * </ul>
    	 */
    	public void setOnCollapse(String methodText){
    	}
     
    	/**
    	 * Returns method text associated with 'collapse' which is invoked whenever a node in the tree has been collapsed.
    	 * @return Method Text if assigned else null
    	 */
    	public String getOnCollapse(){
    		return null;
    	}
    	
    	/**
    	 * Sets method to be invoked when the tree expands a node.  <br>
    	 * @param methodText {String} method in specific format as <strong> MethodName(parameters) </strong>
    	 * <h3>MathodName:</h3> Name of Global method already defined in script
    	 * <h3>parameters:</h3> The event description may contain parameters (in brackets, separated by comma or whitespace characters) as follows:
    	 * <ul>
    	 * <li> <b> this </b> =The source widget (the object on which the event occurred)
    	 * <li> <b> widget name </b> =Another widget in gui identified by the given name
    	 * <li> <b> item </b> =The component part on which the event occurred, valid for list item, tree node, table row, combobox choice, and tabbedpane tab
    	 * <li> <b> this/name/item .attribute </b> =component's or item's attribute value, defined by the this, widget name, or item string, dot, and the attribute key. 
    			Ex. <code> onSelectionChange(this, item.text, this.value) </code>
    	 * <li> <b> constant string </b> =The source widget (the object on which the event occurred)
    	 * <li> <b> constant value </b> =The source widget (the object on which the event occurred)
    	 * <li> <b> constant number </b> =Long numbers end with 'L' character (it ignors case), floats width 'F', doubles have to include a dot character, otherwise it is expected as integer.	 * </ul>
    	 */
    	public void setOnExpand(String methodText){
     	}
     
    	/**
    	 * Returns method text associated with 'collapse' which is invoked when the tree expands a node. 
    	 * @return Method Text if assigned else null
    	 */
    	public String getOnExpand(){
    		return null;
    	}
    }
