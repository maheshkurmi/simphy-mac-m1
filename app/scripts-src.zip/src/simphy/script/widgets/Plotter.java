package simphy.script.widgets;

public  class Plotter {
	/**
	 * Set expressions for each component
	 * 
	 * @param expr Expression in terms of variable x (for multiple plots use ";" as separator) <br>
	 * 			ex:<code> sin(x); x*x </code> will insert two graphs one for sin(x) and other for x*x
	 * @param clearPrevious if true all previous graphs are removed 
	 */
	public void setExpression(String expr,boolean clearPrevious){
	}

	/**
	 * Returns text associated with the plotter used to create expressions
	 * @return
	 */
	public String getExpr(){
		return null;
	}
	
	
	/**
	 * Adds Graph as an explicit function of x
	 * @param expression {String} Explicit function of x ex, x*sin(x) etc
	 * @param lineWidth{Number} lineWidth in pixels (must be >=1}
	 * @param color {Color|String} Color Object or css color string  ex.<br>
	 * 	<ol> 
	 * 	<li> Common color name "red", "green" </li>
	 *	<li> Hexadecimal representation of color such as #FF0096 or 0xFF0096 </li>
	 * 	<li> Color functions "rgb(255,0,0)","hsl(180, 50%, 50%)","rgba(255,255,120,1)" </li>
	 * @see #setUnits(String, String, int)
	 * @return {int}  the series index if added succesfully else returns -1
	 */
	public int addGraph(String expr,double lineWidth, Object color) {
		return -1;
	}
	
	/**
	 * Adds a new series to the list of series.
	 * @param name {String} identifier name of chart
	 * @param lineWidth{Number} lineWidth in pixels (must be >=1}
	 * @param color {Color|String} Color Object or css color string  ex.<br>
	 * 	<ol> 
	 * 	<li> Common color name "red", "green" </li>
	 *	<li> Hexadecimal representation of color such as #FF0096 or 0xFF0096 </li>
	 * 	<li> Color functions "rgb(255,0,0)","hsl(180, 50%, 50%)","rgba(255,255,120,1)" </li>
	 * @see #setUnits(String, String, int)
	 * @return int the series index
	 */
	public int addLineChart(String name,double lineWidth, Object color) {
		return 0;
	}
	
	/**
	 * Adds a new series to the list of series.
	 * @param name {String} identifier name of chart
	 * @param barPercentage {Number} fraction (0-1) of the available width each bar should be drawn
	 * @param color {Color|String} Color Object or css color string  ex.<br>
	 * 	<ol> 
	 * 	<li> Common color name "red", "green" </li>
	 *	<li> Hexadecimal representation of color such as #FF0096 or 0xFF0096 </li>
	 * 	<li> Color functions "rgb(255,0,0)","hsl(180, 50%, 50%)","rgba(255,255,120,1)" </li>
	 * @see #setUnits(String, String, int)
	 * @return int the series index
	 */
	public int addBarChart(String name,double barPercentage, Object color) {
		return 0;
	}
	
	/**
	 * Adds a new series to the list of series.
	 * @param name {String} identifier name of chart
	 * @param radiusPixel {Radius in pixels}
	 * @param joinLines {boolean} if true bubbles are connected by lines
	 * @param color {Color|String} Color Object or css color string  ex.<br>
	 * 	<ol> 
	 * 	<li> Common color name "red", "green" </li>
	 *	<li> Hexadecimal representation of color such as #FF0096 or 0xFF0096 </li>
	 * 	<li> Color functions "rgb(255,0,0)","hsl(180, 50%, 50%)","rgba(255,255,120,1)" </li>
	 * @see #setUnits(String, String, int)
	 * @return int the series index
	 */
	public int addBubbleChart(String name,int radiusPixel,boolean joinLines, Object color) {
		return 0;
	}
	
	/**
	 * Adds a new data point to the plot.
	 * @param yvalue the value of the data point
	 * @param xvalue the value of the data point
	 * @param plotIndex the index of plot added to this plotter
	 * 
	 * does't add if either value is NaN
	 */
	public void addDataPoint(double xValue,double yValue, int plotIndex) {
	}
	
	/**
	 * Adds format string corresponding to charts
	 * @param Unit for xAxis  
	 * @param Unit for yAxis  
	 */
	public void setUnits(String xUnit,String yUnit){
	}


	/**
	 * Resets all charts associated with the plot , Note that it does't remove charts,
	 * to acually remove charts use {@link #clearAll()}
	 * @param index
	 * @param visible
	 * @see resetCharts
	 */
	public void reset(){
	}
	
	/**
	 * Removes all points for the series
	 * @param index index of chart to be reset
	 */
	public void resetChart(int index){
	}
	

	/**
	 * sets Chart Visible
	 * @param index index of chart which is set to visible
	 * @param visible
	 */
	public void setChartVisible(int index,boolean visible){
	}
	
	/**
	 * Removes all points for the chart
	 * @param index index of chart to remove
	 */
	public void removeChart(int index){
	}
	
	/**
	 * removes all charts 
	 */
	public void clearAll(){
	}
	
	
	/**
	 * Calculate min and max value in each direction for cumulative data
	 */
	private void calculateMinMaxValue(){
	}
	

	/**
	 * Zooms In by 5%
	 */
	public void zoomIn(){
	}
	
	/**
	 * Zooms Out by 5%
	 */
	public void zoomOut(){
	}
	
	/**
	 * sets zoom factor
	 * @param zoom must be >0
	 */
	public void setZoom(double zoom){
	}
	
	/**
	 * returns current zoom factor
	 */
	public double getZoom(){
		return 0;
	}
	
	/**
	 * returns current factor used to convert chart coordinates to screen coordinates
	 * @return
	 */
	public double getScaleFactor() {
		return 0;
	}
	
	/**
	 * Sets scales to make sure all charts are just fully visible and sets zoom factor as unity
	 * @see #setZoom(double)
	 */
	public void scaleToFit() {
	
	}
	
	
	
	/**
	 * Sets Text for the plotter, whcih can be used to add graphs to it
	 * @param {String} set of plottable math expressions as a function of x and searated by ;
	 */
	public void setText(String string) {
		this.setExpression(string, true);
		//scaleToFit();
	}

	public boolean isAxisLabled() {
		return false;
	}


	public void setAxisLabled(boolean showInfo) {
	}


	public boolean isGridsShown() {
		return false;
	}


	public void setGridsShown(boolean showGrids) {
	}

	public boolean isAxisShown() {
		return false;
	}


	public void setAxisShown(boolean showAxis) {
	}

	public boolean isLegendsShown() {
		return false;
	}


	public void setLegendsShown(boolean showLegends) {
	}

}