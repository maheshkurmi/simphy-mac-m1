package simphy.script.widgets;


/**
 * 
 * @author mahesh
 *
 */
public class TextField extends ItemWidget{


	/**
	 * The number of visible letters in a column.
	 * @param columns
	 */
	public void setColumns(int columns){
		
	}
	
	/**
	 * return the number of visible letters in a column.
	 */
	public int getColumns(){
		return 0;
	}
	
	/**
	 * returns Start index of the selection.
	 */
	public int getStart(){
		return 0;
	}
	
	
	/**
	 * returns end index of the selection.
	 */
	public int getEnd(){
		return 0;
	}
	
	/**
	 * Sets selection in text
	 */
	public void setSelection(int start, int end){
		return ;
	}
	
	
	/**
	 * Sets if the combobox has an editable field
	 * @param lines {Boolean} 
	 */
	public void setEditable(boolean editable){
		return;
	}
	
	/**
	 * return true if the combobox has an editable field
	 */
	public boolean isEditable(){
		return false;
 	}
	/**
	 * Sets method to be invoked if enter was pressed in an editable and enabled textfield. <br>
	 * @param methodText {String} method in specific format as <strong> MethodName(parameters) </strong>
	 * <h3>MathodName:</h3> Name of Global method already defined in script
	 * <h3>parameters:</h3> The event description may contain parameters (in brackets, separated by comma or whitespace characters) as follows:
	 * <ul>
	 * <li> <b> this </b> =The source widget (the object on which the event occurred)
	 * <li> <b> widget name </b> =Another widget in gui identified by the given name
	 * <li> <b> item </b> =The component part on which the event occurred, valid for list item, tree node, table row, combobox choice, and tabbedpane tab
	 * <li> <b> this/name/item .attribute </b> =component's or item's attribute value, defined by the this, widget name, or item string, dot, and the attribute key. 
			Ex. <code> onSelectionChange(this, item.text, this.value) </code>
	 * <li> <b> constant string </b> =The source widget (the object on which the event occurred)
	 * <li> <b> constant value </b> =The source widget (the object on which the event occurred)
	 * <li> <b> constant number </b> =Long numbers end with 'L' character (it ignors case), floats width 'F', doubles have to include a dot character, otherwise it is expected as integer.	 * </ul>
	 */
	public void setOnPerform(String methodText){
	}
 
	/**
	 * Returns method text associated with 'action' for this widget
	 * @return Method Text if assigned else null
	 */
	public String getOnPerform(){
		return null;
	}
	
 	/**
	 * Sets method to be invoked when there was an insert into the text (and possibly a portion has been removed too).<br>
	 * @param methodText {String} method in specific format as <strong> MethodName(parameters) </strong>
	 * <h3>MathodName:</h3> Name of Global method already defined in script
	 * <h3>parameters:</h3> The event description may contain parameters (in brackets, separated by comma or whitespace characters) as follows:
	 * <ul>
	 * <li> <b> this </b> =The source widget (the object on which the event occurred)
	 * <li> <b> widget name </b> =Another widget in gui identified by the given name
	 * <li> <b> item </b> =The component part on which the event occurred, valid for list item, tree node, table row, combobox choice, and tabbedpane tab
	 * <li> <b> this/name/item .attribute </b> =component's or item's attribute value, defined by the this, widget name, or item string, dot, and the attribute key. 
			Ex. <code> onSelectionChange(this, item.text, this.value) </code>
	 * <li> <b> constant string </b> =The source widget (the object on which the event occurred)
	 * <li> <b> constant value </b> =The source widget (the object on which the event occurred)
	 * <li> <b> constant number </b> =Long numbers end with 'L' character (it ignors case), floats width 'F', doubles have to include a dot character, otherwise it is expected as integer.	 * </ul>
	 */
	public void setOnInsert(String methodText){
	}
 
	/**
	 * Returns method text associated with event method 'onInsert' for this widget
	 * @return Method Text if assigned else null
	 */
	public String getOnInsert(){
		return null;
	}
	
 	/**
	 * Sets method to be invoked when a portion of the text has been removed.<br>
	 * @param methodText {String} method in specific format as <strong> MethodName(parameters) </strong>
	 * <h3>MathodName:</h3> Name of Global method already defined in script
	 * <h3>parameters:</h3> The event description may contain parameters (in brackets, separated by comma or whitespace characters) as follows:
	 * <ul>
	 * <li> <b> this </b> =The source widget (the object on which the event occurred)
	 * <li> <b> widget name </b> =Another widget in gui identified by the given name
	 * <li> <b> item </b> =The component part on which the event occurred, valid for list item, tree node, table row, combobox choice, and tabbedpane tab
	 * <li> <b> this/name/item .attribute </b> =component's or item's attribute value, defined by the this, widget name, or item string, dot, and the attribute key. 
			Ex. <code> onSelectionChange(this, item.text, this.value) </code>
	 * <li> <b> constant string </b> =The source widget (the object on which the event occurred)
	 * <li> <b> constant value </b> =The source widget (the object on which the event occurred)
	 * <li> <b> constant number </b> =Long numbers end with 'L' character (it ignors case), floats width 'F', doubles have to include a dot character, otherwise it is expected as integer.	 * </ul>
	 */
	public void setOnRemove(String methodText){
	}
 
	/**
	 * Returns method text associated with event method 'onRemove' for this widget
	 * @return Method Text if assigned else null
	 */
	public String getOnRemove(){
		return null;
	}
	
	/**
	 * Sets method to be invoked whenever the caret position has been changed.<br>
	 * @param methodText {String} method in specific format as <strong> MethodName(parameters) </strong>
	 * <h3>MathodName:</h3> Name of Global method already defined in script
	 * <h3>parameters:</h3> The event description may contain parameters (in brackets, separated by comma or whitespace characters) as follows:
	 * <ul>
	 * <li> <b> this </b> =The source widget (the object on which the event occurred)
	 * <li> <b> widget name </b> =Another widget in gui identified by the given name
	 * <li> <b> item </b> =The component part on which the event occurred, valid for list item, tree node, table row, combobox choice, and tabbedpane tab
	 * <li> <b> this/name/item .attribute </b> =component's or item's attribute value, defined by the this, widget name, or item string, dot, and the attribute key. 
			Ex. <code> onSelectionChange(this, item.text, this.value) </code>
	 * <li> <b> constant string </b> =The source widget (the object on which the event occurred)
	 * <li> <b> constant value </b> =The source widget (the object on which the event occurred)
	 * <li> <b> constant number </b> =Long numbers end with 'L' character (it ignors case), floats width 'F', doubles have to include a dot character, otherwise it is expected as integer.	 * </ul>
	 */
	public void setOnCaret(String methodText){
	}
 
	/**
	 * Returns method text associated with event method 'onCaret' for this widget
	 * @return Method Text if assigned else null
	 */
	public String getOncaret(){
		return null;
	}
	
	
	
}

	

