package simphy.script.widgets;

/**
 * A list allows the user to select one or more objects from a list, and internally handles scrolling.
 * @author mahesh
 *
 */
  public class ListBox extends Widget implements Actionable{
    

    	/**
    	 * Adds item to the list at its end
    	 * @param text Text displayed
    	 */
    	public SelectableItemWidget addItem(String text){
    		return addItem(text,null);
    	}
    	
    	/**
    	 * Adds item to the list at its end
    	 * @param text
    	 * @param icon
    	 */
     	public SelectableItemWidget addItem(String text,String icon){
    		return addItem(text,icon,-1);
    	}
    	
     	/**
     	 * Adds the specified item to the the scrolling list at the position indicated by the index. The index is zero-based.
     	 * If the value of the index is less than zero, or if the value of the index is greater than or equal to the number of items in the list, then the item is added to the end of the list.
     	 * @param text
     	 * @param icon
     	 * @param index
     	 * @return
     	 */
    	public SelectableItemWidget addItem(String text,String icon, int index){
    		return null;
    	}
    	
    	/**
         * Gets the number of items in this list.
         * @return   
         * @see       #getItem
         */
        public int getItemCount() {
            return 0;
        }
        
      
    	  /**
         * Gets the nth item in this list.
         * @param      n   the index of the item to get.
         * @return     the n<sup>th</sup> item in this container.
         * @exception  ArrayIndexOutOfBoundsException
         *                 if the n<sup>th</sup> value does not exist.
         * @see #getItemCount()
         */
        public SelectableItemWidget getItem(int n) {
        	return null;
        }
        
        /**
         * Gets the index of the first selected item in this list
         * @param n
         * @return
         */
        public int getSelectedIndex() {
        	return 0;
        }
        
        /**
         * Sets the index as selected
         * @param n
         * @return
         */
        public void setSelectedIndex(int n) {
        	
        }
        
        /**
         * Sets the index as selected
         * @param n
         * @return
         */
        public void setSelectedIndices(int[] indices) {
        	
        }
        
        /**
         * Gets the first selected item in this list
         * @return selected item widget
         */
        public SelectableItemWidget getSelectedItem() {
        	return null;
         }
        
           
        /**
         * Gets the selected items of the list when multiple selection is allowed
         * @return Array of selected itemwidgets
         */
        public SelectableItemWidget[] getSelectedItems() {
        	return null;
        }
        
        
        /**
         * Returns the index of the specified item in this  list 
         * returns -1 if not found
         * @param item
         * @return
         */
        public int getIndexOfItem(Widget item){
        	return -1;
        }
        
        /**
         * Gets all the items in this list.
         * @return    an array of all the components in this container.
         * @see #getComponent(int)
         */
        public Widget[] getAllItems() {
        	return null;
        }
        
    	/**
    	 * Removes the specified item from this list. 
    	 * @param item {Widget} the item to be removed
    	 * @see #add(Widget)
    	 * */
    	 public void removeItem(SelectableItemWidget item){
    		
    	}
    	
    	/**
    	 * Removes the item, specified by index, from this list. 
    	 * @param index {Number} the index of the item to be removed
    	 */
    	public void removeItem(int index) throws ArrayIndexOutOfBoundsException{
    		
    	}
    		
    	/**
    	 * Removes all the items from this list. 
    	 */
    	public void removeAll(){
    		
    	}
    	
    	/**
    	 * Sets selection mode of list
    	 * The default single value allows to select one list item at a time, the interval value to select one contiguous range of items, 
    	 * and the multiple value to select one or more contiguous ranges of items.
    	 * @param multiSelect single|interval|multiple
    	 */
    	public void setSelectionMode(String multiSelect){
    		
    	}
    	
    	/**
    	 * Returns selection mode of the list
    	 * @return
    	 */
    	public String getSelectionMode(){
    		return null;
    	}
    	
    	/**
    	 * Sets if lines are drawn separating the list items.
    	 * @param lines {Boolean} separator lines are drawn if true
    	 */
    	public void setDrawSeparatorLines(boolean lines){
    		
    	}
    	
    	/**
    	 * return if lines are drawn separating the list items.
    	 */
    	public boolean isDrawSeparatorLines(){
    		return false;
     	}
    	
    	/**
    	 * Sets method to be invoked list is double clicked <br>
    	 * @param methodText {String} method in specific format as <strong> MethodName(parameters) </strong>
    	 * <h3>MathodName:</h3> Name of Global method already defined in script
    	 * <h3>parameters:</h3> The event description may contain parameters (in brackets, separated by comma or whitespace characters) as follows:
    	 * <ul>
    	 * <li> <b> this </b> =The source widget (the object on which the event occurred)
    	 * <li> <b> widget name </b> =Another widget in gui identified by the given name
    	 * <li> <b> item </b> =The component part on which the event occurred, valid for list item, tree node, table row, combobox choice, and tabbedpane tab
    	 * <li> <b> this/name/item .attribute </b> =component's or item's attribute value, defined by the this, widget name, or item string, dot, and the attribute key. 
    			Ex. <code> onSelectionChange(this, item.text, this.value) </code>
    	 * <li> <b> constant string </b> =The source widget (the object on which the event occurred)
    	 * <li> <b> constant value </b> =The source widget (the object on which the event occurred)
    	 * <li> <b> constant number </b> =Long numbers end with 'L' character (it ignors case), floats width 'F', doubles have to include a dot character, otherwise it is expected as integer.	 * </ul>
    	 */
    	public void setOnPerform(String methodText){
     	}
     
    	/**
    	 * Returns method text associated with 'action' for this widget
    	 * @return Method Text if assigned else null
    	 */
    	public String getOnPerform(){
    		return null;
    	}
    	
    	/**
    	 * Sets method to be invoked whenever item in the list is selected <br>
    	 * @param methodText {String} method in specific format as <strong> MethodName(parameters) </strong>
    	 * <h3>MathodName:</h3> Name of Global method already defined in script
    	 * <h3>parameters:</h3> The event description may contain parameters (in brackets, separated by comma or whitespace characters) as follows:
    	 * <ul>
    	 * <li> <b> this </b> =The source widget (the object on which the event occurred)
    	 * <li> <b> widget name </b> =Another widget in gui identified by the given name
    	 * <li> <b> item </b> =The component part on which the event occurred, valid for list item, tree node, table row, combobox choice, and tabbedpane tab
    	 * <li> <b> this/name/item .attribute </b> =component's or item's attribute value, defined by the this, widget name, or item string, dot, and the attribute key. 
    			Ex. <code> onSelectionChange(this, item.text, this.value) </code>
    	 * <li> <b> constant string </b> =The source widget (the object on which the event occurred)
    	 * <li> <b> constant value </b> =The source widget (the object on which the event occurred)
    	 * <li> <b> constant number </b> =Long numbers end with 'L' character (it ignors case), floats width 'F', doubles have to include a dot character, otherwise it is expected as integer.	 * </ul>
    	 */
      	public void setAction(String methodText) {
     	}

    	@Override
    	public String getAction() {
    		return null;
    	}


    }
