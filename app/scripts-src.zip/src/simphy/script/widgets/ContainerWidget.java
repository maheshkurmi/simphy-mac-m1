package simphy.script.widgets;
  
/**
 * Wrapper Class for Containers [desktop, panel, dialog, splitpane]
 * @author mahesh
  */
public abstract class ContainerWidget extends Widget{
    	
    	/**
    	 * Appends the specified component to the end of this container.
     	 * @param widget {Widget}  the component to be added
    	 */
    	public void add(Widget widget){
     		
    	}
    	
    	 /**
        * Adds the specified component to this container at the given
        * position.
        * @param  widget  the component to be added
        * @param  index   the position at which to insert the component,
        *                 or <code>-1</code> to append the component to the end
     	*/
    	public void add(Widget widget, int index){
    		
    	}
    	
    	/**
         * Gets the number of components in this container.
         * @return    the number of components in this panel.
         * @see       #getComponent
         */
        public int getComponentCount() {
            return 0;
        }
        
      
    	  /**
         * Gets the nth component in this container.
         * @param      n   the index of the component to get.
         * @return     the n<sup>th</sup> component in this container.
         * @exception  ArrayIndexOutOfBoundsException
         *                 if the n<sup>th</sup> value does not exist.
         * @see #getComponentCount()
         */
        public Widget getComponent(int n) {
        	return null;
        }
        
        
         /**
         * Gets all the components in this container.
         * @return    an array of all the components in this container.
         * @see #getComponent(int)
         */
        public Widget[] getComponents() {
        	return null;
        }
        
    	/**
    	 * Removes the specified component from this container. 
    	 * @param component {Widget} the component to be removed
    	 * @see #add(Widget)
    	 * */
    	 public void remove(Widget component){
    		
    	 }
    	
    	/**
    	 * Removes the component, specified by index, from this container. 
    	 * @param index {Number} the index of the component to be removed
    	 */
    	public void remove(int index) throws ArrayIndexOutOfBoundsException{
    		
      	}
    		
    	/**
    	 * Removes all the components from this container. 
    	 */
    	public void removeAll(){
    		
    	}
    	

    }
