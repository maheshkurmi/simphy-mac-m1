package simphy.script.widgets;
/**
 * Wrapper class for ToggleButton, RadioButton, Checkbox, Item(list), checkboxmenuItem
 * @author mahesh
 *
 */
public class ToggleButton extends CheckBox{

	


}
