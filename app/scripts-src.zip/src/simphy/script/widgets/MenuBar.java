package simphy.script.widgets;

/**
 * 
 * @author mahesh
 *
 */
public class MenuBar extends Widget{

	
	/**
	 * Add top menu for the menubar
	 * @param text
	 * @return
	 */
	public MenuBar addMenu(String text){
		return addMenu(text,null);
	}
	
	/**
	 * Add top menu for the menubar
	 * @param text
	 * @param icon
	 * @return
	 */
	public MenuBar addMenu(String text, String icon){
		return null;
	}

	/**
	 * Menubar may unfold the menus either downwards (default - for menubars placed at the top of the container), 
	 * or upwards from the menubar position (bottom - for menubars placed at the bottom of the container).
	 * @param placement top|bottom
	 */
	public void setPlacement(String placement){
		
	}
	
	/**
	 * returns placement of menubar top|bottom
	 * @return
	 */
	public String getPlacement(){
		return null;
	}
}
