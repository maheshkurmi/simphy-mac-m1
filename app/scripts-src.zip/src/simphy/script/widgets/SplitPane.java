package simphy.script.widgets;

/**
 * Widget wrapper for label, button, cell(table), choice(combo) ,menuItem
 * @author mahesh
 *
 */
public class SplitPane extends ContainerWidget{

	/**
	 * The splitpane orientation is either horizontal or vertical. By default the splitter is divided horizontally.
	 * @param orientation {String} horizontal|vertical
	 */
	public void setOrientation(String orientation){
		
	}
	
	/**
	 * The splitpane orientation is either horizontal or vertical. 
	 * @return
	 */
	public String getOrientation(){
		return null;
	}

	/**
	 * The location of the divider. 
	 * A negative value implies the divider should be reset to a value that attempts to honor the preferred size of the two components.
	 * @param divider {integer} location in pixel
	 */
	public void setDivider(int divider){
		
	}
	
	/**
	 * The location of divider in pixel
	 * A negative value implies the divider should be reset to a value that attempts to honor the preferred size of the two components.
	 * @return
	 */
	public int getDivider(){
		return 0;
	}

}
