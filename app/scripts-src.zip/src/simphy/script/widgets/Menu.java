package simphy.script.widgets;

/**
 * 
 * @author mahesh
 *
 */
public class Menu extends Widget{

	
	/**
	 * Adds sub menu to this menu
	 * @param text
	 * @return sub menu added, the returned menu can be used to append more sub menus or subitems to it
	 */
	public Menu addMenu(String text){
		return addMenu(text,null);
	}
	/**
	 * Adds sub menu to this menu
	 * @param text
	 * @param icon
	 * @return sub menu added, the returned menu can be used to append more sub menus or subitems to it
	 */
	public Menu addMenu(String text, String icon){
		return null;
	}

	/**
	 * Add new menu item to this menu
	 * @param text Text to be displayed on submenu
	 */
	public ActionItemWidget addMenuItem(String text){
		return addMenuItem(text,null);
	}
	
	/**
	 * Add new menu item to this menu
	 * @param text Text to be displayed on submenu
	 * @param String icon Image name to be displayed as menu item. 
	 * @return
	 */
	public ActionItemWidget addMenuItem(String text, String icon){
		return null;
	}
	
	/**
	 * Add A menu item that can be selected or deselected. 
	 * The selected menuitem appears with a checkmark next to it. 
	 * A radio-button menu-item is a menu item that is part of a group of menu items in which only one item in the group can be selected.
	 * @param text
	 * @return
	 */
	public CheckBox addCheckBoxMenuItem(String text){
		return addCheckBoxMenuItem(text,null);
	}
	
	/**
	 * Add A menu item that can be selected or deselected. 
	 * The selected menuitem appears with a checkmark next to it. 
	 * A radio-button menu-item is a menu item that is part of a group of menu items in which only one item in the group can be selected.
	 * @param text
	 * @param icon
	 * @return
	 */
	public CheckBox addCheckBoxMenuItem(String text, String icon){
		return null;
	}
	
	/**
	 * add separator
	 * @return
	 */
	public Widget addSeparator(){
		return null;
	}


	/**
	 * Specifies the underlined char in the label's text. 
	 * When Alt+Mnemonic key ispressed the action is fired.
	 * @param mnemonic
	 */
	public void setMnemonic(int mnemonic){
		
	}

}
