package simphy.script.widgets;

/**
 * Widget wrapper for label
 * 
 * @author mahesh
 *
 */
public class Label extends ItemWidget {

	/**
	 * Specifies the underlined char in the label's text. 
	 * When Alt+Mnemonic key ispressed the label will focus the component specified by its name when the mnemonic is activated.
	 * @param mnemonic
	 */
	public void setMnemonic(int mnemonic){
		
	}

}
