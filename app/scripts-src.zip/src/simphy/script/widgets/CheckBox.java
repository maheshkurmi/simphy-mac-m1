package simphy.script.widgets;
/**
 * Wrapper class for ToggleButton, RadioButton, Checkbox, Item(list), checkboxmenuItem
 * @author mahesh
 *
 */
public class CheckBox extends SelectableItemWidget{

	
	
	/**
	 * Identifies the radio button group if not null. 
	 * Only one radio button at a time can be selected.
	 * User can set on a radio button, the selected button of the group will be set off (the group members is searched only in the same parent).
	 * @param group group identifier (can be any unique string)
	 */
	public void setGroup(String group){
		
	}

	/**
	 * Return the radio button group if not null else null 
	 * @see #setGroup()
	 */
	public String getGroup(){
		return "";
	}
	

	/**
	 * Specifies the underlined char in the label's text. 
	 * When Alt+Mnemonic key ispressed the action is fired.
	 * @param mnemonic
	 */
	public void setMnemonic(int mnemonic){
		
	}

}
