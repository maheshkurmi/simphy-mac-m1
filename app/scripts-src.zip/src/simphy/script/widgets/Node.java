package simphy.script.widgets;

/**
 * Widget wrapper for Node for treeview
 * @author mahesh
 *
 */
public class Node extends SelectableItemWidget{

	
   	/**
   	 * Returns nodes at top level of this node at specified index
   	 * @return
   	 * @see getAllNodes()
   	 */
	public Node getNodeAtIndex(int index){
		return null;
	}
	
	
	/**
   	 * Returns nodes at top level of this  node
   	 * Other roots can be obtained by calling getAllNodes at recursily at subnodes
   	 * @return
   	 * @see getNodeAtIndex()
   	 */
	public Node[] getAllNodes(){
		return null;
	}
	
	
	
	/**
	 * Add new Node to the top level of this node
	 * @param text
	 * @return
	 */
	public Node addNode(Object value){
		return addNode(value,null);
	}
	
	/**
	 * Add new Node to the top level of this node
	 * @param text
	 * @param icon
	 * @return
	 */
	public Node addNode(Object value, String icon){
		return null;
	}
	
	/**
	 * Removes Node at top level of this at specified index, along with all its child nodes
	 * @param index
	 */
	public void removeNode(int index){
		
	}

	/**
	 * Removes all Nodes contained in it
 	 */
	public void removeAll(){
		
 	}


	/**
	 * Returns value at the node (Object associated with node)
	 * @return {Object}
	 */
	public Object getValue(){
		return null;
	}
	
}
