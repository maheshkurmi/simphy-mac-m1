package simphy.script.widgets;
  
/**
 * Base/Wrapper Class for Widgets with associated action [button, slider etc]
 * @author mahesh
  */
public interface Actionable{
    
    	/**
    	 * Sets method to be invoked whenever widget fires action (Ex button clicked, combobox selected, slider changed etc) <br>
    	 * @param methodText {String} method in specific format as <strong> MethodName(parameters) </strong>
    	 * <h3>MathodName:</h3> Name of Global method already defined in script
    	 * <h3>parameters:</h3> The event description may contain parameters (in brackets, separated by comma or whitespace characters) as follows:
    	 * <ul>
    	 * <li> <b> this </b> =The source widget (the object on which the event occurred)
    	 * <li> <b> widget name </b> =Another widget in gui identified by the given name
    	 * <li> <b> item </b> =The component part on which the event occurred, valid for list item, tree node, table row, combobox choice, and tabbedpane tab
    	 * <li> <b> this/name/item .attribute </b> =component's or item's attribute value, defined by the this, widget name, or item string, dot, and the attribute key. 
    			Ex. <code> onSelectionChange(this, item.text, this.value) </code>
    	 * <li> <b> constant string </b> =The source widget (the object on which the event occurred)
    	 * <li> <b> constant value </b> =The source widget (the object on which the event occurred)
    	 * <li> <b> constant number </b> =Long numbers end with 'L' character (it ignors case), floats width 'F', doubles have to include a dot character, otherwise it is expected as integer.	 * </ul>
    	 */
    	public void setAction(String methodText);
     
    	/**
	 * Returns method text associated with 'action' for this widget
	 * 
	 * @return Method Text if assigned else null
	 */
    	public String getAction();
}