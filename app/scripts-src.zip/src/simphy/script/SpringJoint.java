package simphy.script;

/**
 * This joint simulates a spring connected between bodies and applies force
 * on the bodies as per the distance between the anchor points.
 *
 */
public class SpringJoint extends Joint {

	/**
	 * Returns true if this distance joint is a spring distance joint
	 * with damping.
	 * @return boolean
	 */
	public boolean isSpringDamper() {
		return false;
	}
	
	/**
	 * Returns the damping ratio.
	 * @return double
	 */
	public double getDampingcoeff() {
		return 0;
	}
	
	/**
	 * Sets the damping ratio.
	 * @param dampingRatio the damping ratio; in the range [0, 1]
	 * @throws IllegalArgumentException if damping ration is less than zero or greater than 1
	 */
	public void setDampingCoeff(double dampingCoeff) {
	}
	
	/**
	 * Returns the spring frequency.
	 * @return double
	 */
	public double getFrequency() {
		return 0;
	}
	
	/**
	 * Sets the spring frequency.
	 * @param frequency the spring frequency in hz; must be greater than or equal to zero
	 * @throws IllegalArgumentException if frequency is less than zero
	 */
	public void setFrequency(double frequency) {
		
	}

	/**
	 * Returns the rest distance between the two constrained {@link Body}s in meters.
	 * @return double
	 */
	public double getNaturalLength() {
		return 0;
	}
	
	/**
	 * Sets the rest distance between the two constrained {@link Body}s in meters.
	 * @param naturalLength the naturalLength in meters
	 * @throws IllegalArgumentException if distance is less than zero
	 */
	public void setNaturalLength(double naturalLength) {
	}

	/**
	 * Sets Spring Constant of the spring
	 * @param springConstant
	 */
	public void setSpringConstant(double springConstant){
	}

	/**
	 * returns Spring Constant of the Spring
	 * @return Spring Constant of the Spring
	 */
	public double getSpringConstant(){
		return 0;
	}
	

}
