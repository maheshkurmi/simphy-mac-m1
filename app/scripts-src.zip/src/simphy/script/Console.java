package simphy.script;

/**
 * Window for displaying info and error messages in scripting
 * 
 * @author Mahesh kurmi
 * @version 1.0.0
 * @since 2.0.0
 */
public   class Console {
	/**
	 * Do not allow its instance creation
	 */
	private Console() {

	}


	/**
	 * prints msg to console window
	 * 
	 * @param text
	 */
	public static  void print(String text) {
		
	}

	/**
	 * prints msg to console window in new line
	 * 
	 * @param text
	 */
	public static  void println(String text) {
		
	}

	/**
	 * prints a formatted string on console using the specified format string and arguments
	 * 
	 * @param format {String} format string {@link https://docs.oracle.com/javase/8/docs/api/java/util/Formatter.html}
	 * @param args Arguments referenced by the format specifiers in the format string. If there are more arguments than format specifiers, the extra arguments are ignored. 
	 * The number of arguments is variable and may be zero.
	 */
	public static  void printf(String format,Object... args) {
		
	}

	/**
	 * For general output of logging information.
	 * @param text
	 */
	public static  void info(String text){
		
	}
	
	/**
	 * Outputs an error message
	 * @param text
	 */
	public static  void error(String text){
		
	}

	/**
	 * Informative logging of information.
	 * @param text
	 */
	public static  void log(String text){
		
	}
	/**
	Returns a formatted string using the specified format string and arguments
	 * @param format {String} format string {@link https://docs.oracle.com/javase/8/docs/api/java/util/Formatter.html}
	 * @param args Arguments referenced by the format specifiers in the format string. If there are more arguments than format specifiers, the extra arguments are ignored. 
	 * The number of arguments is variable and may be zero.
	 */
	public static  String format(String format,Object... args) {
		return null;
	}

	/**
	 * clears console window
	 */
	public static  void clear() {
		
	}

	/**
	 * Shows the about MODELESS dialog, it doesn't block any top-level windows..
	 */
	public static  void show() {
	
	}

	/**
	 * hides console window
	 */
	public static  void hide() {
		
	}

	/**
	 * Sets maximum number of line console can display [default:256], 
	 * Note that very large number of lines may have performance issue
	 * @param numLines
	 * @throws SimphyScriptException
	 */
	public static  void setMaxLines(int numLines) {
	}


	 /** round offs result to preferred significant figures as set in  Preferences
	 * @param {number} val
	 * @return {Number}
	 */
	public static  double roundoff(double val) {
		return 0;
	}

	/**
	 * clears console window
	 */
	public static  void clearAll() {
		
	}


}
