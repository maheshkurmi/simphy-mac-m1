package simphy.script;

/**
 * Implementation of a fixed length distance joint.
 * <p>
 * Given the two world space anchor points a distance is computed and used
 * to constrain the attached {@link Body}s at that distance.  The bodies can rotate
 * freely about the anchor points and the whole system can move and rotate freely, but
 * the distance between the two anchor points is fixed.
 * <p>
 * This joint doubles as a spring/damper distance joint where the length can
 * change but is constantly approaching the target distance.  Enable the
 * spring/damper by setting the frequency and damping ratio to values greater than
 * zero.  A good starting point is a frequency of 8.0 and damping ratio of 0.3
 * then adjust as necessary.
 */
public class DistanceJoint extends Joint {
	
	/**
	 * Returns true if this distance joint is a spring distance joint.
	 * @return boolean
	 * @see #getFrequency()
	 */
	public boolean isSpring() {
		return false;
	}
	
	/**
	 * Returns true if this distance joint is a spring distance joint
	 * with damping.
	 * @return boolean
	 */
	public boolean isSpringDamper() {
		return false;
	}
	
	/**
	 * Returns the rest distance between the two constrained {@link Body}s in meters.
	 * @return double
	 */
	public double getDistance() {
 	return 0;
	}
	
	/**
	 * Sets the rest distance between the two constrained {@link Body}s in meters.
	 * @param distance the distance in meters
	 * @throws IllegalArgumentException if distance is less than zero
	 */
	public void setDistance(double distance) {
		
	}
	
	/**
	 * Returns the damping ratio.
	 * @return double
	 */
	public double getDampingRatio() {
		return 0;
	}
	
	/**
	 * Sets the damping ratio.
	 * <p>
	 * Larger values reduce the oscillation of the spring.
	 * @param dampingRatio the damping ratio; in the range [0, 1]
	 * @throws IllegalArgumentException if damping ration is less than zero or greater than 1
	 */
	public void setDampingRatio(double dampingRatio) {
		
	}
	
	/**
	 * Returns the spring frequency.
	 * @return double
	 */
	public double getFrequency() {
		return 0;
	}
	
	/**
	 * Sets the spring frequency.
	 * <p>
	 * Larger values increase the stiffness of the spring.
	 * @param frequency the spring frequency in hz; must be greater than or equal to zero
	 * @throws IllegalArgumentException if frequency is less than zero
	 */
	public void setFrequency(double frequency) {
		
	}
	

}
