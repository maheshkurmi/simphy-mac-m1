package simphy.script.canvas;


import simphy.script.Vector2;


/**
 * 3x3 Column major Homogeneous matrix whole third row always remians [0 , 0 , 1]
 * <pre>
 * Matrix multiplication 
 * M=M1.M2
 * Transformed Vector=M.V (=M1.M2.V)
 * where V is Column matrix 3x1 |x|
 *                              |y|
 * 								|1|
 * 
 * TransformedVector = TranslationMatrix * RotationMatrix * ScaleMatrix * OriginalVector;
 * This lines actually performs the scaling FIRST, and THEN the rotation, and THEN the translation
 * </pre>
 * @author mahesh
 *
 */
public class Transform {
	
	public double[] m=new double[6];

	/**
	 * x=ax+cy+e
	 * y=bx+dy+f
	 * 
	 * matrix [a,b,c,d,e,f] ==[m0 m1 m2 m3 m4 m5]
	 * 
	 * Creates matrix
	 * |m0  m2  m4|
	 * |m1  m3  m5|
	 * |0   0    1|
	 * @param m0 
	 * @param m1
	 * @param m2
	 * @param m3
	 * @param m4
	 * @param m5
	 */
	public Transform(double m0, double m1, double m2, double m3, double m4, double m5) {
	}

	public Transform(double[] m) {
	}
	
	
	/**
	 * Loads matrix to identity
	 * |1 0 0|
	 * |0 1 0|
	 * |0 0 1|
	 * @return
	 */
	public static Transform matIdentity()  {
		return null;
	}
	
	/**
	 * returns translation matrix  
	 * |1 0 tx|
	 * |0 1 ty|
	 * |0 0  1|
	 * @param tx translation in x
	 * @param ty translation in y
	 * @return
	 */
	public static Transform matTranslate(double tx, double ty) {
		return null;
	}

	/**
	 * returns scale to Scale
	 * |sx  0  0|
	 * |0  sy  0|
	 * |0  0   1|
	 * @param sx scale in x
	 * @param sy scale in y
	 * @return
	 */
	public static Transform matScale(double sx, double sy) {
		return null;
	}

	/**
	 * returns rotation matrix about origin (CW as positive)
	 * |c  -s  0|
	 * |s   c  0|
	 * |0   0  1|
	 * where c=cos(theta), s=sin(theta)
	 * @param radians angle in radians (CW as positive)
	 * @return
	 */
	public static Transform matRotate(double radians) {
		return null;
	}
	
	/**
	 * Inverts this matrix
	 * @return
	 */
	public Transform invert()  {
		return null;
	}
	
	
	/**
	 * post multiplies this matrix to given matrix and returns new matrix
	 * @param m2
	 * @return new m2.this
	 */
	public Transform mul(Transform m2)  {
		return null;
	}
	

	
	/**
	 * returns new transformed Point
	 * @param v
	 * @return
	 */
	public Vector2 transform(double x, double y){
		return null;
	}
	/**
	 * returns new transformed Point
	 * @param v
	 * @return
	 */
	public Vector2 transformPoint(double x, double y){
		return null;
	}
	
	/**
	 * returns new transformed Direction(not translated)
	 * @param v
	 * @return
	 */
	public Vector2 transformDir(double x, double y){
		return null;
	}
	

	/**
	 * returns true if this matrix is identity
	 * @return
	 */
	public boolean isIdentity() {
		return false;
	}

	/**
	 * Creates copy of this transform
	 * @return
	 */
	public Transform copy() {
		return null;
	}

	public float[] toFloatArray() {
		return null;
	}
}
