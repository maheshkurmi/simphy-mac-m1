
package simphy.script.canvas.scene3d;

import simphy.script.Vector3;

/**
 * Physics.
 *
 * @author Mahesh Kurmi
 */

public class Physics 
{
    /** The velocity. */
	public  Vector3 velocity = new Vector3();

    /** The minimum velocity. */
    public  Vector3 minVelocity = new Vector3();

    /** The maximum velocity. */
    public final Vector3 maxVelocity = new Vector3();
    
    /** The acceleration. */
    public Vector3 acceleration = new Vector3();

    /** The linear damping (drag=damping*speed) */
    public float linearDamping =0;

    /** The angular velocity. */
    public  Vector3 angularVelocity = new Vector3();


    
}
