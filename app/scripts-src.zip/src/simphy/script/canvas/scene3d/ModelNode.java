package simphy.script.canvas.scene3d;



public class ModelNode extends SceneNode3D {

	public ModelNode() {

	}


	/**
	 * Resizes Model to unit size and centers it at origin
	 */
	public void Normalize(){
	}          
	

	/**
	 * Clones this node Note that Model is not cloned, only its reference is copied
	 */
	@Override
	public ModelNode clone() {
		return null;
	}

	public void setRenderObjectBounds(boolean b) {
	}

}
