package simphy.script.canvas.scene3d;

import simphy.script.Color;
import simphy.script.Vector3;

/**
 * A light node.
 *
 */

public class Light extends SceneNode3D {
	
	/**
	 * Creates a new light with default colors (White) and full Intensity (=1).
	 */
	public Light() {
		super();
	}


	/**
	 * Sets the light color. 
	 * @param color {Color}
	 *            The color to set (must not be null)
	 */
	public void setColor(final Color color)  {
	}
	
	/**
	 * Sets the color of the light
	 * @param r
	 * @param g
	 * @param b
	 */
	public void setColor(float r, float g, float b){
	}
	
	/**
	 * Returns the light color. 
	 * @return  {Color} 
	 */
	public Color getColor() {
		return null;
	}

	/**
	 * Sets the light color. 
	 * @param {Number} intensity
	 *            numeric value of the light's strength/intensity. Default is 1.
	 */
	public void setIntensity(float intensity) {
	}
	
	/**
	 * Returns numeric value of the light's strength/intensity.
	 * @return {Number}
	 */
	public float getIntensity() {
		return 0;
	}
	

	/**
	 * Sets the target (used only when light is directional or spot) the light is looking at
	 * @param target {Vector3}
	 * @throws SimphyScriptException 
	 */
	public void setTarget(Vector3 target){
	}
	
	/**
	 * Sets the target (used only when light is directional or spot) the light is looking at
	 * @param x
	 * @param y
	 * @param z
	 */
	public void setTarget(float x, float y, float z){
	}
	
	/**
	 * Returns the target (used only when light is directional or spot) the light is looking at
	 * @return {Vector3}
	 */
	public Vector3 getTarget(){
		return null;
	}
	
	/**
	 * Sets this light as Ambient Light located at origin which globally illuminates all objects in the scene equally.
	 */
	public Light setAsAmbientLight(Vector3 position) {
		return this;
	}

	/**
	 * Sets light as point source emitting light in all directions.  Ex. light from bulb
	 * @param position {vector3}
	 *            the position of light in parent space
	 */
	public Light setAsPointLight(Vector3 position) {
		return this;
	}

	/**
	 * Sets Light as directional, A directional light emits light from an infinite distance. The ray emitted are all
	 * parallel and have the same direction. Ex. light from sun
	 * @param position {vector3} position of light in parent space
	 * @param target {Vector3} The direction of light is calculated as pointing from the light's position to the target's position ( 
	 */
	public Light setAsDirectionalLight(Vector3 position,Vector3 target) {
		return this;
	}

	/**
	 * A spot is a particular positional light source. Like positional light source a spot is positionned at a defined
	 * point and emit light from this point. The difference is, for a spot, the ray emission is restricted to a cone
	 * area. Outside the cone, a spot emits no light.
	 * 
	 * @param position {Vector3} 
	 *            position of light source in parent space
	 * @param target {Vector3} 
	 * 			  The direction of light is calculated as pointing from the light's position to the target's position ( 
	 * @param cutOff {Number} 
	 *            the angle (in degrees) between the axis of the cone and a ray along the edge of the cone
	 * @param spot_exponent {Number} 
	 * 			  which by default is zero, to control how concentrated the light is. The light’s intensity is highest in the center of the cone. It’s attenuated toward the edges of the cone by the cosine of the angle between the direction of the light and the direction from the light to the vertex being lit, raised to the power of the spot exponent. 
	 */
	public Light setAsSpotLight(Vector3 position, Vector3 target, float cutOff,float spot_exponent) {
		return this;
	}

	/**
	 * Sets the coefficient of the constant term in the attenuation equation for this Light. Attenuation
	 * factor=1/(c+l*d+q*d*d) Note that: attenuation is disabled for a directional light and ambient, since a directional light is
	 * infinitely far away.
	 * 
	 * @param constantAttenuation
	 *            (c) the value to use for the constant coefficient (default =1).
	 * @param linearAttenuation
	 *            (l) the value to use for the linear coefficient (default=0).
	 * @param quadraticAttenuation
	 *            (d) the value to use for the quadratic coefficient (default=0).
	 */
	public void setAttenuation(float constantAttenuation, float linearAttenuation, float quadraticAttenuation) {
	}

	/**
	 * Retrieves the coefficient of the constant term in the attenuation equation for this Light.
	 * 
	 * @return {Array} [constant, linear, quadratic] coefficient.
	 */
	public float[] getAttenuation() {
		return null;
	}

	/**
	 * Sets the light ON/OFF
	 * @param {boolean} 
	 */
	public void setEnabled(boolean enabled) {
	}

	/**
	 * Return whether light is enabled (ON) or not (OFF) 
	 */
	public boolean isEnabled() {
		return false;
	}
	
	/**
	 * Sets this light as replica of specified light 
	 * @param light {Light} light to be copied in this light
	 * @return {Light} this light
	 */
	public Light set(Light light){
		return this;
	}

	/**
	 * Sets this light as replica of specified light 
	 * @param light {Light} light to be copied in this light
	 * @return {Light} this light
	 */
	public Light clone(){
		Light light=new Light();
		return light.set(this);
	}

}
