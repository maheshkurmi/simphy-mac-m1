package simphy.script.canvas.scene3d;

import simphy.script.Color;

public class Threed {
	public  Curves Curves;
	public  Meshes Meshes;
	
	/**
	 * Creates Empty scene <br>
	 * Use {@link Scene3D#root} method of scene to add objects to it
	 * @return
	 * @see #Scene3D.getRoot()
	 */
	public Scene3D createScene() {
	return null;
	}

	/** Constructs a new PerspectiveCamera, with default values  Which are..
	 * 
	 * <pre>
	 * Focus = [0,0,0] 
	 * Eye   = [0,0,1] 
	 * Up    = [0,1,0]	
	 * fov   = 45 degree
	 * near  = 1
	 * far   = 100
	 * @see {@link Camera#setAsOrthographic(float, float, float, float)}
	 * @see {@link Camera#setAsPerspective(float, float, float, float)}
	 */
	public Camera createCamera() {
		return null;
	}

	/**
	 * Creates a new ambient light with the specified color and specified intensity
	 *
	 * @param color
	 *         The color of the light
	 * @param intensity
	 *         numeric value of the light's strength/intensity. Default is 1.
	 * @throws SimphyScriptException 
	 * @see {@link Light#setAsPointLight(Vector3)}
	 * @see {@link Light#setAsDirectionalLight(Vector3,Vector3)}
	 * @see {@link Light#setAsSpotLight(Vector3,Vector3,float,float)}
	 */
	public Light createLight(Color lightColor, float intensity)  {
		return null;
	}
	
	/**
	 * Creates Material with lighting enabled having specified color
	 * @param color {Color} the color of the material
	 * @return {Material}
	 * @see {@link Material#setAsLineMaterial(Color, float)}
	 * @see {@link Material#setAsPointMaterial(Color, float)}
	 * @see {@link Material#setAsFlatColorMaterial(Color)}
	 * @see {@link Material#setAsLightMaterial(Color, float)}
	 */
	public Material createMaterial(Color color){
		return null;
	}

	/**
	 * Creates New Empty Node, useful in creating groups and applying common Material, Light or Transforms
	 * @return Empty Node object
	 */
	public SceneNode3D createNode() {
		return null;
	}

	/**
	 * Loads Model from obj or 3ds file (must already be loaded in resource), <br.
	 * For multiple copies of model use {@link ModelNode#clone()} rather than calling this method again for same file
	 * @param source name of file resource
	 * @return
	 */
	public ModelNode createModel(String source){
		return null;
	}

	/**
	 * Creates new model from mesh
	 * @param mesh
	 * @param material material used to render mesh, if null material of parent node will be used
	 * @return
	 */
	public ModelNode createModel(Mesh mesh, Material material) {
		return null;
	}

	/**
	 * Creates new model from curve
	 * @param mesh
	 * @param material material used to render mesh, if null material of parent node will be used
	 */
	public ModelNode createModel(Curve curve, Material material)  {
		return null;
	}
	
	/**
	 * Creates new Sprite for the image 
	 * @param {String} name of image
	 */
	public ModelNode createSprite(String imageName)  {
		return null;
	}

	/**
	 * Creates An axis object to visualize the 3 axes in a simple way. 
	 * The X axis is red. The Y axis is green. The Z axis is blue.
	 * @return
	 */
	public ModelNode createAxes(float size){
		return null;
	}

}
