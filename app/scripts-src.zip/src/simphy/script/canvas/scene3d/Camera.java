package simphy.script.canvas.scene3d;

import simphy.script.Vector3;

/**
 * Camera to view Scene, the scene rendering depends only on following 3 attributes of camera
 * <ol>
 * <li>position: location of eye on camera, set by {@link #setPosition(Vector3)} </li>
 * <li>target: Always keeps its eye on target, i.e. renders target at center of viewport set by {@link #setTarget(Vector3)}</li>
 * <li>bank: the banking angle of Up direction of camera set by {@link #bank(Vector3)}</li>
 * </ol>
 * Note that local rotation and scaling of camera has no effect on rendering scene, because camera's UVN axes(View Matrix) is determined by eye, target and bank angle only
 * @author maheshkurmi
 */
public class Camera extends SceneNode3D{

	/**
	 * Sets the camera as orthographic camera 
	 * 
		 * @param verticalFov
		 *            Field of view of camera in Y direction
		 * @param aspect
		 *            width/height ratio used to calculate FOV in x direction
		 * @param near
		 *            distance of near plane from camera (must be >0)
		 * @param far
		 *            distance of far plane from camera	
		 * @return this camera
	 */
	public Camera setAsPerspective(float verticalFov, float aspect, float near, float far){
		return this;
		
	}
	
	/**
	 * Sets the camera as perspective camera 
	 * 
		 * @param verticalFOV
		 *            Field of view of camera in Y direction
		 * @param aspect
		 *            width/height ratio used to calculate FOV in x direction
		 * @param near
		 *            distance of near plane from camera (must be >0)
		 * @param far
		 *            distance of far plane from camera	
		 * @return this camera
	 */
	public Camera setAsOrthographic(float verticalFov, float aspect, float near, float far){
		return this;
		
	}
	
	/**
	 * Get whether this camera uses orthographic projection.
	 * 
	 * @return true if it does; false otherwise.
	 */
	public boolean isOrthographic() {
		return false;
	}

	/**
	 * Set whether this camera should use orthographic projection , all frustum parameters remain same
	 * 
	 * @param isOrthographic
	 *            true if it should; false otherwise.
	 */
	public void setOrthographic(boolean isOrthographic) {
	}
	
	
	
	/**
	 * Enables trackball
	 */
	public void setTrackBallEnabled(boolean enable){
	
	}
	
	/**
	 * Returns orbit controller for the camera
	 * @return {orbitControl}
	 */
	public OrbitControl getTrackBallController(){
		return null;
	}
	
	/**
	 * Sets position of Camera in world space
	 * 
	 * @param position
	 *            Position of camera (eye) in world coordinates
	 */
	@Override
	public void setPosition(Vector3 position) {
	}


	/**
	 * Set position according relative to the parent's local coordinates
	 * 
	 * @param x
	 * @param y
	 * @param z
	 */
	@Override
	public void setPosition(float x, float y, float z) {
	}
	
	/**
	 * Returns the target camera looking at
	 * @return {Vector3}
	 */
	public Vector3 getTarget(){
		return null;
	}
	
	/**
	 * Sets the target camera looking at
	 * 
	 * @param target
	 *            the point to look at in parents coordinates
	 */
	public void setTarget(Vector3 target) {
	}

	/**
	 * Sets the target camera looking at in parent coordinate
	 * 
	 * @param x
	 * @param y
	 * @param z
	 */
	public void setTarget(float x, float y, float z) {
	}
	
	/**
	 * {number} the distance of Camera frustum near plane from camera 
	 */
	public float near=0;
	
	/**
	 * {Number} the distance of Camera frustum near plane from camera
	 */
	public float far=0;
	
	/**
	 * {Number} the distance of Camera frustum left plane from camera
	 */
	public float left=0;
	
	/**
	 * {Number} the distance of Camera frustum right plane from camera
	 */
	public float right=0;
	
	
	/**
	 * {Number} the distance of Camera frustum top plane from camera
	 */
	public float top=0;
	
	/**
	 * {Number} the distance of Camera frustum bottom plane from camera
	 */
	public float bottom=0;
	
	

	/**
	 * {Number} Camera frustum vertical field of view, from bottom to top of view, in degrees.
	 */
	public float fov;
	

	
	/**
	 * {Number} Camera frustum aspect ratio, usually the canvas width / canvas height
	 */
	public float aspect;
	


	/**
	 * Rotate the camera around Axis in World space.
	 * 
	 * @param the
	 *            3D rotation angles (in Degrees).
	 * 
	 */
	public void rotateAboutAxes(float theta_x, float theta_y, float theta_z) {
	}

	/**
	 * Rotate the camera around its focal point.
	 * 
	 * @param ya
	 *            : angle to be rotated about U axis (in degrees).
	 * @param pitch
	 *            : angle to be rotated about N axis (in degrees).
	 * @param roll
	 *            : angle to be rotated about V axis (in degrees).
	 * 
	 */
	public void rotateAroundFocus(double ya, double pitch, double roll) {
	}

	/**
	 * Translate the camera in World space in such a way the projection on view Plane translates accordingly. It is
	 * achieved by translating eye(camera position) as well as focus by x and y along U and V axis (in world space)
	 * respectively.
	 * 
	 * @param x
	 *            Amount camera translates along its right (U axis).
	 * @param y
	 *            Amount camera translates along its up (V axis)
	 */
	public void pan(float dx, float dy) {
	}
	
	

	/**
	 * Banks camera,or we can say rolls cameras UP vector clockwise, so that the projection on view Plane seems to be
	 * rotating about a line joining focus and eye(N Vector).
	 * 
	 * @param theta
	 *            the angle in Degrees by which camera UP vector rotates clockwise.
	 */
	public void bank(float theta) {
	}
	
	/**
	 * Sets this camera as replica of specified camera <br>
	 * Note that only camera related properties are copied not scenegraph related like parent and children
	 * @param {Camera} camera
	 * @return this camera
	 */
	public Camera set(Camera camera){
		return this;
	}
	
	/**
	 * Returns the copy of this camera node
	 */
	@Override
	public Camera clone() {
		return this;
	}

	

}