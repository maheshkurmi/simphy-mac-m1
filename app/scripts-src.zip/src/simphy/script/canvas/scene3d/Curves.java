package simphy.script.canvas.scene3d;

import java.awt.Shape;
import java.util.ArrayList;
import java.util.function.Function;

import simphy.script.Vector3;
import simphy.script.canvas.Path2D;

public class Curves {
	
	private Curves(){
		
	}
	

	
	/**
	 * Creates new Line Joining the vertices v1 and v2
	 * @param v1
	 * @param v2
	 * @return
	 */
	public Curve newLineCurve(Vector3 v1, Vector3 v2){
		return null;
	}

	
	/**
	 * Creates parametric curve for t ranging from 0 to 1
	 * 
	 * @param function
	 *            Function that takes float as argument and returns {@link Vector3} corresponding to it
	 */
	public Curve newParaMetricCurve(Function<Float, Vector3> function)  {
		return null;
	}

	/**
	 * Creates parametric curve for t ranging from 0 to 1
	 * 
	 * @param exprX
	 * @param exprY
	 * @param exprZ
	 * @throws Exception
	 */
	public Curve newParaMetricCurve(String exprX, String exprY, String exprZ)  {
		return null;
	}

	/**
	 * Creates A smooth 3d spline curve from a series of points using the Catmull-Rom algorithm. 
	 * @param closed
	 *            The curve will loop back onto itself when this is true.
	 * @param tension
	 *           Tension of the curve (default 0.5f)
	 * @param curveType
	 *            Possible values are 0=catmullrom, 1=centripetal and 2=chordal
	 * @param pts
	 *            An array of Vector3 points
	 */
	public Curve newSplineCurve(boolean closed, float tension, int curveType, Vector3... pts){
		return null;
	}
	
	/**
	 * Creates A curve representing a continuous curve formed by connecting successive points
	 * @param {Vector3[]} pts
	 */
	public Curve newPolyLineCurve(Vector3... pts) {
		return null;
	}
		
	/**
	 * Creates Curve from Path2D object
	 * 
	 * @param path
	 *            non null Path2D object
	 * @param fineNess
	 *            maximum deviation from original curve
	 */
	public Curve newCurveFromPath2D(Path2D path, float fineNess) {
		return null;
	}
}
