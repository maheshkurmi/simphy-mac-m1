package simphy.script.canvas.scene3d;

import java.nio.FloatBuffer;
import java.nio.ShortBuffer;
import java.util.List;



/**
 * Mesh for the Geometry
 * 
 * @author maheshkurmi
 *
 */
public class Mesh {
	/**
	 * Create Empty Mesh
	 */
	public Mesh(){
		
	}

	/**
	 * Creates copy of the mesh, Note that it is shallow copy , the data is not copied
	 */
	public Mesh clone(){
		return null;
	}
	
	 /**
     * Returns the material .
     * @return The material object
     */
    public Material getMaterial() {
    	return null; 
    }
    
    /**
     * Sets new material .
     * @param The material object
     */
    public void setMaterial(Material material){
    }

 
   
    /**
     * Returns the bounding box.
     * @return The bounding box
     */
    public Bounds getBounds(){
    	return null;
    }
    
    /**
     * Checks if model group has normals.
     *
     * @return True if it has normals, false if not
     */

    public boolean hasNormals()
    {
        return false;
    }


    /**
     * Checks if model group has texture coordinates.
     *
     * @return True if it has texture coordinates, false if not
     */

    public boolean hasTexCoords()
    {
        return false;
    }
    

    /**
     * Returns the number of indices.
     *
     * @return The number of indices
     */

    public int getIndexCount()
    {
        return 0;
    }


    /**
     * Returns the number of vertices in this model group.
     *
     * @return The number of vertices
     */

    public int getVertexCount(){
        return 0;
    }
    

}