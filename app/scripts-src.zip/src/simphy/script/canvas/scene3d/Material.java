package simphy.script.canvas.scene3d;

import simphy.script.Color;

public  class Material {
	/**
	 * Defaults taken from
	 * http://www.it.hiof.no/~borres/j3d/explain/light/p-materials.html
	 */
	public  static Material DEFAULT=new Material("default",
			new float[]{0.2f, 0.2f, 0.2f, 1}, 
			new float[]{0.1f,0.1f,0.1f,1},
			new float[]{1f, 1f, 1f, 1}, 
			27.0f);
	
	public  static Material BRASS=new Material("brass",
			new float[]{0.33f, 0.22f, 0.03f, 1}, 
			new float[]{0.78f, 0.57f, 0.11f, 1},
			new float[]{0.99f, 0.91f, 0.81f, 1}, 
			27.0f);
	
	public  static Material BRONZE=new Material("bronze",
			new float[]{0.25f, 0.148f, 0.06475f, 1.0f }, 
			new float[]{0.4f, 0.2368f, 0.1036f, 1.0f },
			new float[]{0.774597f, 0.458561f, 0.200621f, 1.0f}, 
			76.8f);
	public  static Material CHROME=new Material("chrome",
			new float[]{0.25f, 0.25f, 0.25f, 1.0f}, 
			new float[]{0.4f, 0.4f, 0.4f, 1.0f},
			new float[]{0.774597f, 0.774597f, 0.774597f, 1.0f }, 
			76.8f);
	public  static Material COPPER=new Material("copper",
			new float[]{0.2295f, 0.08825f, 0.0275f, 1.0f }, 
			new float[]{0.5508f, 0.2118f, 0.066f, 1.0f},
			new float[]{0.580594f, 0.223257f, 0.0695701f, 1.0f}, 
			51.0f);
	public  static Material GOLD=new Material("gold",
			new float[]{0.24725f, 0.1995f, 0.0745f, 1.0f}, 
			new float[]{0.75164f, 0.60648f, 0.22648f, 1.0f },
			new float[]{0.628281f, 0.555802f, 0.366065f, 1.0f}, 
			27.0f);
	public  static Material TIN=new Material("tin",
			new float[]{0.105882f, 0.058824f, 0.113725f, 1.0f}, 
			new float[]{0.427451f, 0.470588f, 0.541176f, 1.0f },
			new float[]{0.333333f, 0.333333f, 0.521569f, 1.0f }, 
			10.0f);
	public  static Material SILVER=new Material("silver",
			new float[]{0.19225f, 0.19225f, 0.19225f, 1.0f}, 
			new float[]{0.50754f, 0.50754f, 0.50754f, 1.0f},
			new float[]{0.508273f, 0.508273f, 0.508273f, 1.0f}, 
			52.6f);
	public  static Material EMERALD=new Material("emerald",
			new float[]{0.0215f, 0.1745f, 0.0215f, 0.55f}, 
			new float[]{0.07568f, 0.61424f, 0.07568f, 0.55f},
			new float[]{0.633f, 0.727811f, 0.633f, 0.55f}, 
			76.8f);
	public  static Material PERL=new Material("perl",
			new float[]{0.25f, 0.20725f, 0.20725f, 0.922f }, 
			new float[]{1.0f, 0.829f, 0.829f, 0.922f},
			new float[]{0.296648f, 0.296648f, 0.296648f, 0.922f}, 
			11.0f);
	public  static Material RUBY=new Material("ruby",
			new float[]{0.1745f, 0.01175f, 0.01175f, 0.55f}, 
			new float[]{0.61424f, 0.04136f, 0.04136f, 0.55f },
			new float[]{0.727811f, 0.626959f, 0.626959f, 0.55f }, 
			76.0f);
	public  static Material TURQOISE=new Material("Turquoise",
			new float[]{0.1f, 0.18725f, 0.1745f, 0.8f }, 
			new float[]{0.396f, 0.74151f, 0.69102f, 0.8f},
			new float[]{0.297254f, 0.30829f, 0.306678f, 0.8f }, 
			12.0f);
	public  static Material RED=new Material("red-plastic",
			new float[]{0.1f,0.0f,0.0f,1.0f}, 
			new float[]{0.5f,0.0f,0.0f,1.0f},
			new float[]{0.7f,0.6f,0.6f,1.0f}, 
			32.0f);
	public  static Material GREEN=new Material("green-plastic",
			new float[]{0.0f,0.0f,0.0f,1.0f  }, 
			new float[]{0.1f,0.35f,0.1f,1.0f},
			new float[]{0.45f,0.55f,0.45f,1.0f  }, 
			32.0f);
	public  static Material YELLOW=new Material("yellow-plastic",
			new float[]{0.0f,0.0f,0.0f,1.0f  }, 
			new float[]{0.5f,0.5f,0.0f,1.0f },
			new float[]{0.60f,0.60f,0.50f,1.0f }, 
			32.0f);
	public  static Material BLUE=new Material("blue-plastic",
			new float[]{0.0f,0.1f,0.06f ,1.0f }, 
			new float[]{0.0f, 0.0f, 0.69102f, 1f},
			new float[]{0.50196078f,0.50196078f,0.50196078f,1.0f }, 
			32.0f);
	public  static Material BLACK=new Material("black-plastic",
			new float[]{0.0f, 0.0f, 0.0f, 1.0f }, 
			new float[]{0.01f, 0.01f, 0.01f, 1.0f },
			new float[]{0.50f, 0.50f, 0.50f, 1.0f}, 
			32.0f);
	public  static Material CYAN=new Material("cyan-plastic",
			new float[]{0.0f,0.05f,0.05f,1.0f }, 
			new float[]{0.4f,0.5f,0.5f,1.0f },
			new float[]{0.04f,0.7f,0.7f,1.0f  }, 
			32.0f);
	public  static Material WHITE=new Material("white-plastic",
			new float[]{0.0f,0.0f,0.0f,1.0f }, 
			new float[]{0.55f,0.55f,0.55f,1.0f},
			new float[]{0.70f,0.70f,0.70f,1.0f  }, 
			32.0f);
	

	/**
	 * private constructors to create default materials
	 * @param id
	 * @param ambient float array of size 4 (each element in [0,1])
	 * @param diffuse float array of size 4 (each element in [0,1])
	 * @param specular float array of size 4 (each element in [0,1])
	 * @param shininess float array of size 4 (each element in [0,1])
	 */
	private Material(String id,float[] ambient, float[] diffuse, float[] specular, float shininess) {
		
	}
	
	public Material(Color color){
		
	}
	
	/**
	 * Sets identifier for the material
	 * @param id
	 */
	public void setId(String id){
	}
	
	/**
	 * Returns identifier of material
	 * @return
	 */
	public String getId(){
		return null;
	}
	
	/**
     * Sets texture for the material
     * @param imageName {String} Name of image already loaded in Simphy
     */
    public void setTexture(String imageName){
    	
    }

    /**
     * returns name of Image being used as texture for the material
     * @return {String}
     */
    public String getTexture(){
    	return null;
    }
    
    /**
     * Sets the opacity of material (Default=1}
     * @param opacity (Number} 0=fully transparent, 1= fully opaque
     */
    public void setOpacity(float opacity){
    }
    
    /**
     * Returns opacity of material
     * @return
     */
    public float setOpacity(){
    	return 0;
    }
    
  
	/**
	 * Material to render Mesh as Lines instead of filled triangles, with lighting disabled
	 * @param color {Color} color used to render mesh
	 * @param lineWidth {float} width of lines in pixels used to render material
	 * @return {Material} 
	 */
    public Material setAsLineMaterial(Color color,float lineWidth){
       	return this;
    }
    /**
	 * Material to render Mesh as points instead of filled triangles, with lighting disabled
	 * @param color {Color} color used to render mesh
	 * @param lineWidth {float} width of lines in pixels used to render material
	 * @return {Material} 
	 */
    public Material setAsPointMaterial(Color color,float pointSize){
    	return this;
    }
    
    /**
   	 * Material to render Mesh as points instead of filled triangles, with lighting disabled
   	 * @param color {Color} color used to render mesh
   	 * @param lineWidth {float} width of lines in pixels used to render material
   	 * @return {Material} 
   	 */
    public Material setAsFlatColorMaterial(Color color){
       	return this;
    }
    
    /**
	 * Creates material with lighting enabled & diffused color set as color
	 * @param color {Color} diffused color of material
	 * @param shininess {Number} a number in the range 0 to 128, a the number increases, specular highlights get smaller. 
	 * @see {@link Material#setDiffused(float, float, float)}
	 * @see {@link Material#setSpecular(float, float, float)}
	 * @see {@link Material#setAmbient(float, float, float)}
	 * @see {@link Material#isSmoothShading()}
	 */
	public Material setAsLightMaterial(Color color, float shininess){
		return this;
	}
	
	/**
	 * Sets this material from preset materials
	 * @param presetName {String} Identifier name of the material like "gold", "silver","red","emerald" etc
	 * @return
	 */
	public Material setAsPresetMaterial(String presetName){
		return this;
	}
	
	/**
	 * If true backface (face whose normal is away from viewer) is not rendered at all (Default is false)<br>
	 * (by default it is true, but for transparent meshes and when view point is inside mesh)
	 */
	public void setBackFaceCulled(boolean backFaceCulled) {
	}
	
	/**
	 * Returns true if backface (face whose normal is away from viewer) is not rendered at all
	 */
	public boolean isBackFaceCulled() {
		return false;
	}

	/**
	 * Set the scale and units used to calculate depth values, It is is useful for rendering hidden-line images, for
	 * applying decals to surfaces, and for rendering solids with highlighted edges.
	 * 
	 * @param factor
	 *            Specifies a scale factor that is used to create a variable depth offset for each polygon. The
	 *            initial value is 0.
	 * @param unit
	 *            Is multiplied by an implementation-specific value to create a constant depth offset. The initial
	 *            value is 0. to disable it pass 0 , 0 as parameters
	 */
	public void setPolygonOffset(float factor, float unit) {
	}

	 /**
     * Sets this object's diffuse color from an input Color. Defaults to {0.8,0.8,0.8,1.0}.
     * @param default_diffuse the color that the specular color is copied from - later changes to the Color object will not be reflected in this Material.
     */
	public void setDiffuse(float r, float g, float b){
	}

	 /**
     * This retrieves the diffuse color from this Material.
     * @return a new Color with components copied from this Material.
     */
    public Color getDiffuse() {
        return null;
    }
	  /**
     * Sets this object's ambient color from an input Color. Defaults to {0.2,0.2,0.2,1.0}.
     * @param default_ambient the color that the specular color is copied from - later changes to the Color object will not be reflected in this Material.
     */
	public void setAmbient(float r, float g, float b){	
	}

    /**
     * This retrieves the ambient color from this Material.
     * @return a new Color with components copied from this Material.
     */
    public Color getAmbient() {
        return null;
    }
    
	/**
    * Sets this object's specular color from an input Color. Default is {0,0,0,1}.
    * @param default_specular the color that the specular color is copied from - later changes to the Color object will not be reflected in this Material.
    */
	public void setSpecular(float r, float g, float b){
		
	}

	 /**
     * Retrieves the specular color from this Material.
     * @return a new Color with components copied from this Material.
     */
    public Color getSpecular() {
        return null;
    }
    
    /**
     * Sets this object's emissive color from an input Color. Default is {0,0,0,1}.
     * @param emissive the color that the specular color is copied from - later changes to the Color object will not be reflected in this Material.
     */
    public void setEmissive(Color emissive) {
    }
    
    /**
     * This retrieves the emissive color from this Material.
     * @return a new Color with components copied from this Material.
     */
    public Color getEmissive() {
        return null;
    }
    
    /**
     * shininess property determines the size and sharpness of specular highlights is called shininess. Shininess is a number in the range 0 to 128. 
     * As the number increases, specular highlights get smaller. 
     * @param shininess the value to use for shininess {default=64}
     */
    public void setShininess(float shininess) {
    }
    
    /**
     * Retrieves the shininess from this Material.
     * @return the shininess value
     */
    public float getShininess() {
        return 0;
    }

    /**
     * Specifies the face to which material should be applied
     * @param frontFace if true material is applied on front face
     * @param BackFace if true material is applied on back face
     */
    public void setMaterialFaces(boolean frontFace, boolean backFace){
    }
    
    /**
     * Sets flat or smooth shading while rendering Mesh in fillMode {Default : true}
     * @param smooth if true shading Mode is set smooth else it is set as flat
     */
    public void setSmoothShading(boolean smooth){
    }
    
    /**
     * Returns flat or smooth shading while rendering Mesh in fillMode
     * @return {boolean} true if shading Mode is set smooth else false
     */
    public boolean isSmoothShading(){
    	return false;
    }
    
    /**
     * Enables or disables lighting for the material (by default enabled is set true) <br>
     * If lighting is disabled it used diffuse {@link #setDiffuse(float, float, float)} to render object
     * @param lightingEnabled
     */
    public void setLightingEnabled(boolean lightingEnabled){
    }
    
    /**
     * Returns if lighting for the material (by default enabled is set true) <br>
     * @return {boolean}
     */
    public boolean isLightingEnabled(){
    	return false;
    }
    
    /**
     * Sets Texture Color blending with Material color true or false (Default: true)
     * @param textureBlending if true color of texture is blended with material color
     */
    public void setTextureColorBlending(boolean textureBlending){
    }

    /**
     * Returns if Texture Color blending with Material color is enabled
     * @param textureBlending {boolean}
     */
    public boolean isTextureColorBlending(){
    	return false;
    }

	/**
	 * Sets this material as a replica of specified material 
	 * @param m {Material} material to be copied in this  
	 * @return {Material} this material
	 */
	public  Material set(Material m){
		return this;
	}
	
	/**
	 * Returns new Copy of this material
	 * @return {Material}
	 */
	public  Material clone(){
		return this;
	}
	

}
