package simphy.script.canvas.scene3d;

import simphy.script.Color;

public class Scene3D extends simphy.script.canvas.Scene{
	

	public SceneNode3D getRoot(){
		return null;
	}
	
	public void setRoot(SceneNode3D root){
	}
	
	public Camera getCamera(){
		return null;
	}
	
	public void setCamera(Camera camera){
	}

	/**
	 * Sets and Enabled Fog for the scene
	 * @param fogColor {Color} Color of fog (Default: Black)
	 * @param near {float} near distance from camera view point where fog starts (Default 0)
	 * @param far {float} far distance from camera view point where fog ends {Default 100)
	 * @param fogDensity {float} value that specifies density, the fog density used in non linear fog. Only nonnegative densities are accepted. The initial fog density is 1.
	 * @param isLinear {boolean} if true linear fog equation is used else exponential equation is used (default true)
	 * @see {@link Scene3D#setFogEnabled(boolean)}
	 */
	public void setFog(Color fogColor,float near, float far, float fogDensity, boolean isLinear){
	}
	/**
	 * Enabled fog for the scene
	 * @see {@link Scene3D#setFog(Color, float, float, float)
	 * @see {@link Scene3D#setFog(Color, float, float, float, boolean)}
	 */
	public void setFogEnabled(boolean fogEnabled){
	}
	
	/**
	 * Returns true if fog is enabled for the scene
	 * @return {boolean}
	 */
	public boolean isFogEnabled(){
		return false;
	}
	

}
