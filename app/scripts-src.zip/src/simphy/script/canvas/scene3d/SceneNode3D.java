package simphy.script.canvas.scene3d;

import java.util.ArrayList;
import java.util.List;

import simphy.script.Vector3;


/**
 * A scene node. Can be used directly to create invisible group nodes or can be extended to implement other node types.
 *
 * @author Mahesh Kurmi
 */
public class SceneNode3D {

	/** Default material of the node, used if any child does't contain its own material */
	public Material material = null;
	
	  /** The physics of this node. */
    public Physics physics = null;

  
	public SceneNode3D() {
	}


	/**
	 * sets identifier name of node
	 * 
	 * @param name
	 */
	public void setName(String name) {
	}

	/**
	 * returns identifier name of this node
	 * 
	 * @return
	 */
	public String getName() {
		return null;
	}

	/**
	 * Returns the parent node. If the node has no root node yet then null is returned.
	 *
	 * @return The parent node or null if there is none
	 */

	public final SceneNode3D getParentNode() {
		return null;
	}

	/**
	 * Checks if this node has child nodes.
	 *
	 * @return True if this node has child nodes, false if not
	 */
	public final boolean hasChildNodes() {
		return false;
	}

	/**
	 * Returns array of children of this node if any else returns null
	 * 
	 * @return {Array} array of nodes
	 */
	public SceneNode3D[] getChildern() {
		return null;
	}



	/**
	 * Add a child to the node the function is invoked on if it is not already a child of this node.
	 * 
	 * @param child:
	 *            The node to add as a child of this node.
	 */
	public void addChild(SceneNode3D child) {
		
	};

	/**
	 * Remove a child from the node the function is invoked on if it is a child of this node.
	 * 
	 * @param child:
	 *            The node to remove as a child of this node.
	 */
	public void removeChild(SceneNode3D child) {
		
	};

	/**
	 * Remove a child from the node the function is invoked on if it is a child of this node.
	 * 
	 * @param child:
	 *            The node to remove as a child of this node.
	 */
	public void removeAllChildren() {

	};

	/**
	 * Adds a light so it illuminates this node and all child nodes (not the parent nodes).
	 *
	 * @param light
	 *            The light to add
	 */

	public void addLight(final Light light) {
		
	}

	/**
	 * Removes a light so it no longer illuminates this node and its child nodes.
	 *
	 * @param light
	 *            The light to remove
	 */

	public void removeLight(final Light light) {
	}

	 /**
     * Returns the physics of this scene node. <br> 
     * Note that calling this method guarantees non null object
     * @return The physics object of the node which can later be modified to control this node
     */
    public Physics getPhysics()
    {
    	return null;
    }
    
    /**
     * Sets the physics of this scene node.
     *
     * @return The physics object , can be null to disable physics for the node
     * @see #getPhysics()
     */
    public void setPhysics(Physics physics)
    {
        this.physics=physics;
    }
    

	/**
	 * Sets the current absolute scale
	 * 
	 * @param scale
	 *            {Vector3}: a vector determining the scale in x, y, z directions
	 */
	public void setScale(Vector3 scale) {
	};

	/**
	 * Sets the current absolute scale
	 *
	 * @param sx
	 *            The X scale factor
	 * @param sy
	 *            The Y scale factor
	 * @param sz
	 *            The Z scale factor
	 */
	public void setScale(float sx, float sy, float sz) {
	};

	/**
	 * Scale the node.E.g. make the node twice as large: scale = [2,2,2].
	 * 
	 * @param scale
	 *            {Vector3}
	 */
	public void scale(Vector3 scale) {
	};

	/**
	 * Scales the node by the specified factors.
	 *
	 * @param sx
	 *            The X scale factor
	 * @param sy
	 *            The Y scale factor
	 * @param sz
	 *            The Z scale factor
	 */
	public void scale(float sx, float sy, float sz) {
	};

	/**
	 * Set position according relative to the parent's position
	 * 
	 * @param position:
	 *            a new position
	 */
	public void setPosition(Vector3 position) {
	};

	/**
	 * Set position according relative to the parent's local coordinates
	 * 
	 * @param x
	 * @param y
	 * @param z
	 */
	public void setPosition(float x, float y, float z) {
	};

	/**
	 * Translate the node.
	 * 
	 * @param translation
	 *            {Vector3} translation in parent's local space
	 */
	public void translate(Vector3 translation) {
	};

	/**
	 * Translates the node relative to the parent's local coordinates
	 * 
	 * @param x
	 * @param y
	 * @param z
	 */
	public void translate(float x, float y, float z) {
	};

	/**
	 * Sets Rotation of the node about its local axis by the specified angle around the coordinate axes.
	 * 
	 * @param xRotation
	 *            angle in radians
	 * @param yRotation
	 *            angle in radians
	 * @param zRotation
	 *            angle in radians
	 */
	public void setRotation(float xRotation, float yRotation, float zRotation) {
	}

	/**
	 * Sets Rotation of the node about its local axis by the specified angle around the coordinate axes.
	 * 
	 * @param angles
	 *            {Vector3}: Vector3 having three euler angles in radians as its components
	 */
	public void setRotation(Vector3 angles) {
	};

	/**
	 * Rotates the current transformation matrix by the specified angle around the local coordinates axes.
	 */
	public void rotate(float xRotation, float yRotation, float zRotation) {
	}

	/**
	 * Rotate the node relative to it's parent.
	 * 
	 * @param angles
	 *            {Vector3}: Vector3 having three euler angles in radians as its components
	 */
	public void rotate(Vector3 angles) {
	};

	/**
	 * Sets Material of the node, its children automatically inherit the material from this node
	 * 
	 * @param material
	 */
	public void setMaterial(Material material) {
	}

	/**
	 * returns current Material of the node
	 * 
	 * @return
	 */
	public Material getMaterial() {
		return null;
	}

	/**Creates copy of the node*/
	public SceneNode3D clone() {
		return null;
	}

}
