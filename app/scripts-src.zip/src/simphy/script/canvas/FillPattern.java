package simphy.script.canvas;

import simphy.script.Color;

public abstract class FillPattern {

	

}
