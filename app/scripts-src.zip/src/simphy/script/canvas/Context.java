package simphy.script.canvas;

public class Context {

	// ************************************CANVAS API ATTRIBUTES*******************************//
	/**
	 * Canvas to which context is associated (Read only)
	 */
	public Canvas canvas;
	
	/**
	 * This sets the type of compositing operation to apply when drawing new shapes, where type is a string identifying
	 * which of the twelve compositing operations to use. <br>
	 *
	 * can be "source-over"[default]|"source-in"|"destination-over" etc
	 */
	public String globalCompositeOperation = null;

	/** Global transparency in [0,1] where 0 mean full transparent and 1 [default] means full opaque */
	public double globalAlpha;

	/**
	 * The current style to render filled shapes,all subsequent Shapes are filled using this style <br>
	 *           Can be one of following<br>
	 *            <ul>
	 *            <li><b>Color :</b> Color Object or a String parsed as CSS color value.
	 *            <li><b>Gradient :</b> A Gradient object (a linear or radial gradient).
	 *            <li><b>Pattern :</b> A FillPattern object (a repeating image).
	 *            <li><b>String :</b> Css color string , for example<br>
	 *            <ol>
	 *            <li>Common color name "red", "green"</li>
	 *            <li>Hexadecimal representation of color such as #FF0096 or 0xFF0096</li>
	 *            <li>Color functions "rgb(255,0,0)","hsl(180, 50%, 50%)","rgba(255,255,120,1)"</li>
	 */
	public Object fillStyle = null;

	/**
	 * The current StrokeStyle,all subsequent Shapes are outlines using this style <br>
 	 *	Can be one of following<br>
	 *            <ul>
	 *            <li><b>Color :</b> Color Object or a String parsed as CSS color value.
	 *            <li><b>Gradient :</b> A Gradient object (a linear or radial gradient).
	 *            <li><b>Pattern :</b> A FillPattern object (a repeating image).
	 *            <li><b>String :</b> Css color string , for example<br>
	 *            <ol>
	 *            <li>Common color name "red", "green"</li>
	 *            <li>Hexadecimal representation of color such as #FF0096 or 0xFF0096</li>
	 *            <li>Color functions "rgb(255,0,0)","hsl(180, 50%, 50%)","rgba(255,255,120,1)"</li>
	 */
	public Object strokeStyle = null;

	/**
	 * the current stroke width used to stroke shapes in pixel, default value is 1
	 */
	public double lineWidth;

	/**
	 * The horizontal distance the shadow should extend from the object. This value isn't affected by the transformation
	 * matrix. The default is 0.
	 */
	public double shadowoffsetX = 0;

	/**
	 * The vertical distance the shadow should extend from the object. This value isn't affected by the transformation
	 * matrix. The default is 0.
	 */
	public double shadowoffsetY = 0;

	/**
	 * The size of the blurring effect; this value doesn't correspond to a number of pixels and is not affected by the
	 * current transformation matrix. The default value is 0.
	 */
	public double shadowBlur = 0;

	/**
	 * The color of the shadow effect; by default, it is fully-transparent black. <br>
  	 * {Object} Can be one of following<br>
	 *            <ul>
	 *            <li><b>Color :</b> Color Object or a String parsed as CSS color value.
	 *            <li><b>String :</b> Css color string , for example<br>
	 *            <ol>
	 *            <li>Common color name "red", "green"</li>
	 *            <li>Hexadecimal representation of color such as #FF0096 or 0xFF0096</li>
	 *            <li>Color functions "rgb(255,0,0)","hsl(180, 50%, 50%)","rgba(255,255,120,1)"</li>
	 */
	public Object shadowColor = null;

	/**
	 * The horizontal alignment of text <br>
	 * the value can be "Left"(default), "Center", "Right","Start", or "End"
	 */
	public String textAlign = null;

	/**
	 * The vertical alignment of text <br>
	 * The value can be "Alphabetic" (default), "Top", "Hanging", "Middle","Ideographic", or "Bottom"
	 */
	public String textBaseline = null;

	/**
	 * The current font, all subsequent text are drawn using this font <br>
	 * 
	 * The value is a case insensitive case CSS-font string indicating fontName, fontStyle and fotnSize separated by
	 * space in any order. Few valid examples are: <br>
	 * 
	 * <pre>
	 * "32px bold Arial", "Arial italic" ,"bold dialog 32px", "Dialog 12"
	 * </pre>
	 */
	public String font = null;

	/**
	 * The style of line joints for rendering a path with Stroke. <br>
	 * The value can be "Miter", "Bevel"(default), or "Round"
	 */
	public String lineJoin = null;

	/**
	 * The style of line endings for rendering a path with Stroke <br>
	 * The value can be "Butt"(default), "Square", or "Round"
	 */
	public String lineCap = null;

	/**
	 * The limit (default==10) for how far a miter line join can be extend. (must be >1)
	 */
	public double miterLimit = 0;

	/** The line dash stype */
	public double[] lineDash = null;

	/**
	 * The line dash offset, or "phase." <br>
	 * A float specifying the amount of the line dash offset. The default value is 0.0.
	 */
	public double lineDashOffset = 0;

	/**
	 * Resets canvas to initial default state
	 */
	public void reset() {

	}

	// ************************************CANVAS API COMMANDS*******************************//

	/**
	 * Save saves the current draw state to a stack
	 */
	public void save() {
	}

	/**
	 * Restore restores the last draw state from the stack if available
	 */
	public void restore() {
	}

	/**
	 * Returns a TextMetrics object containing the width, in pixels, that the specified text will be when drawn in the
	 * current text style.
	 * @param text {String} text to be measured
	 * @return TextMetrics Object {width, height, actualBoundingboxAscent,actualBoundingboxDescent)
	 */
	public TextMetrics measureText(String text) {
		return null;
	}

	/**
	 * Creates a linear gradient along the line connecting two given coordinates.<br>
	 * <b>Note:</b> Gradient coordinates are global, i.e., relative to the current coordinate space. When applied to a
	 * shape, the coordinates are NOT relative to the shape's coordinates.
	 * 
	 * @param x0
	 *            The x-axis coordinate of the start point.
	 * @param y0
	 *            The y-axis coordinate of the start point.
	 * @param x1
	 *            The x-axis coordinate of the end point.
	 * @param y1
	 *            The y-axis coordinate of the end point.
	 * @return a LinearGradient object. To be applied to a shape, the gradient must first be assigned to the
	 *         {@link #setFillStyle(Object)} or {@link #setFillStyle(Object)} properties.<br>
	 *         <br>
	 *         Note: use {@link #Gradient.addColorStop(pos,col)} method of returning object to create gradient colors
	 */
	public Gradient createLinearGradient(double x0, double y0, double x1, double y1) {
		return null;
	}

	/**
	 * Creates a radial gradient using the size and coordinates of two circles.<br>
	 * <b>Note:</b> Gradient coordinates are global, i.e., relative to the current coordinate space. When applied to a
	 * shape, the coordinates are NOT relative to the shape's coordinates.
	 * 
	 * @param x0
	 *            The x-axis coordinate of the start circle.
	 * @param y0
	 *            The y-axis coordinate of the start circle.
	 * @param r0
	 *            The radius of the start circle. Must be non-negative and finite.
	 * @param x1
	 *            The x-axis coordinate of the end circle.
	 * @param y1
	 *            The y-axis coordinate of the end circle.
	 * @param r1
	 *            The radius of the end circle. Must be non-negative and finite.
	 * @return a RadialGradient object. To be applied to a shape, the gradient must first be assigned to the
	 *         {@link #setFillStyle(Object)} or {@link #setFillStyle(Object)} properties.<br>
	 *         <br>
	 *         Note: use {@link #Gradient.addColorStop(pos,col)} method of returning object to create gradient colors
	 */
	public Gradient createRadialGradient(double x0, double y0, double r0, double x1, double y1, double r1) {
		return null;
	}

	/**
	 * Creates a pattern using the specified image and repetition.<br>
	 * <b>Note:</b> Gradient coordinates are global, i.e., relative to the current coordinate space. When applied to a
	 * shape, the coordinates are NOT relative to the shape's coordinates.
	 * 
	 * @param image
	 *            {Image} An Image to be used as the pattern's image.
	 * @param repeat
	 *            {String} indicating how to repeat the pattern's image. Possible values are:
	 *            "repeat"|"repeat-x"|"repeat-y"|"no-repeat"
	 * @return a FillPattern object. To be applied to a shape, the pattern must first be assigned to the
	 *         {@link #setFillStyle(Object)} or {@link #setFillStyle(Object)} properties.<br>
	 */
	public FillPattern createPattern(Image img, String repeat) {
		return null;
	}

	// ************************************Rendering Commands ***********************************

	/**
	 * Clears canvas and removes all render commands as well as resets transform to identity (Note that active
	 * animations are not cleared by this command
	 * 
	 * @see {@link #clearAnimations()}
	 */
	public void clear() {
	}

	/**
	 * Clears the specified pixels within a given rectangle. replaces the portion in this rectangle by background color
	 * (or image if any) Note: Takes current transform in account
	 * 
	 * @param x
	 *            {Number} The x-axis coordinate of the rectangle's starting point.
	 * @param y
	 *            {Number} The y-axis coordinate of the rectangle's starting point.
	 * @param width
	 *            {Number} The rectangle's width. Positive values are to the right
	 * @param height
	 *            {Number} The rectangle's height. Positive values are down
	 */
	public void clearRect(double x, double y, double width, double height) {
	}

	/**
	 * turns the current path into the current clipping region. It replaces any previous clipping region.
	 */
	public void clip() {
	}

	/**
	 * turns the current path into the current clipping region. It replaces any previous clipping region.
	 * 
	 * @param windingRule
	 *            The algorithm by which to determine if a point is inside or outside the filling region. Possible
	 *            values:<br>
	 *            "nonzero": The non-zero winding rule. Default rule.<br>
	 *            "evenodd": The even-odd winding rule.
	 */
	public void clip(String windingRule) {
	}

	/**
	 * turns the given path into the current clipping region. It replaces any previous clipping region.
	 * 
	 * @param path
	 *            {path2D} A path to clip.
	 */
	public void clip(Path2D path) {
	}

	/**
	 * turns the given path into the current clipping region. It replaces any previous clipping region.
	 * 
	 * @param path
	 *            {path2D} A path to clip.
	 * @param windingRule
	 *            The algorithm by which to determine if a point is inside or outside the filling region. Possible
	 *            values:<br>
	 *            "nonzero": The non-zero winding rule. Default rule.<br>
	 *            "evenodd": The even-odd winding rule.
	 */
	public void clip(Path2D path, String windingRule) {
	}

	/**
	 * draws a filled oval whose center is at (x, y) and whose size is specified by width and height This method draws
	 * directly to the canvas without modifying the current path, so any subsequent fill() or stroke() calls will have
	 * no effect on it. The fill style is determined by the current fillStyle attribute.<br>
	 * Note: Takes current transform in account
	 * 
	 * @param {number}
	 *            x centre x
	 * @param {number}y
	 *            center y
	 * @param {number}w
	 *            width of oval
	 * @param {number}h
	 *            height of oval
	 */
	public void fillOval(double cx, double cy, double w, double h) {
	}

	/**
	 * draws an oval that is stroked (outlined) according to the current strokeStyle and other context settings. This
	 * method draws directly to the canvas without modifying the current path, so any subsequent fill() or stroke()
	 * calls will have no effect on it.<br>
	 * Note: Takes current transform in account
	 * 
	 * @param cx
	 *            {number} center x
	 * @param cy
	 *            {number} center y
	 * @param w
	 *            {number} width of oval
	 * @param h
	 *            {number} height of oval
	 */
	public void strokeOval(double cx, double cy, double w, double h) {
	}

	/**
	 * draws a filled rectangle whose starting point is at (x, y) and whose size is specified by width and height This
	 * method draws directly to the canvas without modifying the current path, so any subsequent fill() or stroke()
	 * calls will have no effect on it. The fill style is determined by the current fillStyle attribute.<br>
	 * Note: Takes current transform in account
	 * 
	 * @param {number}
	 *            x top left x
	 * @param {number}y
	 *            top left y
	 * @param {number}w
	 *            width of rect
	 * @param {number}h
	 *            height of rect
	 */
	public void fillRect(double x, double y, double w, double h) {
	}

	/**
	 * draws a rectangle that is stroked (outlined) according to the current strokeStyle and other context settings.
	 * This method draws directly to the canvas without modifying the current path, so any subsequent fill() or stroke()
	 * calls will have no effect on it.<br>
	 * Note: Takes current transform in account
	 * 
	 * @param {number}
	 *            x top left x
	 * @param {number}y
	 *            top left y
	 * @param {number}w
	 *            width of rectangle
	 * @param {number}h
	 *            height of rectangle
	 */
	public void strokeRect(double x, double y, double w, double h) {
	}

	/**
	 * fills the current path with the current fillStyle.
	 * 
	 * @param windingRule
	 *            The algorithm by which to determine if a point is inside or outside the filling region. Possible
	 *            values:<br>
	 *            "nonzero": The non-zero winding rule. Default rule.<br>
	 *            "evenodd": The even-odd winding rule.
	 */
	public void fill(String windingRule) {
	}

	/**
	 * Draws the shape (current path) by stroking its outline with current strokeStyle.
	 */
	public void stroke() {
	}

	/**
	 * Draws the path by stroking its outline with current strokeStyle. Note: The path is transformed with current
	 * transform before rendering
	 * 
	 * @param path
	 *            {path2D} A path to stroke.
	 */
	public void stroke(Path2D path) {
	}

	/**
	 * fills the current path with the current fillStyle.
	 */
	public void fill() {
	}

	/**
	 * fills the current path with the current fillStyle. Note: The path is transformed with current transform before
	 * rendering
	 * 
	 * @param path
	 *            {path2D} A path to fill.
	 */
	public void fill(Path2D path) {
	}

	/***
	 * fills the given path with the current fillStyle.<br>
	 * Note: The path is transformed with current transform before rendering
	 * 
	 * @param path
	 *            {path2D} A path to fill.
	 * @param windingRule
	 *            The algorithm by which to determine if a point is inside or outside the filling region. Possible
	 *            values:<br>
	 *            "nonzero": The non-zero winding rule. Default rule.<br>
	 *            "evenodd": The even-odd winding rule.
	 */
	public void fill(Path2D path, String windingRule) {
	}

	/**
	 * draws a text string at the specified coordinates, filling the string's characters with the current fillStyle
	 * 
	 * @param
	 * @param
	 */
	public void fillText(String text, double x, double y) {
	}

	/**
	 * draws the outlines of — the characters of a text string at the specified coordinates.
	 * 
	 * @param
	 * @param
	 */
	public void strokeText(String text, double x, double y) {
	}

	/**
	 * Draws Image/Animation (unscaled)
	 * 
	 * @param imageName
	 * @param {number}
	 *            x top left x coordinate of destination rectangle
	 * @param {number}y
	 *            top left y coordinate of destination rectangle
	 */
	public void drawImage(Image img, double x, double y) throws Exception {
	}

	/**
	 * Draws Image/Animation (stretched if necessary) to fit inside the specified rectangle
	 * 
	 * @param imageName
	 * @param {number}x
	 *            top left x coordinate of destination rectangle
	 * @param {number}y
	 *            top left y coordinate of destination rectangle
	 * @param {number}w
	 *            width of destination rectangle (if w==0 then image is not stretched in X direction)
	 * @param {number}h
	 *            height of destination rectangle(if h==0 then image is not stretched in Y direction)
	 */
	public void drawImage(Image img, double x, double y, double w, double h) throws Exception {
	}

	/**
	 * Draws Portion of Image to fit inside the specified rectangle
	 * 
	 * @param imageName
	 * @param {number}sx
	 *            The x coordinate where to start clipping
	 * @param {number}sy
	 *            The y coordinate where to start clipping
	 * @param {number}sw
	 *            The width of the clipped image
	 * @param {number}sh
	 *            The height of the clipped image
	 * @param {number}x
	 *            top left x coordinate of destination rectangle
	 * @param {number}y
	 *            top left y coordinate of destination rectangle
	 * @param {number}w
	 *            width of destination rectangle
	 * @param {number}h
	 *            height of destination rectangle
	 */
	public void drawImage(String imageName, double sx, double sy, double sw, double sh, double x, double y, double w,
			double h) throws Exception {
	}

	// ***************************************Transform Methods***********************************
	/**
	 * updates the current transformation with a scaling by the given values
	 * 
	 * @param {Number}
	 *            sx
	 * @param {Number}
	 *            sy
	 */
	public void scale(double scaleX, double scaleY) {
	}

	/**
	 * updates the current transformation with a translation by the given values
	 * 
	 * @param {Number}
	 *            tx
	 * @param {Number}
	 *            ty
	 */
	public void translate(double tx, double ty) {
	}

	/**
	 * updates the current transformation with a rotation by the given angle
	 * 
	 * @param {Number}th
	 *            The rotation angle in radians. (Clockwise as positive)
	 */
	public void rotate(double th) {
	}

	/**
	 * Resets the current transform to the identity matrix, and then runs
	 * {@link #transform(double, double, double, double, double)} with the same arguments.
	 * 
	 * @param a
	 *            {Number} Horizontal scaling. A value of 1 results in no scaling.
	 * @param b
	 *            {Number} Vertical skewing. (0 means o skewing)
	 * @param c
	 *            {Number} Horizontal skewing. (0 means o skewing)
	 * @param d
	 *            {Number} Vertical scaling. A value of 1 results in no scaling.
	 * @param e
	 *            {Number} Horizontal translation (moving).
	 * @param f
	 *            {Number} Vertical translation (moving).
	 * @see #setTransform(double, double, double, double, double)
	 * @see #resetTransform()
	 */
	public void setTransform(double a, double b, double c, double d, double e, double f) {
	}

	/**
	 * Resets the current transform to the identity matrix, and then runs {@link #transform(Transform)} with the same
	 * arguments.
	 * 
	 * @param transform
	 * @param f
	 */
	public void setTransform(Transform transform) {
	}

	/**
	 * Multiplies the current transformation with the matrix described by the arguments of this method.Transforms point
	 * (x,y) to (x'y') as below
	 * 
	 * <pre>
	 * x'=ax+cy+e
	 * y'=by+dx+f
	 * </pre>
	 * 
	 * @param a
	 *            {Number} Horizontal scaling. A value of 1 results in no scaling.
	 * @param b
	 *            {Number} Vertical skewing. (0 means o skewing)
	 * @param c
	 *            {Number} Horizontal skewing. (0 means o skewing)
	 * @param d
	 *            {Number} Vertical scaling. A value of 1 results in no scaling.
	 * @param e
	 *            {Number} Horizontal translation (moving).
	 * @param f
	 *            {Number} Vertical translation (moving).
	 * @see #setTransform(double, double, double, double, double)
	 * @see #resetTransform()
	 */
	public void transform(double a, double b, double c, double d, double e, double f) {
	}

	/**
	 * Multiplies the current transformation with the transform described by the arguments of this method.
	 * 
	 * @param transform
	 */
	public void transform(Transform transform) {
	}

	/**
	 * Resets transform to identity call to this function brings origin at top left position and scales in both
	 * direction as unity (1 pixel per unit)
	 * 
	 * @see {@link #scale(double, double)}
	 * @see {@link #translate(double, double)}
	 */
	public void resetTransform() {
	}

	/**
	 * returns current transform of context
	 * 
	 * @return
	 */
	public Transform getTransform() {
		return null;
	}

	// /**************************************Path Methods ******************************************************

	/**
	 * Resets the path to empty. The append position is set back to the beginning of the path and all coordinates and
	 * point types are forgotten
	 */
	public void beginPath() {
	}

	/**
	 * Adds a point to the path by moving to the specified coordinates, without creating a line
	 * 
	 * @param x
	 *            {Number} x coordinate
	 * @param y
	 *            {Number} y coordinate
	 */
	public void moveTo(double x, double y) {
	}

	/**
	 * Adds a point to the path by drawing a straight line from the current coordinates to the new specified coordinates
	 * 
	 * @param x
	 *            {Number} x coordinate
	 * @param y
	 *            {Number} y coordinate
	 */
	public void lineTo(double x, double y) {
	}

	/**
	 * creates a rectangular path whose starting point is at (x, y) and whose size is specified by width and height
	 * 
	 * @param x
	 *            {Number} x coordinate of the rectangle's starting point.
	 * @param y
	 *            {Number} y coordinate of the rectangle's starting point.
	 * @param width
	 *            {Number} The rectangle's width. Positive values are to the right, and negative to the left.
	 * @param height
	 *            {Number} The rectangle's height. Positive values are down, and negative are up.
	 */
	public void rect(double x, double y, double width, double height) {
	}

	/**
	 * creates an arc (used to create circles, or parts of circles)
	 * 
	 * @param x
	 *            {Number} The x-coordinate of the center of the circle
	 * @param y
	 *            {Number} The y-coordinate of the center of the circle
	 * @param r
	 *            {Number} The radius of the circle
	 * @param sa
	 *            {Number} The starting angle, measured clockwise from the positive x-axis and expressed in radians.
	 * @param ea
	 *            {Number} The ending angle, measured clockwise from the positive x-axis and expressed in radians.
	 */
	public void arc(double x, double y, double r, double sa, double ea) {
	}

	/**
	 * creates an arc/curve (used to create circles, or parts of circles)
	 * 
	 * @param x
	 *            {Number} The x-coordinate of the center of the circle
	 * @param y
	 *            {Number} The y-coordinate of the center of the circle
	 * @param r
	 *            {Number} The radius of the circle
	 * @param sa
	 *            {Number} The starting angle, measured clockwise from the positive x-axis and expressed in radians.
	 * @param ea
	 *            {Number} The ending angle, measured clockwise from the positive x-axis and expressed in radians.
	 * @param ccw
	 *            {Boolean} if true drawing is done counterclockwise else clockwise
	 */
	public void arc(double x, double y, double r, double sa, double ea, boolean acw) {

	}

	/**
	 * creates a circular arc passing through currentPoint(current moveTo), (x1,y1) and (x2,y2)
	 * 
	 * @param x1
	 *            {Number} The x-coordinate of the first point
	 * @param y1
	 *            {Number} The y-coordinate of the first point
	 * @param x2
	 *            {Number} The x-coordinate of the second point
	 * @param y2
	 *            {Number} The x-coordinate of the second point
	 * @param r
	 *            {Number} The arc's radius. Must be non-negative.
	 */
	public void arcTo(double x1, double y1, double x2, double y2, double r) {
	}

	/**
	 * Adds a curved segment, defined by two new points, to the path by drawing a Quadratic curve that intersects both
	 * the current coordinates(moveTo) and the specified coordinates (x,y)
	 * 
	 * @param cpx
	 *            {Number} The x-coordinate of the quadratic control point
	 * @param cpy
	 *            {Number} The y-coordinate of the quadratic control point
	 * @param x
	 *            {Number} The x-coordinate of the ending point
	 * @param y
	 *            {Number} The y-coordinate of the ending point
	 */
	public void quadraticCurveTo(double cpx, double cpy, double x, double y) {
	}

	/**
	 * Adds a curved segment, defined by three new points, to the path by drawing a Bezier curve that intersects both
	 * the current coordinates and the specified coordinates (x,y), using the specified points (cpx1,cpy1) and
	 * (cpx2,cpy2) as Bezier control points.
	 * 
	 * @param cpx1
	 *            {Number} The x-coordinate of the first Bezier control point
	 * @param cpy1
	 *            {Number} The y-coordinate of the first Bezier control point
	 * @param cpx2
	 *            {Number} The x-coordinate of the second Bezier control point
	 * @param cpy2
	 *            {Number} The x-coordinate of the second Bezier control point
	 * @param x
	 *            {Number} The x-coordinate of the ending point
	 * @param y
	 *            {Number} The y-coordinate of the ending point
	 */
	public void bezierCurveTo(double cpx1, double cpy1, double cpx2, double cpy2, double x, double y) {
	}

	/**
	 * creates a path from the current point back to the starting point.
	 */
	public void closePath() {
	}

	/**
	 * returns true if a certain point is in the current path
	 * 
	 * @param x
	 *            x-coordinate in canvas space (top left as origin)
	 * @return y y-coordinate in canvas space (top left as origin)
	 */
	public boolean isPointInPath(double x, double y) {
		return false;
	}

	/**
	 * returns true if a certain point is in the specified path
	 * 
	 * @param x
	 *            x-coordinate in canvas space (top left as origin)
	 * @return y y-coordinate in canvas space (top left as origin)
	 */
	public boolean isPointInPath(Path2D path, double x, double y) {
		return false;
	}

	// ************************Pixel Manipulations***************************************
	/**
	 * Returns an ImageData object containing a copy of the pixel data for area of canvas context, whose corners are represented by the points (left,top), (left+width, top), (left, top+height), and (left+width, top+height).<br>
	 * <p>
	 * Note 1: The coordinates are specified in canvas coordinate space units.
	 * <p>
	 * Note 2: The Pixel data is not immediately available, actually The data is filled in next render call, so use {@link ImageData#isFilled()} to check if data is actually available
	 * @param left
	 * @param top
	 * @param width
	 * @param height
	 * @return {ImageData} pixel data can be retrieved using {@link ImageData#getPixel(int, int)} method of returned object
	 */
	public ImageData getImageData(int left, int top, int width, int height) {
		return null;
	}

	/**
	 * Paints {@link ImageData} in content, the The destX and destY parameters indicate the device coordinates within the
	 * context at which to paint the top left corner of the pixel data you wish to draw.
	 * @param data
	 * @param destX
	 * @param destY
	 */
	public void putImageData(ImageData data, int destX, int destY) {
	}

}