package simphy.script.canvas;

import java.util.function.Function;


public class Canvas   {
	/**width of canvas in pixel*/
	public double width;
	/**height of canvas in pixels*/
	public double height;
	
	/**
	 * Returns 2D Rendering context for the canvas
	 * @return {Context} the returned object can be used for 2D rendering on the canvas
	 */
	public Context getContext(){
		return null;
	}
	
	/**
	 * Returns 2D Rendering context for the canvas
	 * @return {Context} the returned object can be used for 2D rendering on the canvas
	 */
	public Context getContext(String mode){
		return null;
	}
	
	/**
	 * Returns current Scene associated with context if any
	 * @return
	 */
	public Scene getScene() {
		return null;
	}
	
	/**
	 * set current Scene associated with context
	 * @param Scene
	 */
	public void setScene(Scene scene) {
	}
	/**
	 * Sets background color of canvas 
	 * 
	 * @param {Number}r
	 *            red component between 0 and 1 inclusive
	 * @param {Number}g
	 *            green component between 0 and 1 inclusive
	 * @param {Number}b
	 *            blue component between 0 and 1 inclusive
	 * @param {Number}a
	 *            alpha component between 0 and 1 inclusive
	 */
	public void setBackGroundColor(double r, double g, double b, double a) {
	
	}
	
	/**
	 * Sets background color of canvas {pass null to use default gui Color}
	 * @param color {Color|String} Color Object or css color string  ex.<br>
	 * 	<ol> 
	 * 	<li> Common color name "red", "green" </li>
	 *	<li> Hexadecimal representation of color such as #FF0096 or 0xFF0096 </li>
	 * 	<li> Color functions "rgb(255,0,0)","hsl(180, 50%, 50%)","rgba(255,255,120,1)" </li>
	 */
	public void setBackGroundColor(Object color) {
		
	}
	
	/**
	 * Creates Offscreen Canvas associated with this canvas
	 * <p> An OffscreenCanvas is a canvas object that isn�t part of the screen display. 
	 * It is simply an area of memory that you can draw into using all of the familiar methods of canvas/context.
	 * <p>
	 * To render its content it can be used in place of Image object in context method, for example
	 * <pre>
	 * 	var ctx=world.getCanvas().getContext();
	 * 	var oCanvas=canvas.createOffscreenCanvas("id",120,120); //create offscreen canvas
	 * 	var octx=oCanvas.getContext();
	 * 	octx.fillRect(10,10,50,50); //draw some stuff on offscreen canvas
	 *	ctx.drawImage(oCanvas,0,0); //copy the content of offscreen canvas on actual context;
       </pre>                           
	 * which is exactly how you would do it with a standard canvas object.
	 * @param id
	 * @param width
	 * @param height
	 * @return {Canvas} canvas created
	 */
	public Canvas createOffscreenCanvas(String id, int width, int height) {
		return null;
	
	}
	
	/**
	 * Returns Offscreen Canvas created for this canvas with specified id else returns null
	 * @param id {String} Id of offscreen canvas used in its creation using {@link #createOffScreenCanvas(String, int, int)}
	 * @return {Canvas}
	 * @see #createOffscreenCanvas(String, int, int)
	 */
	public Canvas getOffscreenCanvas(String id) {
		return null;
	}

	/**
	 * Handles MouseEvent and notifies listeners
	 * returns true if handled (by default returns false)
	 */
	public boolean handleMouseEvent(int x, int y, int clickcount, int id,int button,boolean shiftdown, boolean controldown, boolean popuptrigger) {
		return false;
	}

	/**
	 * Handles MouseWheelEvent and notifies listeners
	 * returns true if handled (by default returns false)
	 */
	public boolean handleMouseWheel(int x, int y,int wheel) {
		return false;
	}

	/**
	 * Handles KeyEvent and notifies listeners
	 * returns true if handled (by default returns false)
	 */
	public boolean handleKey(int keychar, int keycode, int id, boolean shiftdown, boolean controldown, int modifiers) {
		return false;

	}

	/**
	 * Set size of canvas (Note that setting size may have different effect based on layout of its parent)
	 * @param width{Number} width in pixels
	 * @param height{Number} height in pixels
	 */
	public void setSize(int width,int height) throws Exception {
	}

	/**
	 * Returns callbackfunction for mousedown event if any else returns null
	 * @return  {Function} callbackFunction if any
	 */
	public Function<Object,Object> getOnmousedown() {
		return null;
	}

	/**
	 * Sets Callback function for mouse down event
	 * @param  callbackFunction {Function} function(must be defined in script) to be called
	 */
	public void setOnmousedown(Function<Object,Object> callbackFunction)  {
	}
		
	/**
	 * Returns callbackfunction for mouseup event if any else returns null
	 * @return  {Function} callbackFunction if any
	 */
	public Function<Object,Object> getOnmouseup() {
		return null;
	}

	/**
	 * Sets Callback function for mouse up event
	 * @param  callbackFunction {Function} function(must be defined in script) to be called
	 */
	public void setOnmouseup(Function<Object,Object> callbackFunction)  {
		
	}
		
	/**
	 * Returns callbackfunction for mousemove event if any else returns null
	 * @return  {Function} callbackFunction if any
	 */
	public Function<Object,Object> getOnmousemove() {
		return null;
	}

	/**
	 * Sets Callback function for mouse move event
	 * @param  callbackFunction {Function} function(must be defined in script) to be called
	 */
	public void setOnmousemove(Function<Object,Object> callbackFunction)  {
	
	}
		
	/**
	 * Returns callbackfunction for mouse click event if any else returns null
	 * @return  {Function} callbackFunction if any
	 */
	public Function<Object,Object> getOnclick() {
		return null;
	}

	/**
	 * Sets Callback function for mouse click event
	 * @param  callbackFunction {Function} function(must be defined in script) to be called
	 */
	public void setOnclick(Function<Object,Object> callbackFunction)  {
	}
	
	/**
	 * Returns callbackfunction for mouse double click event if any else returns null
	 * @return  {Function} callbackFunction if any
	 */
	public Function<Object,Object> getOndoubleclick() {
		return null;
	}

	/**
	 * Sets Callback function for mouse double click event
	 * @param  callbackFunction {Function} function(must be defined in script) to be called
	 */
	public void setOndoubleclick(Function<Object,Object> callbackFunction) {
	
	}
	
	/**
	 * /**
	 * Returns callbackfunction for mouse wheel event if any else returns null
	 * @return  {Function} callbackFunction if any
	 */
	public Function<Object,Object> getOnmousewheel() {
		return null;
	}

	/**
	 * Sets Callback function for mouse wheel or scroll event
	 * @param  callbackFunction {Function} function(must be defined in script) to be called
	 */
	public void setOnmousewheel(Function<Object,Object> callbackFunction) {
	}
	
	/**
	 * Returns callbackfunction for key press event if any else returns null
	 * @return  {Function} callbackFunction if any
	 */
	public Function<Object,Object> getOnkeypress() {
		return null;
	}

	/**
	 * Sets Callback function for key press event
	 * @param  callbackFunction {Function} function(must be defined in script) to be called
	 */
	public void setOnkeypress(Function<Object,Object> callbackFunction){
	}
	
	/**
	 * Returns callbackfunction for key down event if any else returns null
	 * @return  {Function} callbackFunction if any
	 */
	public Function<Object,Object> getOnkeydown() {
		return null;
	}

	/**
	 * Sets Callback function for key down event
	 * @param  callbackFunction {Function} function(must be defined in script) to be called
	 */
	public void setOnkeydown(Function<Object,Object> callbackFunction) {
	}
	
	/**
	 * Returns callbackfunction for key up event if any else returns null
	 * @return  {Function} callbackFunction if any
	 */
	public Function<Object,Object> getOnkeyup() {
		return null;
	}

	/**
	 * Sets Callback function for key up event
	 * @param  callbackFunction {Function} function(must be defined in script) to be called
	 */
	public void setOnkeyup(Function<Object,Object> callbackFunction)  {
	}
	
	/**
	 * Sets Mouse of keyboard eventListener for canvas
	 * @param event {String} mouseup|mousedown|mouseclick|mousemove|mousewheel|keydown|keyup|keypress
	 * @param callback {Function}
	 */
	public void addEventListener(String event, Function<Object,Object> callback){
		
	}

	/**
	 * Remove an event handler that has been attached with the {@link #addEventListener(String, Function)}method.
	 * @param event
	 */
	public void removeEventListener(String event){
	}
	
	/**
	 * Requests focus on this canvas, Having the focus means that key events are handed by it.
	 */
	public void requestFocus(){
	}
	
	/**
	 * The method allows to execute function on the next available repaint (called irrespective of simulation running or spot)
	 * <p>
	 * This is different from {@link simphy.script.App#setInterval(Function, double)} and {@link simphy.script.App#setTimeout(Function, double)} 
	 * which are executed only when simulation is running.
	 * @param callback {Function} The function to call when it's time to update your animation for the next repaint.
	 */
	public void requestAnimationFrame(Function<Object,Object> callback ) {
		
	}
	
}
