package simphy.script.canvas;

public class MouseEvent {
	public MouseEvent(int x, int y, int button,int clickCount, int id, boolean shiftdown, boolean controldown,int wheeldelta) {
		this.x=x;
		this.y=y;
		this.button=button;
		this.clickCount=clickCount;
		this.id=id;
		this.shiftKey=shiftdown;
		this.ctrlKey=controldown;
		this.wheelDelta=wheeldelta;
	}
	public int id;
	/**button pressed 1=left, 2=middle, 3=right	 */
	public int button = 0;
	
	public int clickCount;
	/**coordinates of the mouse pointer in canvas coordinates.*/
	public double x,y;
	/**coordinates of the mouse pointer in global (screen) coordinates.*/
	public double screenX ,screenY;
	
	public boolean altKey;
	public boolean ctrlKey;
	public boolean shiftKey;
	public int wheelDelta;

}
