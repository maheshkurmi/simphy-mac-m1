package simphy.script.canvas;

/**
 * A image object for canvas2d context
 * 
 * @author Mahesh kurmi
 */
public class Image {

	/**
	 * Create new Image from resource
	 * @param src Name of resource already loaded
	 */
	public Image(String src){
		
	}
	
	/**
	 * Changes the image content
	 * @param src {String} Name of resource already loaded
	 */
	public void setSource(String src){
		
	}
	
	/**
	 * Returns name of resource associated with image
	 * @return {String}
	 */
	public String getSource(){
		return null;
	}
	
    /**
     * Returns the width in pixels of the image
     * @return {Number} the width in pixels of the image
     */
    public int getWidth(){
    	return 0;
    }
    
    /**
     * Returns the height in pixels of the image
     * @return {Number} the height in pixels of the image
     */
    public int getHeight(){
    	return 0;
    }
    
	/**
	 * Sets Color used to tint the image
	 * @param color {Color|String} Color Object or css color string  ex.<br>
	 * 	<ol> 
	 * 	<li> Common color name "red", "green" </li>
	 *	<li> Hexadecimal representation of color such as #FF0096 or 0xFF0096 </li>
	 * 	<li> Color functions "rgb(255,0,0)","hsl(180, 50%, 50%)","rgba(255,255,120,1)" </li>
	 */
	public void setTintColor(Object color) {
	}
	
	/**
	 * Returns Color used to tint Color
	 * @param color
	 * @return {String} hexadecimal representation of color string
	 */
	public String getTintColor() {
		return null;
	}
 
	/**
	 * Creates and returns copy of this image, Note that only refernce of texturedata is
	 * copied not the textureData itself
	 * @return {Image} copy of image
	 */
	public Image createCopy() {
		return null;
	}
}
