package simphy.script.canvas;


public abstract class Scene {

}
