package simphy.script;


public class Preferences{
	/**
	 * Do not allow its instance creation
	 */
	private Preferences(){
		
	}
		
	/**
	 * @return the backColor
	 */
	public static  Color getBackGroundColor() {
		return null;
	}
	
	/**
	 * @param backColor the backColor to set
	 */
	public static  void setBackGroundColor(Color backColor) {
		
	}
	
	/**
	 * /**
	 * Sets BackGround Color of world
	 * @param color {Color|String} Color Object or css color string  ex.<br>
	 * 	<ol> 
	 * 	<li> Common color name "red", "green" </li>
	 *	<li> Hexadecimal representation of color such as #FF0096 or 0xFF0096 </li>
	 * 	<li> Color functions "rgb(255,0,0)","hsl(180, 50%, 50%)","rgba(255,255,120,1)" </li>
	 * </ol>
	 * @throws IllegalArgumentException if color is null or invalid
	 */
	public static  void setBackGroundColor(Object color) throws Exception {
		
	}
	
	/**
	 * @return the foreColor
	 */
	public static  Color getForeGroundColor() {
		return null;
	}
	
	/**
	 * Sets foreground Color of world
	 * @param color {Color|String} Color Object or css color string  ex.<br>
	 * 	<ol> 
	 * 	<li> Common color name "red", "green" </li>
	 *	<li> Hexadecimal representation of color such as #FF0096 or 0xFF0096 </li>
	 * 	<li> Color functions "rgb(255,0,0)","hsl(180, 50%, 50%)","rgba(255,255,120,1)" </li>
	 * </ol>
	 * @throws IllegalArgumentException if color is null or invalid
	 */
	public static  void setForeGroundColor(Color foreColor) {
		
	}

	/**
	 * @param foreColor the foreColor to set
	 * @throws Exception 
	 */
	public static  void setForeGroundColor(String cssColor) throws Exception {
		
	}
	

	/**Order "Mg","f","N","T","R","kx","E", "F","Fps","Fcf","Fcori"
	 * @return
	 * */
    public static  Boolean isForceEnabled(int index){
    	return false;
    }
    
    /**Order "Mg","f","N","T","R","kx","E", "F","Fps","Fcf","Fcori"
	 * */
    public static  void setForceEnabled(int index,boolean enabled){
    	
    }
    /**Order "Mg","f","N","T","R","kx","E", "F","Fps","Fcf","Fcori"
	 * @return
	 * */
    public static  Color getForceColor(int index){
    	return null;
    }
    
    /**Order "Mg","f","N","T","R","kx","E", "F","Fps","Fcf","Fcori"
	 * */
    public static  void setForceColor(int index,Color color){
    	
    }
    /**Order "Mg","f","N","T","R","kx","E", "F","Fps","Fcf","Fcori"
	 * @return
	 * */
    public static  String getForceName(int index){
    	return null;
    }
    
    /**Order "Mg","f","N","T","R","kx","E", "F","Fps","Fcf","Fcori"
	 * */
    public static  void setForceName(int index,String name){
    	
    }
	
	/**
	 * Sets number of significant figures used in calculations
	 * @param n
	 */
	public static  void setMaxSignificantFigures(int n) {
		
	}
	
	/**
	 * Returns number of significant figures used in calculations
	 */
	public static  int getMaxSignifucantFigures() {
		return 0;
	}
	
	/**
	 * Returns true if body labels should be shown.
	 * @return boolean
	 */
	public static  boolean isBodyLabeled() {
		return false;
	}
	
	/**
	 * Sets the body labels flag.
	 * @param flag true if body labels should be shown
	 */
	public static  void setBodyLabeled(boolean flag) {
		return ;
	}
	
	/**
	 * Returns true if the origin and origin label should be shown.
	 * @return boolean
	 */
	public static   boolean isOriginLabeled() {
		return false;
	}
	
	/**
	 * Sets the origin label flag.
	 * @param flag true if the origin and origin label should be shown
	 */
	public static   void setOriginLabeled(boolean flag) {
		
	}
	
	/**
	 * Sets the gravity rendered flag.
	 * @param flag true if the gravity should be shown
	 */
	public static   void setGravityRendered(boolean flag) {
		
	}
	
	/**
	 * Returns true if gravity should be rendered on screen
	 * @return boolean
	 */
	public static  boolean isGravityRendered() {
		return false;
	}
	
	/**
	 * Returns true if the center of mass should be rendered for bodies.
	 * @return boolean
	 */
	public static  boolean isBodyCenterEnabled() {
		return false;
	}
	
	/**
	 * Enables or disables the rendering of the center of mass for bodies.
	 * @param flag true if the center of mass should be rendered
	 */
	public static  void setBodyCenterEnabled(boolean flag) {
		
	}
	
	
	/**
	 * Returns true if the Grids should be rendered.
	 * @return boolean
	 */
	public static  boolean isGridEnabled() {
		return false;
	}
	
	/**
	 * Enables or disables the rendering of the grid.
	 * @param flag true if the scale should be rendered
	 */
	public static  void setGridEnabled(boolean flag) {
		
	}
	
	/**
	 * Returns true if the scale should be rendered.
	 * @return boolean
	 */
	public static  boolean isScaleEnabled() {
		return false;
	}
	
	/**
	 * Enables or disables the rendering of the scale.
	 * @param flag true if the scale should be rendered
	 */
	public static  void setScaleEnabled(boolean flag) {
		
	}
	
	
	/**
	 * Returns true if the body charge should be rendered.
	 * @return boolean
	 */
	public static  boolean isBodyChargeDisplayed() {
		return false;
	}
	
	/**
	 * Enables or disables the rendering of body charge
	 * @param flag true if body charge should be rendered
	 */
	public static  void setBodyChargeDisplayed(boolean flag) {
		
	}
	
	
	/**
	 * Returns true if body velocities should be rendered.
	 * @return boolean
	 */
	public static  boolean isBodyVelocityEnabled() {
		return false;
	}
	
	/**
	 * Enables or disables the rendering of body velocity vectors.
	 * @param flag true if velocities should be rendered
	 */
	public static  void setBodyVelocityEnabled(boolean flag) {
		
	}
	
	/**
	 * @return the forceScale in m/N
	 */
	public static  double getForceScale() {
		return 0;
	}

	/**
	 * @param forceScale the forceScale to set in m/N
	 */
	public static  void setForceScale(double forceScale) {
		
	}

	/**
	 * returns velocity scale m/(m/s)
	 * @return
	 */
	public static  double getVelocityScale() {
		return 0;
	}

	/**
	 * Sets force scale in m/(m/s)
	 * @param velocityScale
	 */
	public static  void setVelocityScale(double velocityScale) {
		
	}

	/**
	 * returns min force that can be shown in free body diagrams
	 * @return
	 */
	public static  double getMinForceDisplayed() {
		return 0;
	}

	/**
	 * Sets min force that can be shown in free body diagrams
	 * @param minForceDisplayed
	 */
	public static  void setMinForceDisplayed(double minForceDisplayed) {
		
	}

	/**
	 * returns min speed that can be shown in tracer
	 * @return
	 */
	public static  double getMinVelocityDisplayed() {
		return 0;
	}

	/**
	 * Sets min speed that can be shown in tracer
	 * @param minvelocity
	 */
	public static  void setMinVelocityDisplayed(double minvelocity) {
		
	}

	/**
	 * Returns true if position of body is displayed
	 * @return
	 */
	public static  boolean isPositionInfoEnabled() {
		return false;
	}

	/**
	 * if position of body is displayed
	 * @param posInfoEnabled
	 */
	public static  void setPositionInfoEnabled(boolean posInfoEnabled) {
		
	}

	/**
	 * Returns true if electric field lines are drawn else false
	 * @return {boolean}
	 */
	public static boolean isElectricFieldDrawn() {
		return false;
	}

	/**
	 * Enables rendering of electric field lines for existing electric fields
	 * @param magneticFieldDrawn {boolean}
	 */
	public static void setElectricFieldDrawn(boolean electricFieldDrawn) {
		
	}

	/**
	 * Returns true if electric field due to charges is rendered else false
	 * @param electricFieldForChargeDrawn {boolean}
	 */
	public static  void setElectricFieldForChargeDrawn(boolean electricFieldForChargeDrawn) {
		
	}
	
	/**
	 * Returns true if magnetic field lines are drawn 
	 * @return {boolean}
	 */
	public static  boolean isMagneticFieldDrawn() {
		return false;
	}

	/**
	 * Enables rendering of magnetic field lines for existing magnetic fields
	 * @param magneticFieldDrawn {boolean}
	 */
	public static  void setMagneticFieldDrawn(boolean magneticFieldDrawn) {
		
	}
	
	/**
	 * Returns if simulation can be edited by user
	 * @return
	 */
	public static boolean isSimulationLocked() {
		return false;
	}

	/**
	 * Sets if simulation can be edited by user
	 * @param simulationLocked
	 */
	public static  void setSimulationLocked(boolean simulationLocked) {
		
	}
	
	/**
	 * Returns Number of pixels represented by 1 unit on canvas
	 * @return {Number}
	 */
	public static double getPixelPerUnitFactor(){
		return 0;
	}

	/**
	 * Returns the simulation speed
	 * @return
	 */
	public double getSimulationSpeed() {
		return 1;
	}

	/**
	 * Sets the simulation speed 
	 * @param simulationspeed (between 0.01 to 10)
	 */
	public  void setSimulationSpeed(double simulationSpeed) {
	}

	/**
	 * Returns true if the simulation time should be shown.
	 * @return boolean
	 */
	public boolean isTimeShown() {
		return false;
	}
	
	/**
	 * Sets the time label flag.
	 * @param flag true if the simulation time should be shown
	 */
	public void setTimeShown(boolean flag) {
		
	}

}
