package simphy.script;


/**
 * Object to which action can be attached
 * 
 * @author maheshkurmi
 *
 */
public interface Actionable {
	/**
	 * sets current action on Actionable ignoring previous action if any
	 * 
	 * @param action
	 */
	public void setAction(Action action);

	/**
	 * Removes and terminates current action on body if any
	 */
	public void removeAction();

	/**
	 * Updates the actor based on time. Typically this is called each frame by {@link Simphy#update(float)}.
	 * <p>
	 * The default implementation calls {@link Action#act(float)} on action and removes action if complete.
	 * 
	 * @param delta
	 *            Time in seconds since the last frame.
	 */
	public void act(double delta);

	/**
	 * Returns current action on body
	 */
	public Action getAction();

	/** Removes this actor from its parent, if it has a parent. */
	public boolean remove();

	/**
	 * translates actor
	 * 
	 * @param x
	 * @param y
	 */
	public void translate(double x, double y);

	/**
	 * Sets position of actor relative to parent
	 * 
	 * @param x
	 * @param y
	 */
	public void setPosition(double x, double y);

	/**
	 * returns current position of center of actor
	 * @return
	 */
	public Vector2 getPosition();

	/**
	 * Scales actor to factors along both directions
	 * 
	 * @param xScale
	 *            must be >=0
	 * @param yScale
	 *            must be >=0
	 */
	public void scaleTo(double xScale, double yScale);

	/**
	 * Scales actor by factors along both directions
	 * 
	 * @param xScale
	 *            must be >=0
	 * @param yScale
	 *            must be >=0
	 */
	public void scaleBy(double xScale, double yScale);

	/**
	 * returns current scale factor for actor along X and Y direction
	 * @return
	 */
	public Vector2 getScale();
	
	
	/**
	 * Sets rotation about its center.
	 * 
	 * @param th
	 *            angle in radians with CCW as positive
	 */
	public void rotate(double th);

	/**
	 * Sets rotation about its own centre
	 * 
	 * @param th
	 *            angle in radians
	 */
	public void setRotation(double th);

	/**
	 * Returns rotation in radians
	 * 
	 * @return
	 */
	public double getRotation();

	/**
	 * Returns the fill color of actor.
	 * 
	 * @return fillColor
	 */
	public Color getFillColor();

	/**
	 * Sets Fill Color of the Actor (to disable filling shape pass null ar arguement)
	 * 
	 * @param color
	 *            {Color|String} Color Object or css color string ex.<br>
	 *            <ol>
	 *            <li>Common color name "red", "green"</li>
	 *            <li>Hexadecimal representation of color such as #FF0096 or 0xFF0096</li>
	 *            <li>Color functions "rgb(255,0,0)","hsl(180, 50%, 50%)","rgba(255,255,120,1)"</li>
	 * @throws IllegalArgumentException
	 *             if color is null or invalid
	 */
	public void setFillColor(Object color);

	/**
	 * Sets opacity of Actor
	 * 
	 * @param opacity
	 *            Opacity % , should be between 0 and 100
	 */
	public void setOpacity(int opacity);

	/**
	 * 
	 * @return returns opacity % of the Actor
	 */
	public int getOpacity();

	/**
	 * @param renderable
	 *            true if body is to be rendered on canvas
	 */
	public void setVisible(boolean visible);

	/**
	 * @param renderable
	 *            true if Actor is visible
	 */
	public boolean isVisible();

}
