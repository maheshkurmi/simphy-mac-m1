package simphy.script;

/**
 * App info Class
 * 
 * @author Mahesh kurmi
 * @version 1.0.0
 * @since 2.0.0
 */

public class App {
	/**
	 * Do not allow its instance creation
	 */
	private App(){
		
	}
	/**
	 * Emits an audio beep depending on native system settings and
	 * hardware capabilities.
	 */
	public static void beep() {
	}

	/**
	 * 
	 * @return true if simulation is not running
	 */
	public static boolean isPaused() {
		return false;
	}

	/**
	 * Sets the paused flag of the simulation.
	 * 
	 * @param paused {boolean} - true if the simulation should be paused
	 */
	public static void setPaused(boolean paused) {
	}

	/**
	 * Shows input box where user can input an integer
	 * 
	 * @param title   {String} Title shown on box
	 * @param message {String} Prompt message displayed in box
	 * @return {Number} Value entered by user or NaN if user cancelled the prompt
	 */
	public static double readInteger(String message) {
		return 0;
	}

	/**
	 * Shows input box where user can input a string
	 * 
	 * @param title{String}   Title shown on box
	 * @param message{String} Prompt message displayed in box
	 * @return {String} text entered by user or null if user cancelled the prompt
	 */
	public static String readString(String message) {
		return "";
	}

	/**
	 * Shows input box where user can input an expression
	 * 
	 * @param title{String}   Title shown on box
	 * @param message{String} Prompt message displayed in box
	 * @return {String} expression entered by user or null if user cancelled the
	 *         prompt
	 */
	public static String readExpression(String message) {
		return "";
	}

	/**
	 * Shows input box where user can input an integer
	 * 
	 * @param title{String}   Title shown on box
	 * @param message{String} Prompt message displayed in box
	 * @return {Number} Value entered by user or NaN if user cancelled the prompt
	 */
	public static double readDouble(String message) {
		return 0;
	}

	/**
	 * Shows a box containing choices (displayed as radiobutton) from which user can
	 * choose exactly ne choice
	 * 
	 * @param message{String} Prompt message displayed in box
	 * @param choices{Array}  Array of Choices to choose from
	 * @return {Number} index chosen by user or -1 if user cancelled the prompt
	 */
	public static int readChoice(String message, String[] choices) {
		return 0;
	}

	/**
	 * Shows a box containing choices (displayed as checkbox) from which user can
	 * choose none,one or more choice
	 * 
	 * @param message{String} Prompt message displayed in box
	 * @param choices{Array}  Array of Choices to choose from
	 * @return {Array} indices chosen by user or null if user cancelled the prompt
	 */
	public static int[] readChoices(String message, String[] choices) {
		return null;
	}

	/**
	 * Shows a box from which user can select an option from predefined
	 * options(shown as buttons)
	 * 
	 * @param message{String} Prompt message displayed in box
	 * @param choices{Array}  Array of Choices to choose from
	 * @return {String} Text on button chosen by user
	 */
	public static String readFromList(String message, String[] choices) {
		return "";
	}

	/**
	 * Shows message box with information icon/style to the user
	 * 
	 * @param title{String}   Title shown on box
	 * @param message{String} Message shown to the user
	 */
	public static void showMessageBox(String title, String message) {

	}

	/**
	 * Shows message box with error icon/style to the user
	 * 
	 * @param title{String}   Title shown on box
	 * @param message{String} Message shown to the user
	 */
	public static void showErrorMessageBox(String title, String message) {

	}

	/**
	 * Shows message box with warning icon/style to the user
	 * 
	 * @param title{String}   Title shown on box
	 * @param message{String} Message shown to the user
	 */
	public static void showWarningMessageBox(String title, String message) {

	}

	/**
	 * Shows modal dialog to the user to choose Ok or Cancel Option
	 * 
	 * @param title{String}   Title shown on box
	 * @param message{String} Message shown to the user
	 * @return {Number} 0=OK, 2=Cancel
	 */
	public static int showOkCancelBox(String title, String message) {
		return 0;
	}

	/**
	 * Shows modal dialog to the user to choose Yes or No action
	 * 
	 * @param title{String}   Title shown on box
	 * @param message{String} Message shown to the user
	 * @return {Number} 0=Yes, 1=No
	 */
	public static int showYesNoBox(String title, String message) {
		return 0;
	}

	/**
	 * Shows modal dialog to the user to choose Yes, No or cancel action
	 * 
	 * @param title{String}   Title shown on box
	 * @param message{String} Message shown to the user
	 * @return {Number} 0=Yes, 1=No, 2=Cancel
	 */
	public static int showYesNoCancelBox(String title, String message) {
		return 0;
	}

	/**
	 * round offs result to preferred significant figures as set in Preferences
	 * 
	 * @param val {number}
	 * @return {Number}
	 */
	public static double roundoff(double val) {
		return 0;
	}

	/**
	 * round offs result to preferred significant figures as set in Preferences
	 * 
	 * @param val        {number} value
	 * @param numFigures {number} number of significant figures
	 * @return {Number}
	 */
	public static double roundoff(double val, int numFigures) {
		return 0;
	}

	/**
	 * The java.text.DecimalFormat class is used to format numbers using a
	 * formatting pattern you specify yourself.
	 * 
	 * @param value   {number} value to be formatted
	 * @param pattern {String} number pattern that numbers should be formatted
	 *                according to. Examples: ###.### 123.456 123.456 ###.# 123.456
	 *                123.5 ###,###.## 123456.789 123,456.79 000.### 9.95 009.95
	 *                ##0.### 0.95 0.95
	 * @return {String} formatted number as string
	 */
	public static String format(double value, String pattern) {
		return "";
	}

	/**
	 * Clears all Timers created using {@link #setInterval(Function, double)} or
	 * {@link #setTimeout(Function, double)}
	 * 
	 * @see #clearInterval(Timer)
	 * @see #clearTimeout(Timer)
	 */
	public static void clearAllTimers() {

	}

	/**
	 * Calls a function or evaluates an expression at specified intervals (in
	 * milliSeconds). The setInterval() method will continue calling the function
	 * until clearInterval() is called, or the window is closed
	 * 
	 * @param callbackFunction {Function|String} function(must be defined in script)
	 *                         to be called
	 * @param interval         {Number} time interval in milliSeconds
	 * @return Timer Object created which can be used as an argument in
	 *         {@link #clearInterval(Timer)} to prevent/interrupt function
	 */
	public static Object setInterval(Object callbackFunction, double interval) throws Exception {
		return null;
	}

	/**
	 * Calls a function or evaluates an expression at specified intervals (in
	 * milliSeconds). The setInterval() method will continue calling the function
	 * until clearInterval() is called, or the window is closed
	 * 
	 * @param callbackFunction {Function|String} function(must be defined in script)
	 *                         to be called
	 * @param interval         {Number} time interval in milliSeconds
	 * @param counter          {Number} Number of times function should run
	 * @return Timer Object created which can be used as an argument in
	 *         {@link #clearInterval(Timer)} to prevent/interrupt function
	 */
	public static Object setInterval(Object callbackFunction, double interval, int counter) throws Exception {
		return null;
	}

	/**
	 * Calls a function or evaluates an expression exactly once after a specified
	 * time in milliSeconds.
	 * 
	 * @param callbackFunction {Function|String} function(must be defined in script)
	 *                         to be called
	 * @param delay            {Number} time delay in milliSeconds
	 * @return Timer Object created which can be used as an argument in
	 *         {@link #clearTimeout(Timer)} to prevent/interrupt function
	 */
	public static Object setTimeout(Object callbackFunction, double delay) throws Exception {
		return null;
	}

	/**
	 * Prevent the function set with the {@link #setTimeout(Function, double)} to
	 * execute: Note: Once timer is cleared it no longer can be activated
	 * 
	 * @param timer{Timer} value returned by setTimeout() function
	 */
	public static void clearTimeout(Object timer) {
	}

	/**
	 * Prevent the function set with the {@link #setInterval(Function, double)} to
	 * execute: Note: Once timer is cleared it no longer can be activated
	 * 
	 * @param timer{Timer} value returned by setInterval() function
	 */
	public static void clearInterval(Object timer) {

	}

}
