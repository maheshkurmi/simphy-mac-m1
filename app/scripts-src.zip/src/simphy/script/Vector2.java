package simphy.script;
/**
 * This class represents a vector or point in 2D space.
 * <p>
 * The operations {@link Vector2#setMagnitude(double)}, {@link Vector2#getNormalized()},
 * {@link Vector2#project(Vector2)}, and {@link Vector2#normalize()} require the {@link Vector2}
 * to be non-zero in length.
 * <p>
 * Some methods also return the vector to facilitate chaining.  For example:
 * <pre>
 * Vector a = new Vector();
 * a.zero().add(1, 2).multiply(2);
 * </pre>
 */
public class Vector2 {
	/** A vector representing the x-axis; this vector should not be changed at runtime; used internally */
	static final Vector2 X_AXIS = new Vector2(1.0, 0.0);
	
	/** A vector representing the y-axis; this vector should not be changed at runtime; used internally */
	static final Vector2 Y_AXIS = new Vector2(0.0, 1.0);
	
	/** The x component of this {@link Vector2} */
	public double x;
	
	/** The y component of this {@link Vector2} */
	public double y;
	
	/** Default constructor. */
	public Vector2() {}

	/**
	 * Copy constructor.
	 * @param vector the {@link Vector2} to copy from
	 */
	public Vector2(Vector2 vector) {}
	
	/**
	 * Optional constructor.
	 * @param x the x component
	 * @param y the y component
	 */
	public Vector2(double x, double y) {}

	/**
	 * Creates a {@link Vector2} from the first point to the second point.
	 * @param x1 the x coordinate of the first point
	 * @param y1 the y coordinate of the first point
	 * @param x2 the x coordinate of the second point
	 * @param y2 the y coordinate of the second point
	 */
	public Vector2(double x1, double y1, double x2, double y2) {}
	
	/**
	 * Creates a {@link Vector2} from the first point to the second point.
	 * @param p1 the first point
	 * @param p2 the second point
	 */
	public Vector2(Vector2 p1, Vector2 p2) {}

	/**
	 * Creates a unit length vector in the given direction.
	 * @param direction the direction in radians
	 * @since 3.0.1
	 */
	public Vector2(double direction) {}
	
	/**
	 * Returns a new {@link Vector2} given the magnitude and direction.
	 * @param magnitude the magnitude of the {@link Vector2}
	 * @param direction the direction of the {@link Vector2} in radians
	 * @return {@link Vector2}
	 */
	public static Vector2 create(double magnitude, double direction) {	return null;}
	
	/**
	 * Returns a copy of this {@link Vector2}.
	 * @return {@link Vector2}
	 */
	public Vector2 copy() {return null;	}
	
	/**
	 * Returns the distance from this point to the given point.
	 * @param x the x coordinate of the point
	 * @param y the y coordinate of the point
	 * @return double
	 */
	public double distance(double x, double y) {return 0;}
	
	/**
	 * Returns the distance from this point to the given point.
	 * @param point the point
	 * @return double
	 */
	public double distance(Vector2 point) {return 0;}
	
	/**
	 * Returns the distance from this point to the given point squared.
	 * @param x the x coordinate of the point
	 * @param y the y coordinate of the point
	 * @return double
	 */
	public double distanceSquared(double x, double y) {return 0;}
	
	/**
	 * Returns the distance from this point to the given point squared.
	 * @param point the point
	 * @return double
	 */
	public double distanceSquared(Vector2 point) {return 0;}
	
	/**
	 * The triple product of {@link Vector2}s is defined as:
	 * <pre>
	 * a x (b x c)
	 * </pre>
	 * However, this method performs the following triple product:
	 * <pre>
	 * (a x b) x c
	 * </pre>
	 * this can be simplified to:
	 * <pre>
	 * -a * (b &middot; c) + b * (a &middot; c)
	 * </pre>
	 * or:
	 * <pre>
	 * b * (a &middot; c) - a * (b &middot; c)
	 * </pre>
	 * @param a the a {@link Vector2} in the above equation
	 * @param b the b {@link Vector2} in the above equation
	 * @param c the c {@link Vector2} in the above equation
	 * @return {@link Vector2}
	 */
	public static Vector2 tripleProduct(Vector2 a, Vector2 b, Vector2 c) {return null;}
	
		/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {return false;}
	
	/**
	 * Returns true if Vectors are very Close to each other
	 * @param Vetor2 v
	 * @return
	 */
	public boolean approxEqual(Vector2 v) {	return false;}
	

	/**
	 * Returns true if the x and y components of this {@link Vector2}
	 * are the same as the given {@link Vector2}.
	 * @param vector the {@link Vector2} to compare to
	 * @return boolean
	 */
	public boolean equals(Vector2 vector) {return false;}
	
	/**
	 * Returns true if the x and y components of this {@link Vector2}
	 * are the same as the given x and y components.
	 * @param x the x coordinate of the {@link Vector2} to compare to
	 * @param y the y coordinate of the {@link Vector2} to compare to
	 * @return boolean
	 */
	public boolean equals(double x, double y) {return false;	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {return null;}
	
	
	
	/**
	 * Sets this {@link Vector2} to the given {@link Vector2}.
	 * @param vector the {@link Vector2} to set this {@link Vector2} to
	 * @return {@link Vector2} this vector
	 */
	public Vector2 set(Vector2 vector) {return null;}
	
	/**
	 * Sets this {@link Vector2} to the given {@link Vector2}.
	 * @param x the x component of the {@link Vector2} to set this {@link Vector2} to
	 * @param y the y component of the {@link Vector2} to set this {@link Vector2} to
	 * @return {@link Vector2} this vector
	 */
	public Vector2 set(double x, double y) {return null;}
	
	/**
	 * Returns the x component of this {@link Vector2}.
	 * @return {@link Vector2}
	 */
	public Vector2 getXComponent() {return null;}
	
	/**
	 * Returns the y component of this {@link Vector2}.
	 * @return {@link Vector2}
	 */
	public Vector2 getYComponent() {return null;}
	
	/**
	 * Returns the magnitude of this {@link Vector2}.
	 * @return double
	 */
	public double getMagnitude() {return 0;	}
	
	/**
	 * Returns the magnitude of this {@link Vector2} squared.
	 * @return double
	 */
	public double getMagnitudeSquared() {return 0;	}
	
	/**
	 * Sets the magnitude of the {@link Vector2}.
	 * @param magnitude the magnitude
	 * @return {@link Vector2} this vector
	 */
	public Vector2 setMagnitude(double magnitude) {return null;	}
	
	/**
	 * Returns the direction of this {@link Vector2}
	 * as an angle in radians.
	 * @return double angle in radians [-&pi;, &pi;]
	 */
	public double getDirection() {return 0;	}
	

	/**
	 * Returns the angle of this {@link Vector2} with +ve x axis
	 * as an angle in radians.
	 * @return double angle in radians [0, 2*&pi;]
	 */
	public double getAngleWithPositiveXAxis() {return 0;	}
	
	/**
	 * Sets the direction of this {@link Vector2}.
	 * @param angle angle in radians
	 * @return {@link Vector2} this vector
	 */
	public Vector2 setDirection(double angle) {return null;}
	
	/**
	 * Adds the given {@link Vector2} to this {@link Vector2}.
	 * @param vector the {@link Vector2}
	 * @return {@link Vector2} this vector
	 */
	public Vector2 add(Vector2 vector) {return null;	}
	
	/**
	 * Adds the given {@link Vector2} to this {@link Vector2}.
	 * @param x the x component of the {@link Vector2}
	 * @param y the y component of the {@link Vector2}
	 * @return {@link Vector2} this vector
	 */
	public Vector2 add(double x, double y) {return null;	}
	
	/**
	 * Adds this {@link Vector2} and the given {@link Vector2} returning
	 * a new {@link Vector2} containing the result.
	 * @param vector the {@link Vector2}
	 * @return {@link Vector2}
	 */
	public Vector2 sum(Vector2 vector) {return null;	}
	
	/**
	 * Adds this {@link Vector2} and the given {@link Vector2} returning
	 * a new {@link Vector2} containing the result.
	 * @param x the x component of the {@link Vector2}
	 * @param y the y component of the {@link Vector2}
	 * @return {@link Vector2}
	 */
	public Vector2 sum(double x, double y) {return null;}
	
	/**
	 * Subtracts the given {@link Vector2} from this {@link Vector2}.
	 * @param vector the {@link Vector2}
	 * @return {@link Vector2} this vector
	 */
	public Vector2 subtract(Vector2 vector) {return null;	}
	
	/**
	 * Subtracts the given {@link Vector2} from this {@link Vector2}.
	 * @param x the x component of the {@link Vector2}
	 * @param y the y component of the {@link Vector2}
	 * @return {@link Vector2} this vector
	 */
	public Vector2 subtract(double x, double y) {return null;	}
	
	/**
	 * Subtracts the given {@link Vector2} from this {@link Vector2} returning
	 * a new {@link Vector2} containing the result.
	 * @param vector the {@link Vector2}
	 * @return {@link Vector2}
	 */
	public Vector2 difference(Vector2 vector) {return null;}
	
	/**
	 * Subtracts the given {@link Vector2} from this {@link Vector2} returning
	 * a new {@link Vector2} containing the result.
	 * @param x the x component of the {@link Vector2}
	 * @param y the y component of the {@link Vector2}
	 * @return {@link Vector2}
	 */
	public Vector2 difference(double x, double y) {return null;	}
	
	/**
	 * Creates a {@link Vector2} from this {@link Vector2} to the given {@link Vector2}.
	 * @param vector the {@link Vector2}
	 * @return {@link Vector2}
	 */
	public Vector2 to(Vector2 vector) {return null;	}
	
	/**
	 * Creates a {@link Vector2} from this {@link Vector2} to the given {@link Vector2}.
	 * @param x the x component of the {@link Vector2}
	 * @param y the y component of the {@link Vector2}
	 * @return {@link Vector2}
	 */
	public Vector2 to(double x, double y) {return null;	}
		
	/**
	 * Multiplies this {@link Vector2} by the given scalar.
	 * @param scalar the scalar
	 * @return {@link Vector2} this vector
	 */
	public Vector2 multiply(double scalar) {return null;	}
	
	/**
	 * Multiplies this {@link Vector2} by the given scalar returning
	 * a new {@link Vector2} containing the result.
	 * @param scalar the scalar
	 * @return {@link Vector2}
	 */
	public Vector2 product(double scalar) {return null;	}
	
	/**
	 * Returns the dot product of the given {@link Vector2}
	 * and this {@link Vector2}.
	 * @param vector the {@link Vector2}
	 * @return double
	 */
	public double dot(Vector2 vector) {return 0;	}
	
	/**
	 * Returns the dot product of the given {@link Vector2}
	 * and this {@link Vector2}.
	 * @param x the x component of the {@link Vector2}
	 * @param y the y component of the {@link Vector2}
	 * @return double
	 */
	public double dot(double x, double y) {return 0;	}
	
	/**
	 * Returns the cross product of the this {@link Vector2} and the given {@link Vector2}.
	 * @param vector the {@link Vector2}
	 * @return double
	 */
	public double cross(Vector2 vector) {return 0;}
	
	/**
	 * Returns the cross product of the this {@link Vector2} and the given {@link Vector2}.
	 * @param x the x component of the {@link Vector2}
	 * @param y the y component of the {@link Vector2}
	 * @return double
	 */
	public double cross(double x, double y) {return 0;}
	
	/**
	 * Returns the cross product of this {@link Vector2} and the z value of the right {@link Vector2}.
	 * @param z the z component of the {@link Vector2}
	 * @return {@link Vector2}
	 */
	public Vector2 cross(double z) {return null;}
	
	/**
	 * Returns true if the given {@link Vector2} is orthogonal (perpendicular)
	 * to this {@link Vector2}.
	 * <p>
	 * If the dot product of this vector and the given vector is
	 * zero then we know that they are perpendicular
	 * @param vector the {@link Vector2}
	 * @return boolean
	 */
	public boolean isOrthogonal(Vector2 vector) {return false;}
	
	/**
	 * Returns true if the given {@link Vector2} is orthogonal (perpendicular)
	 * to this {@link Vector2}.
	 * <p>
	 * If the dot product of this vector and the given vector is
	 * zero then we know that they are perpendicular
	 * @param x the x component of the {@link Vector2}
	 * @param y the y component of the {@link Vector2}
	 * @return boolean
	 */
	public boolean isOrthogonal(double x, double y) {return false;}
	
	/**
	 * Returns true if this {@link Vector2} is the zero {@link Vector2}.
	 * @return boolean
	 */
	public boolean isZero() {return false;}
	
	/** 
	 * Negates this {@link Vector2}.
	 * @return {@link Vector2} this vector
	 */
	public Vector2 negate() {return null;}
	
	/**
	 * Returns a {@link Vector2} which is the negative of this {@link Vector2}.
	 * @return {@link Vector2}
	 */
	public Vector2 getNegative() {return null;}
	
	/** 
	 * Sets the {@link Vector2} to the zero {@link Vector2}
	 * @return {@link Vector2} this vector
	 */
	public Vector2 zero() {return null;	}
	
	/**
	 * Rotates about the origin.
	 * @param theta the rotation angle in radians
	 * @return {@link Vector2} this vector
	 */
	public Vector2 rotate(double theta) {return null;}
	
	/**
	 * returns new vector by Rotating this veector about the origin
	 * @param theta the rotation angle in radians
	 * @return {@link Vector2} new vector
	 */
	public Vector2 getRotated(double theta) {return null;}
	
	/**
	 * Rotates the {@link Vector2} about the given coordinates.
	 * @param theta the rotation angle in radians
	 * @param x the x coordinate to rotate about
	 * @param y the y coordinate to rotate about
	 * @return {@link Vector2} this vector
	 */
	public Vector2 rotate(double theta, double x, double y) {return null;}
	
	/**
	 * Rotates the {@link Vector2} about the given point.
	 * @param theta the rotation angle in radians
	 * @param point the point to rotate about
	 * @return {@link Vector2} this vector
	 */
	public Vector2 rotate(double theta, Vector2 point) {return null;}
	
	/**
	 * returns new vector by Rotating this vector about the origin about the given point
	 * @param theta the rotation angle in radians
	 * @return {@link Vector2} new vector
	 */
	public Vector2 getRotated(double theta, Vector2 point) {return null;}
	
	/**
	 * Projects this {@link Vector2} onto the given {@link Vector2}.
	 * @param vector the {@link Vector2}
	 * @return {@link Vector2} the projected {@link Vector2}
	 */
	public Vector2 project(Vector2 vector) {return null;}

	/**
	 * Returns the right-handed normal of this vector.
	 * @return {@link Vector2} the right hand orthogonal {@link Vector2}
	 */
	public Vector2 getRightHandOrthogonalVector() {return null;}
	
	/**
	 * Sets this vector to the right-handed normal of this vector.
	 * @return {@link Vector2} this vector
	 * @see #getRightHandOrthogonalVector()
	 */
	public Vector2 right() {return null;}
	
	/**
	 * Returns the left-handed normal of this vector.
	 * @return {@link Vector2} the left hand orthogonal {@link Vector2}
	 */
	public Vector2 getLeftHandOrthogonalVector() {return null;}
	
	/**
	 * Sets this vector to the left-handed normal of this vector.
	 * @return {@link Vector2} this vector
	 * @see #getLeftHandOrthogonalVector()
	 */
	public Vector2 left() {return null;}

	/**
	 * Returns a unit {@link Vector2} of this {@link Vector2}.
	 * <p>
	 * This method requires the length of this {@link Vector2} is not zero.
	 * @return {@link Vector2}
	 */
	public Vector2 getNormalized() {return null;}
	
	/**
	 * Converts this {@link Vector2} into a unit {@link Vector2} and returns
	 * the magnitude before normalization.
	 * <p>
	 * This method requires the length of this {@link Vector2} is not zero.
	 * @return double
	 */
	public double normalize() {		return 0;}
	
	/**
	 * Returns the smallest angle between the given {@link Vector2}s.
	 * <p>
	 * Returns the angle in radians in the range -&pi; to &pi;.
	 * @param vector the {@link Vector2}
	 * @return angle in radians [-&pi;, &pi;]
	 */
	public double getAngleBetween(Vector2 vector) {	return 0;}
}
