package simphy.script;

/**
 * Class used to encapsulate camera properties in simulation
 */
public class WorldCamera {
	
	/**
	 * Zooms camera to specified percentage zoom.
	 * @param zoomPercentage Desired Percentage ZOOM
	 */
	public void zoomTo(double zoomPercentage) {
		
	}
	
	/**
	 * Zooms camera to specified percentage zoom about specified point as origin.
	 * @param zoomPercentage Desired Percentage ZOOM
	 * @param pt  Zoom about pt as centre
	 */
	public void zoomToAboutPoint(double zoomPercentage,Vector2 pt) {
		
	}
	
	
	/**
	 * Zooms out the camera.
	 */
	public void zoomOut() {
		
	}
	
	/**
	 * Zooms in the camera.
	 */
	public void zoomIn() {
		
	}
	
	/**
	 * Zooms out the camera about point (in world coordinates).
	 * @param pt Zoom about pt as centre
	 */
	public void zoomOutAboutPoint(Vector2 pt) {
		
	}
	
	/**
	 * Zooms in the camera about point (in world coordinates).
	 * @param pt  Zoom about pt as centre
	 */
	public void zoomInAboutPoint(Vector2 pt) {
		
	}
	
	/**
	 * Moves the camera back to the origin (Now World origin will be rendered at screen center).
	 */
	public void toOrigin() {
		
	}
	
	/**
	 * Translates the camera the given amount along the x and y axes.
	 * @param tx the translation
	 */
	public void translate(Vector2 tx) {
		
	}
	
	/**
	 * Translates the camera the given amount along the x and y axes.
	 * @param x the x translation
	 * @param y the y translation
	 */
	public void translate(double x, double y) {
		
	}
	
	
	/**
	 * Returns the scale factor in pixel per meter.
	 * @return double
	 */
	public double getScale() {
		return 0;
	}
	
	/**
	 * Sets the scale factor in pixels per meter.
	 * @param scale the desired scale factor
	 */
	public void setScale(double scale) {
	}
	
	/**
	 * Returns the offset of camera (displacement of screen center from 'world center rendered on screen').
	 * @return Vector2
	 */
	public Vector2 getOffset() {
		return null;
	}
	
	/**
	 * Sets the offset/translation from the origin in world coordinates.
	 * @param translation the translation
	 */
	public void setOffset(Vector2 translation) {
	}


	/**
	 * returns body set as target of camera (returns null if there is no body attached to camera)
	 * @return
	 */
	public Body getCameraBody() {
		return null;
	}

	/**
	 * Sets target body for Camera, follows the body (renders with origin as body's center and rotation as bodies own rotation) 
	 * @param cameraBody body to be followed (set null to unfollow any body)
	 */
	public void setCameraBody(Body cameraBody) {
	}


}
