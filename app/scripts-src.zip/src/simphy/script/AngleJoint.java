
package simphy.script;

/**
 * Implementation of an angle joint.
 * <p>
 * A angle joint constrains the relative rotation of two bodies.  The bodies 
 * will continue to translate freely.
 * <p>
 * By default the lower and upper limit angles are set to the current angle 
 * between the bodies.  When the lower and upper limits are equal, the bodies 
 * rotate together and are not allowed rotate relative to one another.  By
 * default the limits are disabled.
 * <p>
 * If the lower and upper limits are set explicitly, the values must follow 
 * these restrictions:
 * <ul>
 * <li>lower limit &le; upper limit</li>
 * <li>lower limit &gt; -180</li>
 * <li>upper limit &lt; 180</li>
 * </ul> 
 * To create a joint with limits outside of this range use the 
 * {@link #setReferenceAngle(double)} method.  This method sets the baseline 
 * angle for the joint, which represents 0 radians in the context of the 
 * limits.  For example:
 * <pre>
 * // we would like the joint limits to be [30, 260]
 * // this is the same as the limits [-60, 170] if the reference angle is 90
 * joint.setLimits(Math.toRadians(-60), Math.toRadians(170));
 * joint.setReferenceAngle(Math.toRadians(90));
 * </pre>
 * The angle joint also allows a ratio value that allow the bodies to rotate at
 * a specified value relative to the other.  This can be used to simulate gears.
 * <p>
 * Since the AngleJoint class defaults the upper and lower limits to the same 
 * value and by default the limits are enabled, you will need to modify the 
 * limits, or disable the limit to see the effect of the ratio.
 * <p>
 * When the angle between the bodies reaches a limit, and limits are enabled, 
 * the ratio will be turned off.
 * <p>
 * NOTE: The {@link #getAnchor1()} and {@link #getAnchor2()} methods return
 * the world space center points for the joined bodies.  This constraint 
 * doesn't need anchor points.
 */
public class AngleJoint extends Joint  {
	
	
	/**
	 * Returns the relative angle between the two {@link Body}s in radians in the range [-&pi;, &pi;].
	 * @return double
	 */
	public double getJointAngle() {
		return 0;
	}
	
	/**
	 * Returns the angular velocity ratio between the two bodies.
	 * @return double
	 */
	public double getRatio() {
		return 0;
	}
	
	/**
	 * Sets the angular velocity ratio between the two bodies.
	 * <p>
	 * To disable the ratio and fix their velocities set the ratio to 1.0.
	 * <p>
	 * The ratio can be negative to reverse the direction of the velocity
	 * of the other body.
	 * @param ratio the ratio
	 */
	public void setRatio(double ratio) {
		
	}
	
	/**
	 * Sets whether the angle limits are enabled.
	 * @param flag true if the angle limits should be enforced
	 */
	public void setLimitEnabled(boolean flag) {
	
	}
	
	/**
	 * Returns true if the limit is enabled.
	 * @return boolean true if the limit is enabled
	 */
	public boolean isLimitEnabled() {
		return false;
	}
	
	/**
	 * Returns the upper limit in radians.
	 * @return double
	 */
	public double getUpperLimit() {
		return 0;
	}
	
	/**
	 * Sets the upper limit in radians.
	 * <p>
	 * See the class documentation for more details on the limit ranges.
	 * @param upperLimit the upper limit in radians
	 * @throws IllegalArgumentException if upperLimit is less than the current lower limit
	 */
	public void setUpperLimit(double upperLimit) {
		
	}
	
	/**
	 * Returns the lower limit in radians.
	 * @return double
	 */
	public double getLowerLimit() {
		return 0;
	}
	
	/**
	 * Sets the lower limit in radians.
	 * <p>
	 * See the class documentation for more details on the limit ranges.
	 * @param lowerLimit the lower limit in radians
	 * @throws IllegalArgumentException if lowerLimit is greater than the current upper limit
	 */
	public void setLowerLimit(double lowerLimit) {
		
	}
	
	/**
	 * Sets both the lower and upper limits.
	 * <p>
	 * See the class documentation for more details on the limit ranges.
	 * @param lowerLimit the lower limit in radians
	 * @param upperLimit the upper limit in radians
	 * @throws IllegalArgumentException if lowerLimit is greater than upperLimit
	 */
	public void setLimits(double lowerLimit, double upperLimit) {
		
	}

	/**
	 * Sets both the lower and upper limits and enables them.
	 * <p>
	 * See the class documentation for more details on the limit ranges.
	 * @param lowerLimit the lower limit in radians
	 * @param upperLimit the upper limit in radians
	 * @throws IllegalArgumentException if lowerLimit is greater than upperLimit
	 */
	public void setLimitsEnabled(double lowerLimit, double upperLimit) {
		
	}
	
	/**
	 * Sets both the lower and upper limits to the given limit.
	 * <p>
	 * See the class documentation for more details on the limit ranges.
	 * @param limit the desired limit
	 */
	public void setLimits(double limit) {
		
	}
	
	/**
	 * Sets both the lower and upper limits to the given limit and enables them.
	 * <p>
	 * See the class documentation for more details on the limit ranges.
	 * @param limit the desired limit
	 */
	public void setLimitsEnabled(double limit) {
		
	}
	
	/**
	 * Returns the reference angle.
	 * <p>
	 * The reference angle is the angle calculated when the joint was created from the
	 * two joined bodies.  The reference angle is the angular difference between the
	 * bodies.
	 * @return double
	 */
	public double getReferenceAngle() {
		return 0;
	}
	
	/**
	 * Sets the reference angle.
	 * <p>
	 * This method can be used to set the reference angle to override the computed
	 * reference angle from the constructor.  This is useful in recreating the joint
	 * from a current state.
	 * <p>
	 * See the class documentation for more details.
	 * @param angle the reference angle in radians
	 * @see #getReferenceAngle()
	 */
	public void setReferenceAngle(double angle) {
		
	}

	/**
	 * Returns the current state of the limit.
	 * @return {@link LimitState}
	 */
	public LimitState getLimitState() {
		return null;
	}
}
