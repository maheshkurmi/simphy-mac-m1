package simphy.script;



public class MultiAction extends Action{
	/**
	 * Adds action to this action
	 * @param action
	 */
	public void addAction (Action action) {

	}

	/**
	 * removes action from this action
	 * @param action
	 */
	public void removeAction (Action action) {
		
	}
}
