package simphy.script;

import simphy.script.canvas.Image;

/**
 * Represents a physical {@link Body}.
 * <p>
 * The coefficient of friction and restitution and the linear and angular damping
 * are all defaulted but can be changed via the accessor and mutator methods.
 * <p>
 * A {@link Body} becomes inactive when the {@link Body} has left the boundary of
 * the world.
 * <p>
 * A {@link Body} is dynamic if either its inertia or mass is greater than zero.
 * A {@link Body} is static if both its inertia and mass are zero.
 * <p>
 */
public class Body implements Actionable{
	/**
	 * Returns the outline color.
	 * @return {Color}
	 */
	public Color getOutlineColor() {
		return null;
	}
	

	/**
	 * Sets Outline Color of the body (to disable rendering outline pass null ar arguement)
	 * @param color {Color|String} Color Object or css color string  ex.<br>
	 * 	<ol> 
	 * 	<li> Common color name "red", "green" </li>
	 *	<li> Hexadecimal representation of color such as #FF0096 or 0xFF0096 </li>
	 * 	<li> Color functions "rgb(255,0,0)","hsl(180, 50%, 50%)","rgba(255,255,120,1)" </li>
	 * </ol>
	 */
	public void setOutlineColor(Color color) {
		
	}
	
	/**
	 * Sets outline color of body
     * @param r the red component  in the range (0.0 - 1.0).  
	 * @param g the green component  in the range (0.0 - 1.0).  
	 * @param b the blue component  in the range (0.0 - 1.0).  
	 * @param a the alpha component  in the range (0.0 - 1.0).  
	 */
	public void setOutlineColor(float r, float g,float b,float a){
		
	}
	

	/**
	 * Returns the fill color.
	 * @return {Color} fillColor
	 */
	public Color getFillColor() {
		return null;
	}
	

	/**
	 * Sets Fill Color of the body (to disable filling shape pass null ar arguement)
	 * @param color {Color|String} Color Object or css color string  ex.<br>
	 * 	<ol> 
	 * 	<li> Common color name "red", "green" </li>
	 *	<li> Hexadecimal representation of color such as #FF0096 or 0xFF0096 </li>
	 * 	<li> Color functions "rgb(255,0,0)","hsl(180, 50%, 50%)","rgba(255,255,120,1)" </li>
	 * </ol>
	 * @throws IllegalArgumentException if color is null or invalid
	 */
	public void setFillColor(Color color) {
		
	}

	
	/**
	 * Sets outline color of body
     * @param r the red component  in the range (0.0 - 1.0).  
	 * @param g the green component  in the range (0.0 - 1.0).  
	 * @param b the blue component  in the range (0.0 - 1.0).  
	 * @param a the alpha component  in the range (0.0 - 1.0).  
	 */
	public void setFillColor(float r, float g,float b,float a){
	}
	


	/**
	 * Sets opacity of body	
	 * @param opacity Opacity % an integer  between 10 and 100
	 */
	public void setOpacity(int opacity) {}

	/**
	 * 
	 * @return returns opacity % of the SandBoxbody
	 */
	public int getOpacity() {return 0;}
	
	/**
	 * Returns Sets visibility of body 
	 * @return true if body can be rendered on canvas
	 */
	public boolean isRenderable() {return false;}

	/**
	 * Sets visibility of body
	 * @param renderable true if body is to be rendered on canvas
	 */
	public void setRenderable(boolean renderable) {}

	/**
	 * @return true if body can be touched by mouse
	 */
	public boolean isTouchable() {return false;}

	/**
	 * @param touchable true if body can be touched dragged and selected by mouse
	 */
	public void setTouchable(boolean touchable) {}

	/**
	 * @return charge on body in microCoulomb
	 */
	public double getCharge(){	return 0;	}
	
	/**
	 * @param charge charge on the body in MicroCoulomb (may be positive negative or zero)
	 */
	public void setCharge(double charge){}
	/**
	 * true if free body diagram of body is to be drawn
	 * @return {boolean}
	 */
	public boolean isFbdDrawn() {return false;}

	/**
	 * sets free body diagram of the body enabled
	 * @param fbdDrawn true if free body diagram of body is to be drawn
	 */
	public void setFbdDrawn(boolean fbdDrawn) {}
	
	/**
	 * returns zOrder of the body
	 * @return integer representing z position
	 */
	public int getzOrder() {return 0;}

	/**
	 * sets zOrder of the body
	 * @param zOrder the drawing order
	 */
	public void setzOrder(int zOrder) {}

	
	//methods wriittn for scripting
	
	/**
	 * Position of centre of mass of body in world coordinates
	 * @return Vector2 in world coordinattes
	 */
	public Vector2 getPosition(){return null;}
	
	/**
	 * Sets position of body in world coordinates
	 * @param x
	 * @param y
	 */
	public void setPosition(double x, double y){}
	
	/**Moves body such that its center lies at world origin*/
	public void translateToOrigin() {}
	
	/**
	 * Set position of body
	 * @param v Vector2 in world coordinate
	 */
	public void setPosition(Vector2 v){}
	
	/**
	 * translates body in world 
	 * @param x
	 * @param y
	 */
	public void translate(double x, double y){}
	
	
	/**
	 * Sets rotation about its center of mass. 
	 * @param th angle in radians CCW as positive
	 */
	public void setRotation(double th){
	}
	
	/**
	 * Returns rotation in radians CCW as positive
	 * @return
	 */
	public double getRotation(){
		return 0;
	}
	
	/**
	 * Sets rotation about its center of mass. 
	 * @param th angle in radians with CCW as positive
	 */
	public void rotate(double th){
		
	}
	
	/**
	 * Returns velocity of center of mass in  world coordinates
	 * @return Vector2
	 */
	public Vector2 getVelocity(){return null;}

	/**
	 * Sets Linear Velocity of body in world coordinates
	 * @param vx x component
	 * @param vy y component
	 */
	public void setVelocity(double vx, double vy){}


	/**
	 * Returns angular velocity of the body in radians per secon
	 * @return Number
	 */
	public double getAngularVelocity(){return 0;}


	/**
	 * Sets Angular Velocity of body 
	 * @param w Angular velocity in radian per second (ACW as positive)
	 */
	public void setAngularVelocity(double w){}

	/**
	 * Applies force(in Newton) on center of body 
	 * @param fx x component 
	 * @param fy y component
	 */
	public void applyForce(double fx, double fy){}

	/**
	 * Applies force(in Newton) at specific point of body 
	 * @param fx x component 
	 * @param fy y component
	 * @param px x coordinate of point on body in local coordinates 
	 * @param py y coordinate of point on body in local coordinates 
	 */
	public void applyForce(double fx, double fy,double px, double py){}
	
	/**
	 * Applies Impulse(in Newton-sec) on center of body 
	 * @param fx x component 
	 * @param fy y component
	 */
	public void applyImpulse(double jx, double jy){	}

	/**
	 * Applies Impulse(in Newton sec) at specific point of body 
	 * @param fx x component 
	 * @param fy y component
	 * @param px x coordinate of point on body in local coordinates 
	 * @param py y coordinate of point on body in local coordinates 
	 */
	public void applyImpulse(double jx, double jy,double px, double py){}
	
	
	/**
	 * get mass of body (return 0 of body is static)
	 * @return {Number} 
	 */
	public double getMass(){
		return 0;
	}

	/**
	 * Set mass of body
	 * @param m {Number} should be >=zero , pass 0 to set its mass infinite
	 */
	public void setMass(double m){
		
	}
	

	/**
	 * get Moment f inertia of body about its center of mass(return 0 of body is static)
	 * @return {Number} 
	 */
	public double getInertia(){
		return 0;
	}
	
	
	/**
	 * Set Moment of inertia of body about center of mass
	 * @param m {Number} should be >=zero , pass 0 to set its inertia infinite
	 */
	public void setInertia(double I){
		
	}
	
	/**
	 * Sets friction for body
	 * @param mu  {Number}  value must be >=0
	 */
	public void setFriction(double mu){}
	
	/**
	 * Set coefficient of restitution
	 * @param e {Number}  value in [0,1]
	 */
	public void setRestitution(double e){}
	
	/**
	 * Sets background image of body
	 * @param img {Image} the background image used to render body
	 * automatically adjusts scale of image to match body size
	 */
	public void setAnimation(Image img) {
		
	}
	
	/**
	 * Returns current Animation of the body
	 * @return {Image}
	 */
	public Image getAnimation() {
		return null;
	}

	/**
	 * Returns height of bounding box of non transformed body
	 * @return {Number} height of body in world units (meters)
	 */
	public double getWidth(){return 0;}
	
	/**
	 * Returns width of bounding box of non transformed body
	 * @return  {Number} width of body in world units (meters)
	 */
	public double getHeight(){return 0;}
	
	/**
	 * Sets size of body such that width and height in parameter become size of bounding box
	 * @param width {Number} desired width in world scale, must be >0
	 * @param height {Number} desired width in world scale, must be >0
	 * @return  {Boolean}  true if size can be set successfully, false if parameters are invalid
	 */
	public boolean setSize(double width,double height){return false;}
	

	/**
	 * Returns true if body does't sense and process collision
	 * @return
	 */
	public boolean isSensor() {return false;}
	
	/**
	 * Sets if body can sense and process collision
	 * @param sensor boolean flag if true then body does't sense and process collision
	 */
	public void setSensor(boolean sensor) {}
	
	/**
	 * returns text associated with body
	 * @return
	 */
	public String getText(){return null;}
	
	/**
	 * Sets text of body
	 * Text can have blocks as in example [font="default-large", color="red", alignX="left", alignY="top",  x="-1.3",y="0.7"]
	 * x and y are  in bodies local coordinate in world units <br>
	 * <b>defaults:</b> <br>
	 * font: default-normal  <br> 
	 * color: outline color of body  <br>
	 * alignX="center"  <br>
	 * alignY="center"  <br>
	 * x=0;  <br>
	 * y=0;  <br>
	 * Note that Next Block inherits previous block properties unless changed
	 * @param s Html String
	 */
	public void setText(String s){}
	
	/**
	 * Returns the Copy of this body, the copied body is same in look and size, 
	 * but is placed at origin and has speed zero
	 * @return new clone of body
	 */
	public Body copy(){return null;}
	
	/**
	 * Returns the Copy of this body, the copied body is same in look and size, 
	 * @param applyTransform if true bodies velocity and position are also copied else 
	 * returned body is placed at origin and has speed zero
	 * @return new clone of body
	 */
	public Body copy(boolean applyTransform){return null;}

	/**
	 * Scales  body in each direction 
	 * @param xScale absolute scale
	 * @param yScale absolute scale
	 */
	public void scaleTo(double xScale, double yScale) {}
		
	/**
	 * Scales body in each direction 
	 * @param xScale relative scale
	 * @param yScale relative scale
	 */
	public void scaleBy(double xScale, double yScale) {}
	
	
	/**
	 * Sets Action of body
	 * @param action Action created using {@link Actions}
	 */
	public void setAction (Action action) {}

	/**
	 * returns action associated to the body
	 */
	public Action getAction () {return null;}
	
	/**
	 * Returns the name of the body.
	 * @return String
	 */
	public String getName() {return null;}
	
	/**
	 * Sets the name of the body.
	 * @param name String value for the name
	 */
	public void setName(String name) {}
	
	/**
	 * Returns custom user data associated with body
	 */
	public Object getUserData() {
		return null;
	}
	
	/**
	 * sets custom user data for this body
	 */
	public void setUserData(Object userData) {
		
	}


	@Override
	public void removeAction() {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void act(double delta) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public boolean remove() {
		// TODO Auto-generated method stub
		return false;
	}


	@Override
	public Vector2 getScale() {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public void setFillColor(Object color) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void setVisible(boolean visible) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public boolean isVisible() {
		// TODO Auto-generated method stub
		return false;
	}
}
