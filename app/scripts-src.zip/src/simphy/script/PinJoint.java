package simphy.script;

/**
 * Implementation of a pin joint.
 * <p>
 * A pin joint is a joint that pins a body to a specified world space point
 * using a spring-damper system.  This joint will attempt to place the given
 * anchor point at the target position.
 * <p>
 * NOTE: The anchor point does not have to be within the bounds of the body.
 * <p>
 * By default the target position will be the given world space anchor. Use 
 * the {@link #setTarget(Vector2)} method to set a different target.
 * <p>
 * The pin joint requires the spring-damper system to function properly and
 * as such the frequency value must be greater than zero.  Use a 
 * {@link RevoluteJoint} instead if a spring-damper system is not desired.
 * A good starting point is a frequency of 8.0 and damping ratio of 0.3
 * then adjust as necessary.
 * <p>
 * The {@link #getAnchor1()} method returns the target and the 
 * {@link #getAnchor2()} method returns the world space anchor point.
 * <p>
 * Both the {@link #getBody1()} and {@link #getBody2()} methods return the same
 * body.
 * <p>
 */
public class PinJoint extends Joint{
	
	/**
	 * Returns the target point in world coordinates.
	 * @param target the target point
	 * @throws NullPointerException if target is null
	 */
	public void setTarget(Vector2 target) {
		
	}
	
	/**
	 * Returns the target point in world coordinates
	 * @return {@link Vector2}
	 */
	public Vector2 getTarget() {
		return null;
	}
	
	/**
	 * Returns the maximum force this constraint will apply in newtons.
	 * @return double
	 */
	public double getMaximumForce() {
		return 0;
	}
	
	/**
	 * Sets the maximum force this constraint will apply in newtons.
	 * @param maximumForce the maximum force in newtons; in the range [0, &infin;]
	 * @throws IllegalArgumentException if maxForce less than zero
	 */
	public void setMaximumForce(double maximumForce) {
		
	}

	/**
	 * Returns the damping ratio.
	 * @return double
	 */
	public double getDampingRatio() {
		return 0;
	}
	
	/**
	 * Sets the damping ratio.
	 * @param dampingRatio the damping ratio; in the range [0, 1]
	 * @throws IllegalArgumentException if dampingRation is less than zero or greater than one
	 */
	public void setDampingRatio(double dampingRatio) {
		
	}
	
	/**
	 * Returns the spring frequency.
	 * @return double
	 */
	public double getFrequency() {
		return 0;
	}
	
	/**
	 * Sets the spring frequency.
	 * @param frequency the spring frequency in hz; must be greater than zero
	 * @throws IllegalArgumentException if frequency is less than or equal to zero
	 */
	public void setFrequency(double frequency) {
		
	}
	
	
}
