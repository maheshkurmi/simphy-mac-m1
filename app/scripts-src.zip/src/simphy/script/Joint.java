package simphy.script;

/**
 * Represents constrained motion between two {@link Body}s.
 * */
public abstract class Joint {
	protected Joint() {
	}

	/**
	 * Returns the anchor point on the first {@link Body} in world coordinates.
	 * 
	 * @return {@link Vector2}
	 */
	public  Vector2 getAnchor1() {
		return null;
	}

	/**
	 * Returns the anchor point on the second {@link Body} in world coordinates.
	 * 
	 * @return {@link Vector2}
	 */
	public  Vector2 getAnchor2() {
		return null;
	}

	/**
	 * Returns the force applied to the {@link Body} in order to satisfy the
	 * constraint in Newtons.
	 * 
	 * @param invdt
	 *            the inverse delta time
	 * @return {@link Vector2}
	 */
	public  Vector2 getReactionForce(double invdt) {
		return null;
	}

	/**
	 * Returns the torque applied to the {@link Body}s in order to satisfy the
	 * constraint in newton-meters.
	 * 
	 * @param invdt
	 *            the inverse delta time
	 * @return double
	 */
	public  double getReactionTorque(double invdt) {
		return 0;
	}

	/**
	 * Returns true if collision between the joined {@link Body}s is allowed.
	 * 
	 * @return boolean
	 */
	public boolean isCollisionAllowed() {
		return false;
	}

	/**
	 * Sets whether collision is allowed between the joined {@link Body}s.
	 * 
	 * @param flag
	 *            true if collisions are allowed
	 */
	public void setCollisionAllowed(boolean flag) {
	}


	/**
	 * @return true if joint is renderable
	 */
	public boolean isRenderable() {
		return false;
	}

	/**
	 * @param renderable
	 *            the renderable to set
	 */
	public void setRenderable(boolean renderable) {
	}

	
	/**
	 * @return {Color} Color used to render joint
	 */
	public Color getColor() {
		return null;
	}

	/**
	 * Sets color with which joint should be rendered
	 * @param color {Color|String} Color Object or css color string  ex.<br>
	 * 	<ol> 
	 * 	<li> Common color name "red", "green" </li>
	 *	<li> Hexadecimal representation of color such as #FF0096 or 0xFF0096 </li>
	 * 	<li> Color functions "rgb(255,0,0)","hsl(180, 50%, 50%)","rgba(255,255,120,1)"</li>
	 * @throws IllegalArgumentException if color is null or invalid
	 */
	public void setColor(Object color) {
	
	}
	
	

	
	/**
	 * size of the joint (size=1 means default size) size >1 scales up size
	 * while size<1 scales down the size (max size=5)
	 * 
	 * @param size
	 */
	public void setSize(float size) {
	}

	/**
	 * size of the joint
	 * 
	 * @return
	 */
	public float getSize() {
		return 0;
	}

	/**
	 * Sets opacity of joint
	 * 
	 * @param opacity
	 *            Opacity % an integer between 10 and 100
	 */
	public void setOpacity(int opacity) {
	}

	/**
	 * 
	 * @return returns opacity % of the joint
	 */
	public int getOpacity() {
		return 0;
	}
	
	/**
	 * Returns the name of the joint.
	 * @return String
	 */
	public String getName() {return null;}
	
	/**
	 * Sets the name of the joint.
	 * @param name String value for the name
	 */
	public void setName(String name) {}
	
	/**
	 * Returns custom user data associated with joint
	 */
	public Object getUserData() {
		return null;
	}
	
	/**
	 * sets custom user data for this joint
	 */
	public void setUserData(Object userData) {
		
	}

}
