package js.ecma.api.ecma5.functions;

import js.api.ecma3.functions.JSStringFunctions;
import js.ecma.api.ecma5.JS5String;


public interface JS5StringFunctions extends JS5ObjectFunctions, JSStringFunctions {

	/**
     * <b>function trim ()</b> string leading and trailing whitespace.
     * 
     * @returns A copy of <b><i>string</i></b>, with all leading and trailing whitespace removed.
     * @see  js.ecma.api.ecma5.JS5String String
     * @since   Standard ECMA-262 5th. Edition 
     */ 
    public JS5String trim();
}
