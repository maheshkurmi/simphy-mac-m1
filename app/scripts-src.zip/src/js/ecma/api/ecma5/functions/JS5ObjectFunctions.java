package js.ecma.api.ecma5.functions;

import js.api.ecma3.functions.JSObjectFunctions;


public interface JS5ObjectFunctions extends JSObjectFunctions {
	
	
}
