package js.ecma.api.ecma3;


/**
 * Object Undefined
 * @since Standard ECMA-262 3rd. Edition
 */
public abstract class JSUndefined {

}
