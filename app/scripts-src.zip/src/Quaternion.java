

/**
 * Represents a quaternion. Quaternion has the capability to rotate a vector v.
 * <p><b>How to use:</b>
 * If we want to rotate a vector about axis(vector) u (say xi+yj+zk) by an angle θ then, the 
 * quaternion used for this transformation is
 * </p>
 * <pre>
 * q = cos(θ/2) + sin(θ/2)*u
 * or
 * q = cos(θ/2) + sin(θ/2)*(xi + yj + zk)
 *
 * <b><i>Right-handed system:</i></b>
 * vq' = q' * vq * q,   clockwise rotation
 * vq' = q  * vq * q',   counter-clockwise rotation
 * <b><i>Left-handed system:</i></b>
 * vq' = q  * vq * q',   clockwise rotation
 * vq' = q' * vq * q,   counter-clockwise rotation * 
 * 
 * where,
 * vq is a vector to be rotated, encoded in a quaternion with q0 = 0,
 * vq'is vector after rotation by angle and direction as specified by q,
 * </pre>
 */
public final class Quaternion 
{
	public float w = 1;
	
	/**
	 * The imaginary (xi,yi,ji) part.
	 */
	public float x,y,z;
	
	/**
	 * Returns a copy of this quaternion. If a target quat is specified then this
	 * quat is copied into this target quat. If it is null then a new
	 * fresh quat is created.
	 * 
	 * @param {Quat} target
	 *            Optional target quat, can be null
	 * @return {Quat} A copy of this quat
	 */
	public Quaternion clone(Quaternion target) {
		return null;	
	}
	
	
	/**
	 * Set this quaternion's value.
	 * @param aQ the quaternion whose values to copy.
	 * @return this.
	 */
	public Quaternion set(Quaternion aQ)
	{
		return null;
	}	
	
	/**
	 * Sets Quat in form w+ i(x+y+z)
	 * @param x the x-component of imaginary part
	 * @param y the y-component of imaginary part
	 * @param z the z-component of imaginary part
	 * @param w the real part
	 */
   public Quaternion set( float x,float y,float z,float w ) {
		return null;

	}
   
	/**
	 * Sets this quaternion from the rotation specified by rotation angles about axes in order XYZ
	 * 
	 * @param thX
	 *            angle in radians about x axis
	 * @param thY
	 *            angle in radians about y axis
	 * @param thZ
	 *            angle in radians about z axis
	 * @return
	 */
	public Quaternion setFromEuler(float thX, float thY, float thZ) {
		return null;

	}
	
	
	/**
	 * Sets this quaternion from rotation specified by axis and angle.
	 * @param axis Unit Vector 
	 * @param angle rotation in radians
	 * @return the Quat for chaining
	 */
	public Quaternion setFromAxisAngle(Vector3 axis, float angle ) {
		return null;

	}
	
	  /**
     * Get a rotation quaternion for the given 3D Euler angles around the
     * given axis vectors.
     *
     * @param u a unit vector representing the x-axis.
     * @param v a unit vector representing the y-axis.
     * @param w a unit vector representing the z-axis.
     */
	public Quaternion setFromEulerRotation(float ya, float pitch , float roll, Vector3 u, Vector3 v, Vector3 w)
	{

		return null;
	}	
	

	/**
	 * Sets this quaternion from rotation component of m.
	 * @param m 	// assumes the upper 3x3 of m is a pure rotation matrix (i.e, unscaled)
	 * @return this
	 */
	public Quaternion setFromRotationMatrix(Matrix4 m ) {

		return null;

	}

	/**
	 * Sets this quaternion to the rotation required to rotate direction vector vFrom to direction vector vTo.
	 * vFrom and vTo are assumed to be normalized.
	 * @param vFrom
	 * @param vTo
	 * @return
	 */
	public Quaternion setFromUnitVectors ( Vector3 vFrom , Vector3 vTo) {
		return null;
	}
   
   /**
	 * Extracts the euler angles corresponding to this quat into the target vector.
	 * If target vector is null,then a new  vector set as this quats rotation is returned
	 * 
	 * @param {Vector3} target
	 *            Optional target vector, can be null
	 * @return {Vector3} target Vector set as this quats rotation about x,y,z axis in order
	 */
   public Vector3 extractEulerAngles(Vector3 target){
	   
		return null;

		
   }	
   
   
   public boolean equals(Object obj) {
		return true;

	}

   
   /**
    * Post Multiplies this quaternion by q.
    * @param q
    * @return this Quat after multiplication
    */
   public Quaternion multiply(Quaternion q) {
		return null;
	}

   /**
    * Pre-multiplies this quaternion by q.
    * @param q
    * @return this Quat after multiplication
    */
   public Quaternion premultiply (Quaternion q ) {
		return null;
	}

   /**
    * Returns the angle between this quaternion and quaternion q in radians.
    * @param q
    * @return
    */
   public float angleTo(Quaternion q ) {
		return 0;
	}

   
   /**
    * Rotates this quaternion by a given angular step to the defined quaternion q. 
    * The method ensures that the final quaternion will not overshoot q.
    * @param q The target quaternion.
    * @param step The angular step in radians.
    * @return this
    */
	public Quaternion rotateTowards (Quaternion q, float step ) {

		return null;


	}

	/**
	 * Handles the spherical linear interpolation between quaternions. t represents the amount of rotation between this quaternion (where t is 0) and qb (where t is 1). 
	 * This quaternion is set to the result. 
	 * @param qb The ending quaternion (where t is 1, t=0 at thsi quat)
	 * @param t  interpolation factor in the closed interval [0, 1].
	 * @return this 
	 */
	public Quaternion lerp ( Quaternion qb, float t ) {

		return null;
	}

	
	
	/**
	 * Inverts this quaternion -normalizes and calculates the conjugate.
	 * @return
	 */
	public Quaternion invert() {
		return null;

	}

	/**
	 * Returns the rotational conjugate of this quaternion. 
	 * The conjugate of a quaternion represents the same rotation in the opposite direction about the rotational axis.
	 * @return this
	 */
	public Quaternion conjugate() {
		return null;

	}

	/**
	 * Get the length of this quaternion.
	 * @return a value >= 0.
	 */
    public float getLength()
    {
		return 0;
    }
    
    /**
	 * Get the length of this quaternion.
	 * @return a value >= 0.
	 */
    public float getLengthSq()
    {
		return 0;
    }
    
    /**
     * Calculates the dot product of quaternions v and this one.
     */
    public float dot(Quaternion q) {
		return 0;
	}

    
	/**
	 * Normalise this quaternion so that it becomes a unit quaternion whose 
	 * {@link #getLength()} equals 1. 
	 */
	public Quaternion normalize() {
		return null;
	}

   
	
    	
	/**
	 * Add another quaternion to this one.
	 * @param aQuat the quaternion to add to this one.
	 */
	public void add(Quaternion aQuat)
	{
		
	}
	
	

	/**
	 * Subtract another quaternion from this one.
	 * 
	 * @param aQuat the quaternion to subtract from this one.
	 */
	public void subtact(Quaternion aQuat)
	{
		
	}	
	
	
	
		/**
	 * Multiply this quaternion by a scalar value.
	 * 
	 * @param aVal the scalar value to multiply this quaternion by.
	 */
	public void scale(float scale)
	{
		
	}
	
	

	
}



