

/** A color class, holding the r, g, b and alpha component as floats in the range [0,1]. All methods perform clamping on the
 * internal values after execution.
 */
public class Color {

	/** the red components in [0,1]**/
	public float r;
	/** the green components in [0,1]**/
	public float g;
	/** the blue components in [0,1]**/
	public float b;
	/** the alpha components in [0,1]**/
	public float a;

	/** Constructs a new Color with all components set to 0. */
	public Color () {
	}

	public static Color RED=new Color();
	/**
	 * Creates sRGB color from CSS color
	 * @param cssColor CSS Color String example: "red", "0xFF0096", "#FF0096" ,"rgb(1,0.2,0.1)","hsb(1,0.2,0.1)","rgba(1,0.2,0.1,1)","hsba(1,0.2,0.1,1)"
	 */
	public Color(String cssColor){
	}
	 /**
     * Creates an sRGB color with the specified combined RGBA value consisting
     * of the alpha component in bits 24-31, the red component in bits 16-23,
     * the green component in bits 8-15, and the blue component in bits 0-7.
     * @param rgba the combined RGBA components
     * */
	public Color (int rgba8888) {
	}

	 /**
     * Creates an sRGB color with the specified red, green, blue, and
     * alpha values in the range (0.0 - 1.0).  
     * @param r the red component
	 * @param g the green component
	 * @param b the blue component
	 * @param a the alpha component */
	public Color (float r, float g, float b, float a) {
	}
	


	/** Sets this color to the given color.
	 * 
	 * @param color the Color */
	public Color set (Color color) {
		return this;
	}
	
	/**
	 * returns color as 32bit in in RGBA8888 format	
	 * @return
	 */
	public  int toRGBA8888 () {
		return 0;
	}

	/**
	 * Sets transparency of color
	 * @param f factor in [0,1]
	 */
	public Color setTransparency(float f){
		return this.set(r,g,b,f);
	}
	
    /**
     * Creates a new <code>Color</code> that is a brighter version of this
     * <code>Color</code>.
     * <p>
     * This method applies an arbitrary scale factor to each of the three RGB
     * components of this <code>Color</code> to create a brighter version
     * of this <code>Color</code>.
     * The {@code alpha} value is preserved.
     * Although <code>brighter</code> and
     * <code>darker</code> are inverse operations, the results of a
     * series of invocations of these two methods might be inconsistent
     * because of rounding errors.
     * @return     a new <code>Color</code> object that is
     *                 a brighter version of this <code>Color</code>
     *                 with the same {@code alpha} value.
     * @see        #darker
     */
    public Color brighter() {
       return null;
    }
    
    /**
     * Creates a new <code>Color</code> that is a darker version of this
     * <code>Color</code>.
     * <p>
     * This method applies an arbitrary scale factor to each of the three RGB
     * components of this <code>Color</code> to create a darker version of
     * this <code>Color</code>.
     * The {@code alpha} value is preserved.
     * Although <code>brighter</code> and
     * <code>darker</code> are inverse operations, the results of a series
     * of invocations of these two methods might be inconsistent because
     * of rounding errors.
     * @return  a new <code>Color</code> object that is
     *                    a darker version of this <code>Color</code>
     *                    with the same {@code alpha} value.
     * @see        #brighter
     */
    public Color darker() {
    	return null;
    }
    
    /**
     * returns shadow of a color
     * @param color
     * @return
     */
   public  Color shadow()  {
       return null;
    }   

   /**
	 * Returns a foreground color (for text) given a background color by examining
	 * the brightness of the background color.
	 * @param color the foreground color
	 * @return Color
	 */
	public Color foreground() {
		return null;
	}


    public Color highlight()  {
      return null;
    }  
    
    
	/** Multiplies the this color and the given color
	 * 
	 * @param color the color
	 * @return this color. */
	public Color mul (Color color) {
		return null;
	}

	/** Multiplies all components of this Color with the given value.
	 * 
	 * @param value the value
	 * @return this color */
	public Color mul (float value) {
		return null;
	}

	/** Adds the given color to this color.
	 * 
	 * @param color the color
	 * @return this color */
	public Color add (Color color) {
		return null;
	}

	
	
	/** Subtracts the given color from this color
	 * 
	 * @param color the color
	 * @return this color */
	public Color sub (Color color) {
		return null;
	}


	/** Sets this Color's component values.
	 * 
	 * @param r Red component
	 * @param g Green component
	 * @param b Blue component
	 * @param a Alpha component
	 * 
	 * @return this Color for chaining */
	public Color set (float r, float g, float b, float a) {
		return null;
	}


	/** Linearly interpolates between this color and the target color by t which is in the range [0,1]. The result is stored in
	 * this color.
	 * @param target The target color
	 * @param t The interpolation coefficient
	 * @return This color for chaining. */
	public Color lerp (final Color target, final float t) {
		return null;
	}

	/** Linearly interpolates between this color and the target color by t (in order of t:1) which is in the range [0,1]. The result is stored in
	 * this color.
	 * @param r The red component of the target color
	 * @param g The green component of the target color
	 * @param b The blue component of the target color
	 * @param a The alpha component of the target color
	 * @param t The interpolation coefficient
	 * @return This color for chaining. */
	public Color lerp (final float r, final float g, final float b, final float a, final float t) {
		return null;
	}

	
	/** @return a copy of this color */
	public Color copy () {
		return null;
	}
	
	
   
}
