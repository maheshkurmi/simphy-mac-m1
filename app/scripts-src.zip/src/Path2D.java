

/**
 * Coordinates of path are always in canvas default coordinates
 * 1 pixel per unit , X right and Y down
 * @author mahesh
 *
 */
public class Path2D {
	
	/**
	 * Constructs a new double precision Path2D object from an path object. All of the initial geometry and the winding rule for this path are taken from the specified Shape object.
	 * @param p
	 */
	public Path2D(Path2D p){
		
	}
	
	public Path2D() {
		
	}

	/**
	 * Transform this path with given affine transform as arguement
	 * @param transform
	 * @return
	 */
	protected void transform(Transform transform){
		
	}
	
	/**
	 * returns new path after applying transform to it
	 * @param transform affine Transform to be applied
	 * @return {Path2D}
	 */
	protected Path2D getTransformedPath(Transform transform){
		return null;
	}
	
	/**
	 * returns true if a certain point is in the current path 
	 * @param x x-coordinate in canvas space (top left as origin)
	 * @return y y-coordinate in canvas space (top left as origin)
	 */
	public boolean contains(double x, double y){
		return false;
	}
	/**
	 * Resets the path to empty. The append position is set back to the
	 * beginning of the path and all coordinates and point types are forgotten
	 */
	public void beginPath() {
		
	}

	/**
	 * Adds a path to the current path.
	 * @param path
	 */
	public void addPath(Path2D path){
		
	}
	

	/**
	 * Adds a path to the current path.
	 * @param path
	 * @param Transform (transform to be applied to path before adding it to this path
	 */
	public void addPath(Path2D path,Transform transform){
		
	}
	
	/**
	 * Adds a point to the path by moving to the specified coordinates, without
	 * creating a line
	 * 
	 * @param x
	 *            {Number} x coordinate
	 * @param y
	 *            {Number} y coordinate
	 */
	public void moveTo(double x, double y) {
		
	}

	/**
	 * Adds a point to the path by drawing a straight line from the current
	 * coordinates to the new specified coordinates
	 * 
	 * @param x
	 *            {Number} x coordinate
	 * @param y
	 *            {Number} y coordinate
	 */
	public void lineTo(double x, double y) {
		
	}

	/**
	 * creates a rectangular path whose starting point is at (x, y) and whose
	 * size is specified by width and height
	 * 
	 * @param x
	 *            {Number} x coordinate of the rectangle's starting point.
	 * @param y
	 *            {Number} y coordinate of the rectangle's starting point.
	 * @param width
	 *            {Number} The rectangle's width. Positive values are to the
	 *            right, and negative to the left.
	 * @param height
	 *            {Number} The rectangle's height. Positive values are down, and
	 *            negative are up.
	 */
	public void rect(double x, double y, double width, double height) {
	
	}

	/**
	 * creates an arc (used to create circles, or parts of circles)
	 * 
	 * @param x
	 *            {Number} The x-coordinate of the center of the circle
	 * @param y
	 *            {Number} The y-coordinate of the center of the circle
	 * @param r
	 *            {Number} The radius of the circle
	 * @param sa
	 *            {Number} The starting angle, measured clockwise from the
	 *            positive x-axis and expressed in radians.
	 * @param ea
	 *            {Number} The ending angle, measured clockwise from the
	 *            positive x-axis and expressed in radians.
	 */
	public void arc(double x, double y, double r, double sa, double ea) {
		
	}

	/**
	 * creates an arc/curve (used to create circles, or parts of circles)
	 * 
	 * @param x
	 *            {Number} The x-coordinate of the center of the circle
	 * @param y
	 *            {Number} The y-coordinate of the center of the circle
	 * @param r
	 *            {Number} The radius of the circle
	 * @param sa
	 *            {Number} The starting angle, measured clockwise from the
	 *            positive x-axis and expressed in radians.
	 * @param ea
	 *            {Number} The ending angle, measured clockwise from the
	 *            positive x-axis and expressed in radians.
	 * @param ccw
	 *            {Boolean} if true drawing is done counterclockwise else
	 *            clockwise
	 */
	public void arc(double x, double y, double r, double sa, double ea, boolean acw) {
		
		
	}

	/**
	 * creates a circular arc passing through currentPoint(current moveTo),
	 * (x1,y1) and (x2,y2)
	 * 
	 * @param x1
	 *            {Number} The x-coordinate of the first point
	 * @param y1
	 *            {Number} The y-coordinate of the first point
	 * @param x2
	 *            {Number} The x-coordinate of the second point
	 * @param y2
	 *            {Number} The x-coordinate of the second point
	 * @param r
	 *            {Number} The arc's radius. Must be non-negative.
	 */
	public void arcTo(double x1, double y1, double x2, double y2, double r) {
		
	}
	/**
	 * @param  x, y -- The center of the ellipse offset from the last call.
	 * @param xRadius -- The radius of the ellipse in the x axis.
	 * @param yRadius -- The radius of the ellipse in the y axis.
	 * @param rotation -- The rotation angle of the ellipse in radians, counterclockwise from the positive X axis
	 */
	public void ellipse (float x,float y,float xRadius,float yRadius,float aRotation) {
	}

	/**
	 * @param  x, y -- The center of the ellipse offset from the last call.
	 * @param xRadius -- The radius of the ellipse in the x axis.
	 * @param yRadius -- The radius of the ellipse in the y axis.
	 * @param rotation -- The rotation angle of the ellipse in radians, counterclockwise from the positive X axis
	 * @param startAngle -- The angle at which the ellipse starts, measured clockwise from the positive x-axis and expressed in radians.
	 * @param endAngle -- The angle at which the ellipse ends, measured clockwise from the positive x-axis and expressed in radians.
	 * @param acw --A Boolean which, if true, draws the ellipse anticlockwise (counter-clockwise)
	 */
	public void ellipse (float x,float y,float xRadius,float yRadius,float aRotation, float aStartAngle,float aEndAngle,boolean acw) {
		
	}
	
	/**
	 * Adds a curved segment, defined by two new points, to the path by drawing
	 * a Quadratic curve that intersects both the current coordinates(moveTo)
	 * and the specified coordinates (x,y)
	 * 
	 * @param cpx
	 *            {Number} The x-coordinate of the quadratic control point
	 * @param cpy
	 *            {Number} The y-coordinate of the quadratic control point
	 * @param x
	 *            {Number} The x-coordinate of the ending point
	 * @param y
	 *            {Number} The y-coordinate of the ending point
	 */
	public void quadraticCurveTo(double cpx, double cpy, double x, double y) {
		
	}

	/**
	 * Adds a curved segment, defined by three new points, to the path by
	 * drawing a Bezier curve that intersects both the current coordinates and
	 * the specified coordinates (x,y), using the specified points (cpx1,cpy1)
	 * and (cpx2,cpy2) as Bezier control points.
	 * 
	 * @param cpx1
	 *            {Number} The x-coordinate of the first Bezier control point
	 * @param cpy1
	 *            {Number} The y-coordinate of the first Bezier control point
	 * @param cpx2
	 *            {Number} The x-coordinate of the second Bezier control point
	 * @param cpy2
	 *            {Number} The x-coordinate of the second Bezier control point
	 * @param x
	 *            {Number} The x-coordinate of the ending point
	 * @param y
	 *            {Number} The y-coordinate of the ending point
	 */
	public void bezierCurveTo(double cpx1, double cpy1, double cpx2, double cpy2, double x, double y) {
		
	}

	/**
	 * creates a path from the current point back to the starting point.
	 */
	public void closePath() {
		
	}
	
	/**
	 * Appends shape/glyph from text to this path
	 * @param text
	 * @param x
	 * @param y
	 * @param font
	 */
	public void addText(String text, double x, double y, String font){
		
	}
	

}
