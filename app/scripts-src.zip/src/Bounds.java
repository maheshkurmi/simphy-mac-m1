

/**
 * Provides a instance of a boundary object that stores the maximum and minimum extents of a bounding box in 3D space.
 * <p>
 *
 */
public class Bounds {

	/** A static representation of a large number to be used for initialization of the boundaries */
	public static final float LARGE = Float.MAX_VALUE;

	/** The minimum point of the bounding box */
	public Vector3 min;

	/** The maximum point of the bounding box */
	public Vector3 max;

	/**
	 * Constructor that initializes the bounding box to the specified bounding values passed in as vectors
	 * 
	 * @param v1
	 *            The minimum boundary point specified by a Vector3 object
	 * @param v2
	 *            The maximum boundary point specified by a Vector3 object
	 */

	/** Sets the minimum and maximum vector to positive and negative infinity.
	 *
	 * @return This bounding box for chaining. */
	public Bounds reset(){
		return this;
	}
	/**
	 * Recalculates the boundary limits based on the coordinates of a point passed into it. If any of the coordinates of
	 * the passed in point are beyond the current bounding box limits then the bounding box is expanded.
	 *
	 * @param x
	 *            The x coordinate of a point used to adjust the boundary box
	 * @param y
	 *            The y coordinate of a point used to adjust the boundary box
	 * @param z
	 *            The z coordinate of a point used to adjust the boundary box
	 */
	public void update(float x, float y, float z) {
		
	}

	/**
	 * Recalculates the boundary limits based on the coordinates of a point passed into it. If any of the coordinates of
	 * the passed in point are beyond the current bounding box limits then the bounding box is expanded.
	 *
	 * @param v
	 *            The Vector3 instance of a point used to adjust the boundary box
	 */
	public void update(Vector3 v) {
	}

	/**
	 * Returns bounding radius
	 * 
	 * @return
	 */
	public float getRadius() {
		return 0 ;
	}

	/**
	 * Return center of bounds
	 */
	public Vector3 getCenter() {
		return null;
	}

	/** Returns whether the given vector is contained in this bounding box.
	 * @param v The vector
	 * @return Whether the vector is contained or not. */
	public boolean contains (Vector3 v) {
		return true;
	}

	@Override
	public String toString () {
		return null;
	}
	/**
	 * Returns true if bounds are valid
	 * 
	 * @return
	 */
	public boolean isValid() {
		return true;
	}

	

	/**
	 * Merges bounds
	 * 
	 * @param b
	 */
	public void Merge(Bounds b) {
		
	}

	/** Multiplies the bounding box by the given matrix. This is achieved by multiplying the 8 corner points and then calculating
	 * the minimum and maximum vectors from the transformed points.
	 *
	 * @param transform The matrix
	 * @return This bounding box for chaining. */
	public Bounds transform (Matrix4 transform) {
		return this;
	}
	
	public Bounds clone(){
		return null ;
	}
	
	
}