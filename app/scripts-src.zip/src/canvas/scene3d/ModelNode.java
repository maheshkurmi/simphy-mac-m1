package canvas.scene3d;

import org.omg.CORBA.Bounds;

public class ModelNode extends SceneNode3D {
	
	/**
	 * Resizes Model to unit size (insides cube of size 2) and centers it at origin
	 */
	public void normalize(){
		
	}          
	

	/**
	 * Clones this node Note that Model is not cloned, only its reference is copied
	 */
	public ModelNode clone() {
		return null;
	}

	public void setMaterial(Material material){
		
	}
	
	public Material getMaterial(){
		return null;
	}
	
	public void setRenderObjectBounds(boolean b) {
		
	}

	
	/**
	 * Returns bounds in world coordinates
	 * @return
	 */
	public Bounds getBounds(){
		return null;
	}

	/**
	 * Returns bounding radius of model in world units
	 * @return
	 */
	public float getBoundingRadius(){
		return 0;
	}

}
