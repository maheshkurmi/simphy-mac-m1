package canvas.scene3d;

import script.Color;
import script.Vector3;

/**
 * Class to trace locus of a point on body
 * @author Mahesh Kurmi
 */
public class Tracer extends SceneNode3D{
	public static final int SOLID = 0;
	public static final int DOTS = 1;

	/** Returns Pixel size of tracer */
	public int getPtSize() {
		return 0;
	}

	/** Sets pixel size of tracer */
	public void setPtSize(int ptSize) {
		
	}
	
	/**
	 * 
	 * @return
	 */
	public float getResolution(){
		return 0;
	}
	
	/**
	 * Sets minimum gap between 2 successive points in tracer
	 * @param resolution
	 */
	public void setResolution(float resolution){
		
	}
	/** Returns Maximum Number of points in tracer array */
	public int getPtsCount() {
		return 0;
	}

	/** Sets Maximum Number of points in tracer array */
	public void setPtsCount(int count) {
	}

	/** Returns Mode Used to draw Tracer can be Solid[0] or dotted [1] */
	public int getMode() {
		return 0;
	}

	/** Sets Mode Used to draw Tracer can be Solid[0] or dotted [1] */
	public void setMode(int mode) {
		
	}


	/**
	 * Reinitializes the tracer
	 */
	public void reset() {
		
	}



	/**
	 * updates the Tracer with current Location of bodyPoint
	 */
	public boolean update(float dt) {
		
		return true;
	}
	

	/**
	 * @return the tracer Color
	 */
	public Color getColor() {
		return null;
	}

	/**
	 * Sets Color used to render trajectories
	 * @param ptColor
	 *            the Color to set
	 */
	public void setColor(Color ptColor) {
	}

	/**
	 * True if linear velocity is to be shown in tracer
	 * @return
	 */
	public boolean isShowVelocity() {
		return true;
	}

	/**
	 * Sets if linear veclocity of tracer point is displayed
	 * @param showVelocity
	 */
	public void setShowVelocity(boolean showVelocity) {
	}
	
	/**
	 * Returns true if angular velocity is to be dispalyed
	 * @return
	 */
	public boolean isShowAngularVelocity() {
		return true;
	}

	/**
	 * Sets if angular velocity is to be dispalyed
	 * @param showAnglurVel
	 */
	public void setShowAngularVelocity(boolean showAnglurVel) {
		
	}
	
	/**
	 * Returns true if linear acceleration is shown in tracers
	 * @return
	 */
	public boolean isShowAcceleration() {
		return true;
	}
	
	/**
	 * Sets if linear acceleration is to be displayed in tracer
	 * @param showAcceleration
	 */
	public void setShowAcceleration(boolean showAcceleration) {
		
	}
	
	/**
	 * returns acceleration of tracer point in current camera frame
	 */
	public Vector3 getAcceleration(){
		return null;
	}
	
	/**
	 * returns angular acceleration of body w.r.t. tracer point in ground frame
	 */
	public double getAngAcceleration(){
		return 0;
	}
	
	/**
	 * returns Velocity current camera frame of point whose trajectory is to be traced
	 * 
	 * @return
	 */
	public Vector3 getVelocity() {
		return null;

	}
	
	
}

