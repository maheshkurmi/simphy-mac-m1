package canvas.scene3d;

import script.Color;

public  class Material {

	
	
	public float opacity=1;

	public Material backMaterial=null;
	
	public String toString(){
		return null;
	}
    
	/**
	 * Sets identifier for the material
	 * @param id
	 */
	public void setId(String id){
		
	}
	
	/**
	 * Returns identifier of material
	 * @return
	 */
	public String getId(){
		return null;
	}
	
	/**
     * Sets texture for the material
     * @param imageName Name of image already loaded in Simphy
     */
    public void setTexture(String imageName){
    	
    }

    /**
     * returns name of Image being used as texture for the material
     * @return 
     */
    public String getTexture(){
    	return null;
    }
    
    /**
     * Sets the opacity of material (Default=1}
     * @param opacity (Number} 0=fully transparent, 1= fully opaque
     */
    public void setOpacity(float opacity){
    	
    }
    
    /**
     * Returns opacity of material
     * @return
     */
    public float getOpacity(){
    	return 0;
    }
    
    
	/**
	 * Material to render Mesh as Lines instead of filled triangles, with lighting disabled
	 * @param color {Color} color used to render mesh
	 * @param lineWidth {float} width of lines in pixels used to render material
	 * @return {Material} 
	 */
    public Material setAsLineMaterial(Color color,float lineWidth){
    	return null;
    }
    /**
	 * Material to render Mesh as points instead of filled triangles, with lighting disabled
	 * @param color {Color} color used to render mesh
	 * @param lineWidth {float} width of lines in pixels used to render material
	 * @return {Material} 
	 */
    public Material setAsPointMaterial(Color color,float pointSize){
    	return null;
    }
    
    /**
   	 * Material to render Mesh as points instead of filled triangles, with lighting disabled
   	 * @param color {Color} color used to render mesh
   	 * @param lineWidth {float} width of lines in pixels used to render material
   	 * @return {Material} 
   	 */
    public Material setAsFlatColorMaterial(Color color){
    	return null;
    }
    
    /**
	 * Creates material with lighting enabled & diffused color set as color
	 * @param color {Color} diffused color of material
	 * @param shininess {Number} a number in the range 0 to 128, a the number increases, specular highlights get smaller. 
	 * @see {@link Material#setDiffused(float, float, float)}
	 * @see {@link Material#setSpecular(float, float, float)}
	 * @see {@link Material#setAmbient(float, float, float)}
	 * @see {@link Material#isSmoothShading()}
	 */
	public Material setAsLightMaterial(Color color, float shininess){
		return null;
	}
	
	/**
	 * Sets Material used to render back facing polygons
	 * @param mat {material}
	 */
	public void setBackMaterial(Material mat){
		
	}
	
	/**
	 * Sets this material from preset materials
	 * @param presetName {String} Identifier name of the material like "gold", "silver","red","emerald" etc
	 * @return
	 * @throws SimphyScriptException 
	 */
	public Material setAsPresetMaterial(String presetName) {
		return null;
	}
	
	/**
	 * If true backface (face whose normal is away from viewer) is not rendered at all (Default is false)<br>
	 * (by default it is true, but for transparent meshes and when view point is inside mesh)
	 */
	public void setBackFaceCulled(boolean backFaceCulled) {
		
	}

	/**
	 * Returns true if backface (face whose normal is away from viewer) is not rendered at all
	 */
	public boolean isBackFaceCulled() {
		return true;
	}
	/**
	 * Set the scale and units used to calculate depth values, It is is useful for rendering hidden-line images, for
	 * applying decals to surfaces, and for rendering solids with highlighted edges.
	 * 
	 * @param factor
	 *            Specifies a scale factor that is used to create a variable depth offset for each polygon. The
	 *            initial value is 0.
	 * @param unit
	 *            Is multiplied by an implementation-specific value to create a constant depth offset. The initial
	 *            value is 0. to disable it pass 0 , 0 as parameters
	 */
	public void setPolygonOffset(float factor, float unit) {
		
	}

	 /**
     * Sets this object's diffuse color from an input Color. Defaults to {0.8,0.8,0.8,1.0}.
     * @param default_diffuse the color that the specular color is copied from - later changes to the Color object will not be reflected in this Material.
     */
	public void setDiffuse(float r, float g, float b){
		
	}

	 /**
     * This retrieves the diffuse color from this Material.
     * @return a new Color with components copied from this Material.
     */
    public Color getDiffuse() {
    	return null;
    }
	  /**
     * Sets this object's ambient color from an input Color. Defaults to {0.2,0.2,0.2,1.0}.
     * @param default_ambient the color that the specular color is copied from - later changes to the Color object will not be reflected in this Material.
     */
	public void setAmbient(float r, float g, float b){	
		
	}

    /**
     * This retrieves the ambient color from this Material.
     * @return a new Color with components copied from this Material.
     */
    public Color getAmbient() {
    	return null;
    }
    
	/**
    * Sets this object's specular color from an input Color. Default is {0,0,0,1}.
    * @param default_specular the color that the specular color is copied from - later changes to the Color object will not be reflected in this Material.
    */
	public void setSpecular(float r, float g, float b){
		
	}

	 /**
     * Retrieves the specular color from this Material.
     * @return a new Color with components copied from this Material.
     */
    public Color getSpecular() {
    	return null;
    }
    
    /**
     * Sets this object's emissive color from an input Color. Default is {0,0,0,1}.
     * @param emissive the color that the specular color is copied from - later changes to the Color object will not be reflected in this Material.
     */
    public void setEmissive(float r, float g, float b) {
        
    }
    
    /**
     * This retrieves the emissive color from this Material.
     * @return a new Color with components copied from this Material.
     */
    public Color getEmissive() {
    	return null;
    }
    
    /**
     * shininess property determines the size and sharpness of specular highlights is called shininess. Shininess is a number in the range 0 to 128. 
     * As the number increases, specular highlights get smaller. 
     * @param shininess the value to use for shininess {default=64}
     */
    public void setShininess(float shininess) {
       
    }
    
    /**
     * Retrieves the shininess from this Material.
     * @return the shininess value
     */
    public float getShininess() {
        return 0;
    }

    /**
     * Specifies the face to which material should be applied
     * @param frontFace if true material is applied on front face
     * @param BackFace if true material is applied on back face
     */
    public void setMaterialFaces(boolean frontFace, boolean backFace){
    	
    }
    
    /**
     * Sets flat or smooth shading while rendering Mesh in fillMode {Default : true}
     * @param smooth if true shading Mode is set smooth else it is set as flat
     */
    public void setSmoothShading(boolean smooth){
    	
    }
    
    /**
     * Returns flat or smooth shading while rendering Mesh in fillMode
     * @return {boolean} true if shading Mode is set smooth else false
     */
    public boolean isSmoothShading(){
    	return true;
    }
    
    /**
     * Enables or disables lighting for the material (by default enabled is set true) <br>
     * If lighting is disabled it used diffuse {@link #setDiffuse(float, float, float)} to render object
     * @param lightingEnabled
     */
    public void setLightingEnabled(boolean lightingEnabled){

    }
    
    /**
     * Returns if lighting for the material (by default enabled is set true) <br>
     * @return {boolean}
     */
    public boolean isLightingEnabled(){
    	return true;
    }
    
    /**
     * Sets Texture Color blending with Material color true or false (Default: true)
     * @param textureBlending if true color of texture is blended with material color
     */
    public void setTextureColorBlending(boolean textureBlending){

    }

    /**
     * Returns if Texture Color blending with Material color is enabled
     * @param textureBlending {boolean}
     */
    public boolean isTextureColorBlending(){
    	return true;
    }

	/**
	 * Sets this material as a replica of specified material 
	 * @param m {Material} material to be copied in this  
	 * @return {Material} this material
	 */
	public  Material set(Material m){
		return null;

	}
	
	/**
	 * Returns new Copy of this material
	 * @return {Material}
	 */
	public  Material clone(){
		return null;
	}
	
	/**
	 * Defaults taken from
	 * http://www.it.hiof.no/~borres/j3d/explain/light/p-materials.html
	 */
	public  static Material DEFAULT= null ;
	
	public  static Material BRASS= null;
	
	public  static Material BRONZE=null;
	
	public  static Material CHROME=null;
	
	public  static Material COPPER=null;
	
	public  static Material GOLD=null;
	
	public  static Material TIN=null;
	
	public  static Material SILVER=null;
	
	public  static Material EMERALD=null;
	
	public  static Material PERL=null;
	
	public  static Material RUBY=null;
	
	public  static Material TURQOISE=null;
	
	public  static Material RED=null;
	
	public  static Material GREEN=null;
	
	public  static Material YELLOW=null;
	
	public  static Material BLUE=null;
	
	public  static Material BLACK=null;
	
	public  static Material CYAN=null;
	
	public  static Material WHITE=null;
}
