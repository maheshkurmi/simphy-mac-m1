package canvas.scene3d;

import java.util.ArrayList;
import java.util.function.Function;

import script.Vector3;

public  class VectorField extends ModelNode{
	
	/**
	 * Sets maximum number of steps field line takes (default=100)
	 */
	public void setMaxSteps(int maxSteps){
		
	}
	
	/**
	 * Sets the steps size for field
	 */
	public void setStepSize(float step){
		
	}
	
	/**
	 * Adds stop point for field line (if field line reaches this point it breaks)
	 * @param stopPoint
	 */
	public void addStopPoint(Vector3 stopPoint){
		
	}
	
	/**
	 * removes all field lines form this Vector field
	 */
	public void reset(){
		
	}
	
	/**
	 * Sets the way arrows are rendered
	 * @param arrowLoc {Number} location of arrow as t value in [0 to 1]
	 * @param arrowSize {Number} size of arrow
	 */
	public void setFieldArrow(float arrowLoc, float arrowSize){
		
	}
	
	/**
	 * Sets maximum and minimum intensity of Vector field for which line is drawn
	 * once intensity reaches the limit line breaks
	 * @param min
	 * @param max
	 */
	public void setLimits(float min,float max){
		
	}
	
	public void addFieldLine(Vector3 pt){
		
	}
	/**
	 * Add field line starting at given point
	 * @param pt
	 */
	public void addFieldLine(Vector3 pt,boolean moveAgainstField){
	}
	
	
}
