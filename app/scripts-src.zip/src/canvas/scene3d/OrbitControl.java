package canvas.scene3d;

public class OrbitControl {
	    
				
	    /**Whether or not the controls are enabled.*/
		public boolean enabled = true;

	
		/**
		 * How far you can dolly in ( PerspectiveCamera only ). Default is 0.
		 */
		public float minDistance = 0;
		/**
		 * How far you can dolly out ( PerspectiveCamera only ). Default is Infinity.
		 */
		public float maxDistance = Float.POSITIVE_INFINITY;

		/**
		 * How far you can zoom in ( OrthographicCamera only ). Default is 0.
		 */
		public float minZoom = 0;
		/**
		 * How far you can zoom out ( OrthographicCamera only ). Default is Infinity.
		 */
		public float maxZoom = Float.POSITIVE_INFINITY;

		/**How far you can orbit vertically, upper limit. Range is 0 to Math.PI radians, and default is Math.PI.*/
		public float minPolarAngle = 0; // radians
		/**How far you can orbit vertically, lower limit. Range is 0 to Math.PI radians, and default is 0.*/
		public float maxPolarAngle = (float) Math.PI; // radians

		/**
		 * How far you can orbit horizontally, upper limit. Range is - Math.PI to Math.PI ( or Infinity for no limit ) and default is Infinity;
		 */
		public float minAzimuthAngle = Float.NEGATIVE_INFINITY; // radians
		/**How far you can orbit horizontally, lower limit. Range is - Math.PI to Math.PI ( or - Infinity for no limit ) and default is - Infinity;*/
		public float maxAzimuthAngle = Float.POSITIVE_INFINITY; // radians

		/**Set to true to enable damping (inertia), which can be used to give a sense of weight to the controls.*/
		public boolean enableDamping = false;
		/**The damping inertia used if {@link #enableDamping} is set to true.*/
		public float dampingFactor = 0.05f;

		/**
		 *  This option actually enables dollying in and out; move back and forth the perspective camera and zoom out/in for orthographic camera.
		 */
		public boolean enableZoom = true;
		/**
		 * Speed of zooming / dollying. Default is 1.
		 */
		public float zoomSpeed = 1.0f;

		/**Enable or disable horizontal and vertical rotation of the camera. Default is true.
		Note that it is possible to disable a single axis by setting the min and max of the polar angle or azimuth angle to the same value, which will cause the vertical or horizontal rotation to be fixed at that value.*/
		public boolean enableRotate = true;
		/**Speed of rotation. Default is 1.*/
		public float rotateSpeed = 1.0f;

		/**Enable or disable camera panning. */
		public boolean enablePan = true;
		/**Speed of panning. Default is 1.*/
		public float panSpeed = 1.0f;
		/**Defines how the camera's position is translated when panning. If true, the camera pans in screen space. Otherwise, the camera pans in the plane orthogonal to the camera's up direction. Default is false.*/
		public boolean screenSpacePanning = false; // if true, pan in screen-space
		/**How fast to pan the camera when the keyboard is used. Default is 7.0 pixels per keypress.*/
		public float keyPanSpeed = 7.0f;	// pixels moved per arrow key push

		/** Set to true to automatically rotate around the target
		 If auto-rotate is enabled, you must call controls.update() in your animation loop*/
		public boolean autoRotate = false;
		/**How fast to rotate around the target if .autoRotate : Booleanis true. Default is 2.0, which equates to 30 seconds per rotation at 60fps.*/
		public float autoRotateSpeed = 2.0f; // 30 seconds per round when fps is 60

		/**Enable or disable the use of keyboard controls.*/
		public boolean enableKeys = true;

		/**The camera being controlled.*/
		public Camera camera;
		
		/**
		 * Get the current vertical rotation, in radians.
		 * @return
		 */
		public float getPolarAngle() {
			return 0;
		}

		/**
		 * Get the current horizontal rotation, in radians.
		 * @return
		 */
		public float getAzimuthalAngle() {
			return 0;
		}

		/**Save the current state of the controls. This can later be recovered with .reset.*/
		public void saveState() {
			
		}
		
		/**Reset the controls to their state from either the last time the .saveState was called, or the initial state.*/
		public void reset() {
			
		}
		
}
