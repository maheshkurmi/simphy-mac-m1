package canvas.scene3d;

import java.nio.FloatBuffer;
import java.nio.ShortBuffer;

import org.omg.CORBA.Bounds;

/**
 * Mesh for the Geometry
 * 
 * @author maheshkurmi
 *
 */
public class Mesh {
	
	/**
	 * ReScales to fit Mesh in unit cube (insides cube of size 2) centered at origin
	 */
	public void normalize() {
		
	}

	/**
	 * Creates copy of the mesh, Note that it is shallow copy , the data is not copied
	 */
	public Mesh clone(){
		return null;
	}
	
	 /**
     * Returns the material .
     * @return The material object
     */
    public Material getMaterial() {
		return null;
    }
    
    /**
     * Sets new material .
     * @param The material object
     */
    public void setMaterial(Material material){
        
    }

    /**
     * Sets identifier for the mesh
     * @param id
     */
    public void setId(String id){

    }
    
    /**
     * returns identifier for the mesh
     */
    public String getId(){
		return null;
    }
   
    /**
     * Returns the bounding box.
     * @return The bounding box
     */
    public Bounds getBounds(){
		return null;
    }
    
    /**
     * Checks if model group has normals.
     *
     * @return True if it has normals, false if not
     */

    public boolean hasNormals()
    {
		return true;
    }


    /**
     * Checks if model group has texture coordinates.
     *
     * @return True if it has texture coordinates, false if not
     */

    public boolean hasTexCoords()
    {
		return true;

    }
    
    /**
     * Returns the vertices.
     *
     * @return The vertices
     */

    public FloatBuffer getVertices()
    {
		return null;
    }


    /**
     * Returns the normals.
     *
     * @return The normals
     */

    public FloatBuffer getNormals()
    {
		return null;
    }

    /**
     * Returns the colors.
     *
     * @return The colors
     */

    public FloatBuffer getColors()
    {
		return null;
    }

    /**
     * Returns the texture coordinates.
     *
     * @return The texture coordinates
     */

    public FloatBuffer getTexCoords()
    {
		return null;
    }


    /**
     * Returns the indices.
     *
     * @return The indices
     */

    public ShortBuffer getIndices()
    {
		return null;
    }


    /**
     * Returns the polygon size. This can be 1 (for points), 2 (for lines) or
     * 3 (for triangels) and 4 (for quads). Nothing else is allowed.
     *
     * @return The polygon size (1-3)
     */

    public int getSize()
    {
		return 0;
    }


    /**
     * Returns the number of indices.
     *
     * @return The number of indices
     */

    public int getIndexCount()
    {
		return 0;
    }


    /**
     * Returns the number of vertices in this model group.
     *
     * @return The number of vertices
     */

    public int getVertexCount()
    {
		return 0;
    }
    
    public String toString(){
		return null;
    }
    
     /**
     * Returns the polygon mode for the specified polygon size.
     * should not be set explicitly since it is set implicitly by MeshBuilder or MeshFactory 
     * @param drawMode The polygon Mode (GL_POINTS, GL_LINES, GL_TRIANGLES ,GL_TRIANGLE_STRIPS, GL_QUADS, GL_QUADSTRIPS)
   	*/
    public void setDrawMode(int drawMode){
		
    }
    
}