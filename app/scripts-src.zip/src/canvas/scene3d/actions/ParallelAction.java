package canvas.scene3d.actions;

import java.lang.reflect.Array;

import canvas.scene3d.Action3D;
import canvas.scene3d.SceneNode3D;

/** Executes a number of actions at the same time.
 * @author Nathan Sweet */
public class ParallelAction extends Action3D {
        

        public boolean act (float delta) {
    		return true;

        }

        public void restart () {
                
        }

        public void reset () {
        }

        public void addAction (Action3D action) {
        }

        public void setActor3d(SceneNode3D actor) {

        }

        public Array<Action3D> getActions () {
    		return null;
        }

        public String toString () {
    		return null;
        }
}