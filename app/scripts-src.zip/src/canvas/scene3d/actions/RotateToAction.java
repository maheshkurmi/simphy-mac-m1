package canvas.scene3d.actions;
/** Sets the actor's rotation from its current value to a specific value.
 * @author Nathan Sweet */
public class RotateToAction extends TemporalAction {
	

	public void setRotation(float yaw, float pitch, float roll) {
		
	}

	public float getYaw () {
		return 0;
	}

	public void setYaw (float yaw) {
		
	}

	public float getPitch () {
		return 0;
	}

	public void setPitch (float pitch) {
		
	}

	public float getRoll () {
		return 0;
	}

	public void setRoll (float roll) {
		
	}
}