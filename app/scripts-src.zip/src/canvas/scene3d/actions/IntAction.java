package canvas.scene3d.actions;
/** An action that has an int, whose value is transitioned over time.
 * @author Nathan Sweet */
public class IntAction extends TemporalAction {
       

        /** Gets the current int value. */
        public int getValue () {
                return 0;
        }

        /** Sets the current int value. */
        public void setValue (int value) {
                
        }

        public int getStart () {
                return 0;
        }

        /** Sets the value to transition from. */
        public void setStart (int start) {
                
        }

        public int getEnd () {
                return 0;
        }

        /** Sets the value to transition to. */
        public void setEnd (int end) {
                
        }
}