package canvas.scene3d.actions;
/** Base class for actions that transition over time using the percent complete since the last frame.
 * @author Nathan Sweet */
abstract public class RelativeTemporalAction extends TemporalAction {
        
}