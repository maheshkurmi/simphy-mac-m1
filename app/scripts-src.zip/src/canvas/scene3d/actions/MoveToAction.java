package canvas.scene3d.actions;

public class MoveToAction extends TemporalAction {
    
    
    public void setPosition (float x, float y, float z) {
    	
    
    }
            

    public float getX () {
            return 0;
    }

    public void setX (float x) {
           
    }

    public float getY () {
            return 0;
    }

    public void setY (float y) {
           
    }
    
    public float getZ () {
        return 0;
    }

    public void setZ (float z) {
        
    }
}