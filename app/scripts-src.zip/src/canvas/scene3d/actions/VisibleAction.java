package canvas.scene3d.actions;

import canvas.scene3d.Action3D;

/** Sets the actor's {@link Actor#setVisible(boolean) visibility}.
 * @author Nathan Sweet */
public class VisibleAction extends Action3D {
        
        public boolean act (float delta) {
                return true;
        }

        public boolean isVisible () {
                return true;
        }

        public void setVisible (boolean visible) {
                
        }
}