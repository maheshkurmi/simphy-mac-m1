package canvas.scene3d.actions;
/** Multiplies the delta of an action.
 * @author Nathan Sweet */
public class TimeScaleAction extends DelegateAction {
       
        
        public float getScale () {
             return 0;
        }

        public void setScale (float scale) {
               
        }
}