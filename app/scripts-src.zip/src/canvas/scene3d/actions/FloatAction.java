package canvas.scene3d.actions;
/** An action that has a float, whose value is transitioned over time.
 * @author Nathan Sweet */
public class FloatAction extends TemporalAction {
       

        

        /** Gets the current float value. */
        public float getValue () {
                return 0;
        }

        /** Sets the current float value. */
        public void setValue (float value) {
                
        }

        public float getStart () {
                return 0;
        }

        /** Sets the value to transition from. */
        public void setStart (float start) {
               
        }

        public float getEnd () {
                return 0;
        }

        /** Sets the value to transition to. */
        public void setEnd (float end) {
                
        }
}