package canvas.scene3d.actions;

import canvas.scene3d.Action3D;
import canvas.scene3d.SceneNode3D;

/** Base class for an action that wraps another action.
 * @author Nathan Sweet */
abstract public class DelegateAction extends Action3D {
       
        /** Sets the wrapped action. */
        public void setAction (Action3D action) {
                
        }

        public Action3D getAction () {
    		return null;
        }

        public final boolean act (float delta) {
    		return true;

        }

        public void restart () {

        }

        public void reset () {
                
        }

        public void setActor3d (SceneNode3D actor3d) {

        }

        public String toString () {
    		return null;
        }
}