package canvas.scene3d.actions;
/** Scales an actor's scale to a relative size.
 * @author Nathan Sweet */
public class ScaleByAction extends RelativeTemporalAction {

        public void setAmount (float x, float y, float z) {
                
        }

        public void setAmount (float scale) {
               
        }

        public float getAmountX () {
                return 0;
        }

        public void setAmountX (float x) {
                
        }

        public float getAmountY () {
                return 0;
        }

        public void setAmountY (float y) {
               
        }
        
        public float getAmountZ () {
            return 0;
        }

        public void setAmountZ (float z) {
            
        }

}