package canvas.scene3d.actions;

import canvas.scene3d.Action3D;

/** Removes an actor from the stage.
 *  */
public class RunFunctionAction extends Action3D {
	
	
	public void setCallback(ScriptFunction callback) {
		
	}
	
	public boolean act (float delta) {
		
		return true;
	}

	public void restart () {
		
	}
}
