package canvas.scene3d.actions;
/** Repeats an action a number of times or forever.
 * @author Nathan Sweet */
public class RepeatAction extends DelegateAction {
        static public final int FOREVER = -1;

       

        /** Causes the action to not repeat again. */
        public void finish () {
                
        }

        public void restart () {
               
        }

        /** Sets the number of times to repeat. Can be set to {@link #FOREVER}. */
        public void setCount (int count) {

        }

        public int getCount () {
                return 0;
        }
}