package canvas.scene3d.actions;

import canvas.scene3d.Action3D;
import canvas.scene3d.SceneNode3D;

/** Removes an actor from the stage.
 * @author Nathan Sweet */
public class RemoveActorAction extends Action3D {
        public boolean act (float delta) {
                return true;
        }

        public void restart () {

        }

        public void reset () {
               
        }

        public SceneNode3D getRemoveActor () {
    		return null;
        }

        /** Sets the actor to remove. If null (the default), the {@link #getActor() actor} will be used. */
        public void setRemoveActor (SceneNode3D removeActor) {

        }
}