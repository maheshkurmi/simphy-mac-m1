package canvas.scene3d.actions;
/** Moves an actor to a relative position.
 * @author Nathan Sweet */
public class AlphaByAction extends RelativeTemporalAction {
        
        public float getAlpha () {
    		return 0;
    	}

    	public void setAlpha (float alpha) {

    	}

		
}