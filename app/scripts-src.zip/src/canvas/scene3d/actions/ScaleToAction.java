package canvas.scene3d.actions;
/** Sets the actor's scale from its current value to a specific value.
 * @author Nathan Sweet */
public class ScaleToAction extends TemporalAction {
        

        public void setScale (float x, float y, float z) {
                
        }

        public void setScale (float scale) {
               
        }

        public float getX () {
                return 0;
        }

        public void setX (float x) {
               
        }

        public float getY () {
                return 0;
        }

        public void setY (float y) {
                
        }
        
        public float getZ () {
            return 0;
        }

        public void setZ (float z) {
           
        }
}