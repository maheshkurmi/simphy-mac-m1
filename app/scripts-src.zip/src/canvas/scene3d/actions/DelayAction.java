package canvas.scene3d.actions;
/** Delays execution of an action or inserts a pau
 * 
 * se in a {@link SequenceAction}.
 * @author Nathan Sweet */
public class DelayAction extends DelegateAction {
        



        /** Causes the delay to be complete. */
        public void finish () {
                
        }

        public void restart () {
               
        }

        /** Gets the time spent waiting for the delay. */
        public float getTime () {
                return 0;
        }

        /** Sets the time spent waiting for the delay. */
        public void setTime (float time) {
                
        }

        public float getDuration () {
                return 0;
        }

        /** Sets the length of the delay in seconds. */
        public void setDuration (float duration) {
               
        }
}