package canvas.scene3d.actions;

import canvas.scene3d.Action3D;

/** An action that runs a {@link Runnable}. Alternatively, the {@link #run()} method can be overridden instead of setting a
 * runnable.
 * @author Nathan Sweet */
public class RunnableAction extends Action3D {
        
        public boolean act (float delta) {
               
                return true;
        }

        /** Called to run the runnable. */
        public void run () {
                
        }

        public void restart () {
                
        }

        public void reset () {
               
        }

        public Runnable getRunnable () {
    		return null;
        }

        public void setRunnable (Runnable runnable) {
               
        }
}