package canvas.scene3d.actions;

import canvas.scene3d.SceneNode3D;

/** Executes an action only after all other actions on the actor at the time this action was added have finished.
 * @author Nathan Sweet */
public class AfterAction extends DelegateAction {
        
        public void setActor3d(SceneNode3D actor3d) {
             
        }

        public void restart () {
                
        }

        
}