package canvas.scene3d.actions;

/** Executes a number of actions one at a time.
 * @author Nathan Sweet */
public class SequenceAction extends ParallelAction {
       
        public boolean act (float delta) {
    		return true;
        }

        public void restart () {

        }
}