package canvas.scene3d.actions;

import canvas.scene3d.Action3D;

/**
 * Base class for actions that transition over time using the percent complete.
 * 
 * @author Nathan Sweet
 */
abstract public class TemporalAction extends Action3D {

	public boolean act(float delta) {
		return true;

	}

	/** Skips to the end of the transition. */
	public void finish() {
		
	}

	public void restart() {
		
	}

	public void reset() {

	}

	/** Gets the transition time so far. */
	public float getTime() {
		return 0;
	}

	/** Sets the transition time so far. */
	public void setTime(float time) {
		
	}

	public float getDuration() {
		return 0;
	}

	/** Sets the length of the transition in seconds. */
	public void setDuration(float duration) {
		
	}

	public String getInterpolation() {
		return null;
	}

	public void setInterpolation(Object interpolation) {
		
	}

	public boolean isReverse() {
		return true;
	}

	/** When true, the action's progress will go from 100% to 0%. */
	public void setReverse(boolean reverse) {
		
	}
}
