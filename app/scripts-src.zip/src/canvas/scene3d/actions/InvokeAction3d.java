package canvas.scene3d.actions;

import canvas.scene3d.Action3D;
import canvas.scene3d.SceneNode3D;

/** Invokes action on some actor, generally used along with sequence action
 *  */
public class InvokeAction3d extends Action3D {
	
	
	public boolean act (float delta) {
		
		return true;
	}

	public void setAction(Action3D targetAction, SceneNode3D targetActor) {
		
	}
	
	public void restart () {
		
	}
}
