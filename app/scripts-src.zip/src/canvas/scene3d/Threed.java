package canvas.scene3d;

import java.util.function.Function;

import script.Color;
import script.Vector3;

public class Threed {
	public  Curves Curves;
	public  Meshes Meshes;
	public Actions3D Actions;
	
	/**
	* Return instance of this singleton class
	 * @return
	 */
	public static Threed getInstance(){
		return null;
	}
	
	/**
	 * Creates Empty scene <br>
	 * Use {@link Scene3D#root} method of scene to add objects to it
	 * @return
	 * @see #Scene3D.getRoot()
	 */
	public Scene3D createScene() {
		return null;

	}

	/** Constructs a new PerspectiveCamera, with default values  Which are..
	 * 
	 * <pre>
	 * Focus = [0,0,0] 
	 * Eye   = [0,0,1] 
	 * Up    = [0,1,0]	
	 * fov   = 45 degree
	 * near  = 1
	 * far   = 100
	 * @see {@link Camera#setAsOrthographic(float, float, float, float)}
	 * @see {@link Camera#setAsPerspective(float, float, float, float)}
	 */
	public Camera createCamera() {
		return null;
	}

	/**
	 * Creates a new ambient light with the specified color and specified intensity
	 *
	 * @param color
	 *         The color of the light
	 * @param intensity
	 *         numeric value of the light's strength/intensity. Default is 1.
	 * @throws SimphyScriptException 
	 * @see {@link Light#setAsPointLight(Vector3)}
	 * @see {@link Light#setAsDirectionalLight(Vector3,Vector3)}
	 * @see {@link Light#setAsSpotLight(Vector3,Vector3,float,float)}
	 */
	public Light createLight(Color lightColor, float intensity)  {
		return null;
	}
	
	
	/**
	 * Creates material from specified style
	 * @param style {Object} Can be one of following<br>
	 * <ul>
	 * <li><b>Color :</b> Color Object or a String parsed as CSS color value. 
	 * <li><b>Css Color String :</b> Css color string , for example<br>
	 *            <ol>
	 *            <li>Common color name "red", "green"</li>
	 *            <li>Hexadecimal representation of color such as #FF0096 or
	 *            0xFF0096</li>
	 *            <li>Color functions
	 *            "rgb(255,0,0)","hsl(180, 50%, 50%)","rgba(255,255,120,1)"</li>
	 *            </ol>
	 * <li><b>Material Name</b> Name of material like "gold" "brass" "tin" etc</li>
	 * @return {Material}
	 * @see {@link Material#setAsLineMaterial(Color, float)}
	 * @see {@link Material#setAsPointMaterial(Color, float)}
	 * @see {@link Material#setAsFlatColorMaterial(Color)}
	 * @see {@link Material#setAsLightMaterial(Color, float)}
	 */
	public Material createMaterial(Object style){
		return null;
	}

	/**
	 * Creates New Empty Node, useful in creating groups and applying common Material, Light or Transforms
	 * @return Empty Node object
	 */
	public SceneNode3D createNode() {
		return null;
	}

	
	/**
	 * Loads Model from obj or 3ds file (must already be loaded in resource), <br.
	 * For multiple copies of model use {@link ModelNode#clone()} rather than calling this method again for same file
	 * @param source name of file resource
	 * @return
	 * @throws SimphyScriptException
	 */
	public ModelNode createModel(String source) {
		return null;
	}

	/**
	 * Creates new model from mesh
	 * @param mesh
	 * @param material material used to render mesh, if null material of parent node will be used
	 * @return
	 * @throws SimphyScriptException 
	 */
	public ModelNode createModel(Mesh mesh, Material material)  {
		return null;
	}

	/**
	 * Creates new model from curve
	 * @param meshes
	 * @param material material used to render mesh, if null material of parent node will be used
	 * @throws SimphyScriptException 
	 */
	public ModelNode createModel(Curve curve, Material material)  {
		return null;
	}
	
	/**
	 * Creates new Sprite for the image 
	 * @param {String} name of image
	 */
	public ModelNode createSprite(String imageName) {
		return null;
	}

	/**
	 * Creates An axis object to visualize the 3 axes in a simple way. 
	 * The X axis is red. The Y axis is green. The Z axis is blue.
	 * @return
	 */
	public ModelNode createAxes(float size){
		return null;
	}
	
	/**
	 * 
	 *Creates Vector field for given 3D expression
	 * @param function Function that accepts Vector 3 as argument and returns Vector3 as output
	 * bounds of VectorField are[xmin,xmax,ymin,ymax,zmin,zmax]
	 * @param xmin 
	 * @param xmax
	 * @param ymin
	 * @param ymax
	 * @param zmin
	 * @param zmax
	 * @param step step to crawl to create vector field 
	 * @return
	 */
	public VectorField createVectorField(Function<Vector3, Vector3> function,float xmin,float xmax, float ymin, float ymax, float zmin,float zmax, float step) {
		return null;
	}

}
