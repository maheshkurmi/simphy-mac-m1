package canvas.scene3d;

import canvas.Scene;
import script.Color;

public class Scene3D extends Scene{
	
	public static Camera testCamera;
	
	public SceneNode3D getRoot(){
		return null;
	}
	
	public void setRoot(SceneNode3D root){
		
	}
	
	public Camera getCamera(){
		return null;
	}

	public void setCamera(Camera camera){
		
	}
	
	
	/**Adds tracer attached to the node at its local center
	*@param node
	**/
	public Tracer addTracer(SceneNode3D node){
		return null;

	}
	
	/**
	 * Removes tracer from the scene
	 * @param tracer
	 */
	public void removeTracer(Tracer tracer){

	}
	
	/**
	 * Clears points on all tracers
	 */
	public void resetAllTracers(){

	}
	
	/**
	 * Removes all tracers from the scene
	 */
	public void removetAllTracers(){

	}
	
	/**
	 * Sets and Enabled Fog for the scene
	 * @param fogColor {Color} Color of fog (Default: Black)
	 * @param near {float} near distance from camera view point where fog starts (Default 0)
	 * @param far {float} far distance from camera view point where fog ends {Default 100)
	 * @param fogDensity {float} value that specifies density, the fog density used in non linear fog. Only nonnegative densities are accepted. The initial fog density is 1.
	 * @param isLinear {boolean} if true linear fog equation is used else exponential equation is used (default true)
	 * @see {@link Scene3D#setFogEnabled(boolean)}
	 */
	public void setFog(Color fogColor,float near, float far, float fogDensity, boolean isLinear){
		
	}
	/**
	 * Enabled fog for the scene
	 * @see {@link Scene3D#setFog(Color, float, float, float)
	 * @see {@link Scene3D#setFog(Color, float, float, float, boolean)}
	 */
	public void setFogEnabled(boolean fogEnabled){

	}
	
	/**
	 * Returns true if fog is enabled for the scene
	 * @return {boolean}
	 */
	public boolean isFogEnabled(){
		return true;
	}
	

	/**
	 * Returns the Model Node located at screen position (or the node under mouse)
	 * @param screenX
	 * @param screenY
	 * @return Model node under mouse if any else returns null
	 */
	 public ModelNode getNodeAt (int screenX, int screenY) {
			return null;
	   }

	 
	 
}
