package canvas.scene3d;

/**
 * A sprite is a plane that always faces towards the camera, generally with a partially transparent texture applied.
 * @author maheshkurmi
 */
public class Sprite extends ModelNode{
	
	
}
