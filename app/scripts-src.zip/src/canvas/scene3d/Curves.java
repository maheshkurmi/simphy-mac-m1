package canvas.scene3d;

import java.util.function.Function;

import canvas.Path2D;
import script.Vector3;

public class Curves {
	public static Curves instance=new Curves();
	
	
	/**
	* Return instance of this singleton class
	 * @return
	 */
	public static Curves getInstance(){
    	return null;

	}
	
	/**
	 * A curve representing a 2d line segment.
	 */
	public static class LineCurve extends Curve {
		
		public Vector3 getPointAt(float t, Vector3 resultVector) {
			return null;
		}

		public Vector3 getTangentAt(float t) {
			return null;
		}

		public LineCurve clone() {
			return null;

		}

	}

	/**
	 * A curve defined by paramter t (0<t<1)
	 */
	public static class ParametricCurve extends Curve {

		/**
		 * returns Point in 3d space corresponding to parameter t
		 * 
		 * @param t
		 *            value in [0,1]
		 * @param returnVector
		 *            Vector to which result should be copied
		 * @return null if point is undefined else returns point in 3d space
		 */
		public Vector3 getPointAt(float t, Vector3 returnVector) {
			return null;
		}

		public Vector3 getColorAt(float t) {
			return null;
		}
		
		public ParametricCurve clone() {
			return null;
		}

	}

	/** A smooth 3d spline curve from a series of points using the Catmull-Rom algorithm. */
	public static class SplineCurve extends Curve {
		
		public Vector3 getPointAt(float t, Vector3 resultVector) {
			return null;
		}
		
		public SplineCurve clone() {
			return null;
		}

	}

	/**
	 * A curve representing a continuous curve formed by connecting successive points
	 */
	public static class PolyLineCurve extends Curve {

		/**
		 * Adds point to the end of list
		 */
		public void addPoint(Vector3 pt) {

		}

		/**
		 * inserts point at specific index
		 * 
		 * @param pt
		 * @param index
		 */
		public void insertPoint(Vector3 pt, int index) {
			
		}

		/**
		 * removes point at specific index
		 * 
		 * @param index
		 */
		public void removePoint(Vector3 pt, int index) {
			
		}

		/**
		 * removes point at specific index
		 * 
		 * @param index
		 */
		public void updatePoint(Vector3 pt, int index) {
			
		}

		/**
		 * Returns copy of point at specified index
		 */
		public Vector3 getPoint(int index) {
			return null;
		}

		public Vector3 getPointAt(float t, Vector3 resultVector) {
			return null;
		}

		public Vector3 getTangentAt(float t) {
			
			return null;
		}

		public PolyLineCurve clone() {
			return null;
		}
	}

	/**
	 * A CurvePath is simply an array of connected curves, but retains the api of a curve.
	 * 
	 * @author maheshkurmi
	 */
	public static class CurvePath extends Curve {

		public void addCurve(Curve c) {
			
		}

		public void insertCurve(Curve c, int index) {
			
		}

		public void removeCurve(int index) {
			
		}

		public Vector3 getPointAt(float t, Vector3 resultVector) {
			
			return null;
		}

		public Vector3 getTangentAt(float t) {
			
			return null;
		}

		public CurvePath clone() {
			return null;

		}
			
	}
	
	/**
	 * Creates new Line Joining the vertices v1 and v2
	 * @param v1
	 * @param v2
	 * @return
	 */
	public Curve newLineCurve(Vector3 v1, Vector3 v2){
		return null;

	}

	
	/**
	 * Creates parametric curve for t ranging from 0 to 1
	 * 
	 * @param vertexFunction (must not be null)
	 *            Function that takes float as argument and returns {@link Vector3} corresponding to it
	 * @param colorFunction (can be null)
	 *            Function that takes float as argument and returns {@link Vector3} representing color at the vertex as r,g,b components each in [0,1] 
	 * @param segments
	 *		number of segments curve should be divided (more the segments more approximate is curve but slower is rendering)
	 */
	public Curve newParaMetricCurve(Function<Float, Vector3> vertexFunction,Function<Float, Vector3> colorFunction, int segments)  {
		return null;
	}

	/**
	 * Creates parametric curve for t ranging from 0 to 1
	 * 
	 * @param exprX
	 * @param exprY
	 * @param exprZ
	 * @param segments
	 *		number of segments curve should be divided (more the segments more approximate is curve but slower is rendering)
	 * @throws Exception
	 */
	public Curve newParaMetricCurve(String exprX, String exprY, String exprZ, int segments)  {
		return null;
	}

	/**
	 * Creates A smooth 3d spline curve from a series of points using the Catmull-Rom algorithm. 
	 * @param closed
	 *            The curve will loop back onto itself when this is true.
	 * @param tension
	 *           Tension of the curve (default 0.5f)
	 * @param curveType
	 *            Possible values are 0=catmullrom, 1=centripetal and 2=chordal
	 * @param pts
	 *            An array of Vector3 points
	 */
	public Curve newSplineCurve(boolean closed, float tension, int curveType, Vector3... pts) {
		return null;
	}
	
	/**
	 * Creates A curve representing a continuous curve formed by connecting successive points
	 * @param {Vector3[]} pts
	 */
	public Curve newPolyLineCurve(Vector3... pts)  {
		return null;
	}
		
	/**
	 * Creates Curve from Path2D object
	 * 
	 * @param path
	 *            non null Path2D object
	 * @param fineNess
	 *            maximum deviation from original curve
	 */
	public Curve newCurveFromPath2D(Path2D path, float fineNess){
		return null;
	}
}
