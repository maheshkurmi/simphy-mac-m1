package canvas.scene3d;

import org.omg.CORBA.Bounds;

import script.Color;
import script.Vector3;

public abstract class Curve {
	/**
	 * Creates copy of the curve, Note that it is shallow copy , the data is not copied
	 */
	public abstract Curve clone();
	
	 /**
     * Returns the material .
     * @return The material object
     */
    public Material getMaterial() {
    	return null;
}
    
    /**
     * Sets new material .
     * @param The material object
     */
    public void setMaterial(Material material){
    
    }
    
	/**
	 * Returns a vector for a given position on the curve.
	 * 
	 * @param t
	 *            - A position on the curve. Must be in the range [ 0, 1 ].
	 * @param resultVector
	 *            if not null the result will be copied into this Vector, otherwise a new Vector will be created.
	 */
	public abstract Vector3 getPointAt(float t, Vector3 resultVector);

	/**
	 * Returns color at position t 
	 * @param t
	 * @return
	 */
	public Vector3 getColorAt(float t){
		return null;
	}
	
	/**
	 * Returns a unit vector tangent at t In case any sub curve does not implement its tangent derivation, 2 points a
	 * small delta apart will be used to find its gradient which seems to give a reasonable approximation
	 * 
	 * @param t
	 *            (t in 0 to 1)
	 */
	public Vector3 getTangentAt(float t) {
    	return null;

	}

	/**
	 * Returns an array divisions + 1 points using {@link #getPointAt(float, Vector3)}
	 * 
	 * @param divisions
	 *            -- number of pieces to divide the curve into.
	 * @return
	 */
	public Vector3[] getPoints(int divisions) {
    	return null;

	}

	public Curve Copy() {
		return this;
	}
	
	/**
	 * Sets number of linear segments the curve should be broken for rendering
	 * @param segments
	 */
	public void setSegments(int segments){
		
	}
	
	
	
	/**
	 * Adds marker at specified position on the curve
	 * @param pos must be in [0,1]
	 * @param size must be >0
	 * @param type 0=sphere, 1=forwardArrow,2=backwardArrow,3=Cylinder, other=none
	 */
	public void addMarker(float pos, float size, int type){

	}
	
	/**
	 * Adds marker at specified position on the curve
	 * @param pos must be in [0,1]
	 * @param size must be >0
	 * @param type 0=sphere, 1=forwardArrow,2=backwardArrow,3=Cylinder, other=none
	 * @param text Text to be rendered at marker, can be null 
	 * @color color Color used to render marker, can be null if curve color is to be used
	 */
	public void addMarker(float pos, float size, int type,String text, Color color){
		
	}
	
	/**
	 * removes all marks from the curve
	 */
	public void removeAllMarkers(){

	}
	
	
	 /** 
     * Returns the bounds of the model 
     *
     * @return Bounds of the model 
     */
    public Bounds getBounds() {
    	return null;
    }
    
    public void setBounds(Bounds bounds) {

    }
 
	
}
