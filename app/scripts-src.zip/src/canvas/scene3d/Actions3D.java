package canvas.scene3d;

import canvas.scene3d.actions.AddAction;
import canvas.scene3d.actions.AfterAction;
import canvas.scene3d.actions.DelayAction;
import canvas.scene3d.actions.MoveByAction;
import canvas.scene3d.actions.MoveToAction;
import canvas.scene3d.actions.ParallelAction;
import canvas.scene3d.actions.RemoveAction;
import canvas.scene3d.actions.RemoveActorAction;
import canvas.scene3d.actions.RepeatAction;
import canvas.scene3d.actions.RotateByAction;
import canvas.scene3d.actions.RotateToAction;
import canvas.scene3d.actions.RunnableAction;
import canvas.scene3d.actions.ScaleByAction;
import canvas.scene3d.actions.ScaleToAction;
import canvas.scene3d.actions.SequenceAction;
import canvas.scene3d.actions.TimeScaleAction;
import canvas.scene3d.actions.VisibleAction;

public class Actions3D {
	/** Linear interpolation */
	public static final String linear= "linear" ;

	/**Slow then uniform then slow */
	public static final String fade= "fade" ;
	
	/** Quadratic interpolation */
	public static final String POW= "pow2" ;
	/** Fast, then slow quadratic interpolation */
	public static final String POW2IN = "pow2In";
	/** Slow, then falst quadratic interpolation  */
	public static final String pow2Out = "pow2Out";
	
	
	/** Cubic interpolation */
	public static final String pow3 ="pow3";
	/** Fast, then slow cubic interpolation */
	public static final String pow3In = "pow3In";
	/** Fast, then slow cubic interpolation */
	public static final String pow3Out = "pow3Out";

	/** exponential growth for half part and asymptotical growth for another half */
	public static final String exp5 = "exp5";
	/** exponential growt*/
	public static final String expIn = "exp5In";
	/**asymptotical growth*/
	public static final String expOut = "exp5Out";

	/**A simple elastic interaction, similar to a spring oscillating back and forth*/
	public static final String elastic = "elastic";
	/**Elastic in Interpolation*/
	public static final String elasticIn = "elasticIn";
	/**Elastic out Interpolation*/
	public static final String elasticOut = "elasticOut";

	/**Swing interploation in and out symmetrically*/
	public static final String swing = "swing";
	/**Swing In Interploation */ 
	public static final String swingIn = "swingIn";
	/**Swing Out Interploation*/ 
	public static final String swingOut = "swingOut";

	/**Bounce Interpolation in and out symmetrically*/
	public static final String bounce = "bounce";
	/**Bounce In Interpolation*/
	public static final String bounceIn = "bounceIn";
	/**Bounce Out Interpolation*/
	public static final String bounceOut = "bounceOut";

	/**Circular Interpolation in and out*/
	public static final String circle = "circle";
	/**Circular In Interpolation */
	public static final String circleIn = "circleIn";
	/**Circular Out Interpolation */
	public static final String circleOut = "circleOut";

	/**Sinusoidal Interpolation in and out symmetrically. (Sine interpolation from -90 to 90*/
	public static final String sine = "sine";
	
	/**Sinusoidal In Interpolation (Sine interpolation from -90 to 0)*/
	public static final String sineIn = "sineIn";
	
	/**Sinusoidal Out Interpolation in  (Sine interpolation from 0 to 90*/
	public static final String sineOut = "sineOut";
	
	/**
	 * Return instance of this singleton class
	 * 
	 * @return
	 */
	public static Actions3D getInstance() {
		return null;

	}

	/** Returns a new or pooled action of the specified type. */
	public static <T extends Action3D> T action3d(Class<T> type) {
		return null;

	}

	public AddAction addAction(Action3D action) {
		return null;

	}

	public AddAction addAction(Action3D action, SceneNode3D targetActor) {
		return null;

	}

	public RemoveAction removeAction(Action3D action) {
		return null;

	}

	public RemoveAction removeAction(Action3D action, SceneNode3D targetActor) {
		return null;

	}

	/** Moves the actor instantly. */
	public MoveToAction moveTo(float x, float y, float z) {
		return null;
	}

	public MoveToAction moveTo(float x, float y, float z, float duration) {
		return null;
	}
	 /**
	  * Moves actor to specified point in specified time
	  * @param x
	  * @param y
	  * @param Z
	  * @param duration
	  * @param interpolation String representing <a href="https://github.com/libgdx/libgdx/wiki/Interpolation">interpolation </a>ex "sine", "exp", "bounce" 
	  * @return
	  */
	public MoveToAction moveTo(float x, float y, float z, float duration, String interpolation) {
		return null;
	}

	/** Moves the actor instantly. */
	public MoveByAction moveBy(float amountX, float amountY, float amountZ) {
		return null;
	}

	public MoveByAction moveBy(float amountX, float amountY, float amountZ, float duration) {
		return null;
	}

	public MoveByAction moveBy(float amountX, float amountY, float amountZ, float duration,
			String interpolation) {
		return null;
	}

	/** Scales the actor instantly. */
	public ScaleToAction scaleTo(float x, float y, float z) {
		return scaleTo(x, y, z, 0, null);
	}

	public ScaleToAction scaleTo(float x, float y, float z, float duration) {
		return null;
	}

	public ScaleToAction scaleTo(float x, float y, float z, float duration, String interpolation) {
		return null;
	}

	/** Scales the actor instantly. */
	public ScaleByAction scaleBy(float amountX, float amountY, float amountZ) {
		return scaleBy(amountX, amountY, amountZ, 0, null);
	}

	public ScaleByAction scaleBy(float amountX, float amountY, float amountZ, float duration) {
		return null;
	}

	public ScaleByAction scaleBy(float amountX, float amountY, float amountZ, float duration,
			String interpolation) {
		return null;
	}

	/** Rotates the actor instantly. */
	public RotateToAction rotateTo(float yaw, float pitch, float roll) {
		return rotateTo(yaw, pitch, roll, 0, null);
	}

	public RotateToAction rotateTo(float yaw, float pitch, float roll, float duration) {
		return null;
	}

	public RotateToAction rotateTo(float yaw, float pitch, float roll, float duration, String interpolation) {
		return null;
	}

	/** Rotates the actor instantly. */
	public RotateByAction rotateBy(float yaw, float pitch, float roll) {
		return null;
	}

	public RotateByAction rotateBy(float yaw, float pitch, float roll, float duration) {
		return null;
	}

	public RotateByAction rotateBy(float yaw, float pitch, float roll, float duration, String interpolation) {
		return null;
	}

	public VisibleAction show() {
		return null;
	}

	public VisibleAction hide() {
		return null;
	}

	public VisibleAction visible(boolean visible) {
		return null;
	}

	public RemoveActorAction removeActor(SceneNode3D removeActor) {
		return null;
	}

	public DelayAction delay(float duration) {
		return null;
	}

	public DelayAction delay(float duration, Action3D delayedAction) {
		return null;
	}

	public TimeScaleAction timeScale(float scale, Action3D scaledAction) {
		return null;
	}

	public SequenceAction sequence(Action3D action1) {
		return null;
	}

	public SequenceAction sequence(Action3D action1, Action3D action2) {
		return null;
	}

	public SequenceAction sequence(Action3D action1, Action3D action2, Action3D action3) {
		return null;
	}

	public SequenceAction sequence(Action3D action1, Action3D action2, Action3D action3, Action3D action4) {
		return null;
	}

	public SequenceAction sequence(Action3D action1, Action3D action2, Action3D action3, Action3D action4,
			Action3D action5) {
		return null;
	}

	public SequenceAction sequence(Action3D... actions) {
		return null;
	}

	public SequenceAction sequence() {
		return null;
	}

	public ParallelAction parallel(Action3D action1) {
		return null;
	}

	public ParallelAction parallel(Action3D action1, Action3D action2) {
		return null;
	}

	public ParallelAction parallel(Action3D action1, Action3D action2, Action3D action3) {
		return null;
	}

	public ParallelAction parallel(Action3D action1, Action3D action2, Action3D action3, Action3D action4) {
		return null;

	}

	public ParallelAction parallel(Action3D action1, Action3D action2, Action3D action3, Action3D action4,
			Action3D action5) {
		return null;

	}

	public ParallelAction parallel(Action3D... actions) {
		return null;

	}

	public ParallelAction parallel() {
		return null;
	}

	public RepeatAction repeat(int count, Action3D repeatedAction) {
		return null;
	}

	public RepeatAction forever(Action3D repeatedAction) {
		return null;
	}

	public RunnableAction run(Runnable runnable) {
		return null;
	}

	public AfterAction after(Action3D action) {
		return null;
	}

}
