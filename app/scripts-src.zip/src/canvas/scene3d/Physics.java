
package canvas.scene3d;

import script.Vector3;

/**
 * Physics.
 *
 * @author Mahesh Kurmi
 */

public class Physics 
{
    
 
    /**
     * Returns the velocity.
     *
     * @return The velocity.
     */

    public Vector3 getVelocity()
    {
		return null;
    }

    /**
     * Sets the Linear velocity of center.
     * @param vel Vector with components as velocities long respective axes
     */
    public void setVelocity(Vector3 vel)
    {

    }

    /**
     * Returns the min velocity.
     *
     * @return The min velocity.
     */

    public Vector3 getMinVelocity()
    {
		return null;
    }

    /**
     * Sets the Minimum velocity along each direction.
     * @param minVel Vector with components as minimum linear velocities along respective axes
     */
    public void setMinVelocity(Vector3 minVel)
    {

    }

    /**
     * Returns the max velocity.
     *
     * @return The max velocity.
     */

    public Vector3 getMaxVelocity()
    {
		return null;
    }

    /**
     * Sets the Maximum velocity along each direction.
     * @param maxVel Vector with components as maximum linear velocities along respective axes
     */
    public void setMaxVelocity(Vector3 maxVel)
    {

    }
    /**
     * Returns the acceleration.
     *
     * @return The acceleration
     */

    public Vector3 getAcceleration()
    {
		return null;
    }

    /**
     * Sets the acceleration along each direction.
     * @param accc Vector with components as acceleration along respective axes
     */
    public void setAcceleration(Vector3 acc)
    {
       
    }

    /**
     * Returns the linear damping.
     *
     * @return The linear damping coefficient
     */

    public float getLinearDamping()
    {
		return 0;
    }

    /**
     * Sets the linear damping factor 
     * @param damping damping factor in (0 to 1)
     */
    public void setLinearDamping(float damping)
    {

    }

    /**
     * Returns the angular velocity.
     *
     * @return The angular velocity in rad/s.
     */

    public Vector3 getAngularVelocity()
    {
		return null;
    }


    /**
     * Sets the angular velocity along each direction.
     * @param angularVel Vector with components as angular velocity (in rad/s) about respective axes
     */
    public void setAngularVelocity(Vector3 angularVel)
    {

    }
    
    
    /**
     * Returns the min angular velocity.
     *
     * @return The min angular velocity (in rad/s).
     */

    public Vector3 getMinAngularVelocity()
    {
		return null;
    }

    /**
     * Sets the Minimum Angular velocity along each direction.
     * @param minAngularVel Vector with components as minimum angular velocities (in rad/s) about respective axes
     */
    public void setMinAngularVelocity(Vector3 minAngularVel)
    {

    }

    /**
     * Returns the max angular velocity.
     *
     * @return The max angular velocity (in rad/s).
     */

    public Vector3 getMaxAngularVelocity()
    {
		return null;
    }

    /**
     * Sets the Minimum Angular velocity along each direction.
     * @param maxAngularVel Vector with components as minimum angular velocities (in rad/s) about respective axes
     */
    public void setMaxAngularVelocity(Vector3 maxAngularVel)
    {

    }

    
    /**
     * Returns the angular acceleration.
     *
     * @return The angular acceleration.
     */

    public Vector3 getAngularAcceleration()
    {
		return null;
    }

    /**
     * Sets the angular acceleration along each direction.
     * @param angularAcc Vector with components as angular acceleration (in rad/s2) about respective axes
     */
    public void setAngularAcceleration(Vector3 angularAcc)
    {

    }
    
    
    /**
     * Returns the angular deceleration.
     *
     * @return The angular deceleration.
     */

    public float getAngularDamping()
    {
		return 0;
    }

    /**
     * Sets the angular damping factor 
     * @param damping damping factor in (0 to 1)
     */
    public void setAngularDamping(float damping)
    {

    }
    
    
    /**
     * Updates the angular physics.
     *
     * @param node
     *            The node to update
     * @param delta
     *            The time delta in seconds
     * @return True if the scene needs to be rendered again, false if not
     */

    public boolean updateAngular(final SceneNode3D node, final float delta)
    {
		return true;
    }


    /**
     * Updates the velocity physics.
     *
     * @param node
     *            The node to update
     * @param delta
     *            The time delta in seconds
     * @return True if the scene needs to be rendered again, false if not
     */

    public boolean updateVelocity(final SceneNode3D node, final float delta)
    {
		return true;
    }

    /**
     * Updates the specified node with this physics data.
     *
     * @param node
     *            The scene node to update
     * @param delta
     *            The time delta in seconds
     * @return True if the scene needs to be rendered again, false if not
     */
    protected boolean update(final SceneNode3D node, final float delta)
    {
        boolean changed = false;

        changed |= updateAngular(node, delta);
        changed |= updateVelocity(node, delta);
        return changed;
    }
    
}
