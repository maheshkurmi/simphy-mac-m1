package canvas;

import script.Color;

public  class Gradient extends FillPattern {
	public Gradient(double x0, double y0, double x1, double y1) {
	}

	public Color colorAt(float pos) {
		return null;
	}

	public void addColorStop(double pos, String col) {
	}

	/**
	 * AddColorStop adds a color stop to the gradient. The stops don't have to be added in order, they are sorted
	 * into the right place
	 * 
	 * @param pos
	 *            position between 0 to 1 (0 means starting color and 1 for end color)
	 * @param c
	 *            {Color}
	 */
	public void addColorStop(double pos, Color c) {
	}

}