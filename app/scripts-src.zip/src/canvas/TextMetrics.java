package canvas;
public class TextMetrics{
	/**width of text*/
	public double width=0;
	/**height of text*/
	public double height=0;
	/**distance by which bounding box of font is above base line*/
	public double actualBoundingBoxAscent=0;
	/**distance by which bounding box of font is below base line*/
	public double actualBoundingBoxDescent=0;
	
	public TextMetrics(double width, double ascent, double descent){
		this.width=width;
		this.height=ascent+descent;
		this.actualBoundingBoxAscent=ascent;
		this.actualBoundingBoxDescent=descent;
	}
}