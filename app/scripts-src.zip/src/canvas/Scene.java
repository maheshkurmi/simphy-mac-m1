package canvas;


/**
 * Scene can be 2D or 3D, both having default center at center of canvas but has coordinate system as  x:Right, y:Up and z: out of screen
 * @author mahesh
 *
 */
public abstract class Scene {

	/**Flag to enable debug mode in scene */
	public boolean debug=true;
	
	/** Various scaling types for fitting one rectangle into another. */
	public enum ViewPortMode {
		
	}
}
