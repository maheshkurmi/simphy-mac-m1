package canvas;

import script.Color;

/**
 * The ImageData object represents the underlying pixel data of an area of a canvas object. 
 * @author maheshkurmi
 *
 */
public class ImageData {
	
	/**
	 * create a new ImageData object with the same dimensions as the object specified by anotherImageData. The new object's pixels are all preset to transparent black. 
	 * <b>This does not copy the image data!</b>
	 * @param imageData
	 */
	public ImageData(ImageData imageData){
	}
	
	/**
	 * This creates a new ImageData object with the specified dimensions. All pixels are preset to transparent black (all zeroes i.e rgba(0,0,0,0)).
	 * @param width
	 * @param height
	 */
	public ImageData(int width, int height){
	}
	
	/**
	 * Returns pixel Color at specified position
	 * @param row
	 * @param col
	 * @return {Color} 
	 */
	public Color getPixel(int row, int col) {
		return null;
	}
	
	/**
	 * Sets pixel color at specified position
	 * @param row Row Position , must be in [0, height-1]
	 * @param column Column position must be in [0, width-1]
	 * @param color Color to put
	 */
	public void setPixel(int row, int column,Color color) {
		
	}
	
	/**
	 * returns the height of the image in pixels.
	 * @return {Nmumber}
	 */
	public int getHeight(){
		return 0;
	}
	
	/**
	 * returns the width of the image in pixels.
	 * @return {Nmumber}
	 */
	public int getWidth(){
		return 0;
	}
	
	/**
	 * Returns true if this data is filled with buffer
	 * @return
	 */
	public boolean isFilled() {
		return false;
	}
	
	
}
