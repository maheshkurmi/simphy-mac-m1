package canvas;



public abstract class FillPattern {

	

}
