package canvas;

public class MouseEvent {
	
	public void set(int x, int y, int button,int clickCount, int id, boolean shiftdown, boolean controldown,int wheeldelta) {
		
	}
	
	public int id;
	/**button pressed 1=left, 2=middle, 3=right	 */
	public int button = 0;
	
	public int clickCount;
	/**coordinates of the mouse pointer in canvas coordinates.*/
	public double x,y;
	
	public boolean altKey;
	public boolean ctrlKey;
	public boolean shiftKey;
	public int wheelDelta;
	public int which;
	public boolean consumed=false;
	
	public void preventDefault(){
	}
}
