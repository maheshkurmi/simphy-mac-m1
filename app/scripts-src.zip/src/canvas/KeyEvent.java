package canvas;

public class KeyEvent {
	
	public void set(char keychar, int keycode, int id, boolean shiftdown, boolean controldown) {
		
	}
	public String key;
	public int id;

	/**
	 * a Number representing a system and implementation dependent numerical code identifying the unmodified value of
	 * the pressed key.
	 */
	public int keyCode;
	/**the character value of the key.*/
	public char keyChar;
	
	public boolean altKey;
	public boolean ctrlKey;
	public boolean shiftKey;
	/** Returns a Boolean that is true if the key is being held down such that it is automatically repeating. */
	public boolean repeat;
	public int which;
	public boolean consumed=false;
	
	public void preventDefault(){
		
	}
}
