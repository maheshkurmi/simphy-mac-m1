package widgets;

/**
 * Wrapper Widget for [slider, Progressbar, SpinBox]
 * @author mahesh
 *
 */
public class Slider extends ProgressBar{

	
	
	@Override
	public void setStep(double step){
		
	}
	
	@Override
	public double getStep(){
		return 0;
	}
	
	/**
	 * Sets the distance of the value change when using page buttons (page up and page down).
	 * @param block
	 */
	public void setBlock(double block){
		
	}
	
	/**
	 * Sets the distance of the value change when using page buttons (page up and page down).
	 * @return
	 */
	public double getBlock(){
		return 0;
	}
	
	/**
	 * Text displayed by widget 
	 * [text may contain 'name', 'value', 'min' and 'max' as placeholders  which are placed by corresponding values on display]
	 * Ex. text="name=value"
	 * @param text
	 */
	@Override
	public void setText(String text){
		
	}


	/**
	 * Sets the interval in seconds between 2 successive ticks of slider
	 * @param block
	 * @see #setAnimMode(String)
	 */
	public void setAnimInterval(double animinterval){
		
	}
	
	/**
	 * Sets the interval in seconds between 2 successive ticks of slider
	 * @return
	 */
	public double getAnimInterval(){
		return 0;
	}
	
	/**
	 * Sets the animation mode of slider (default is "none"). When animation mode is other than 'none' slider
	 * changes its value based on mode and animinerval 
	 * @param animode {String} "none"|"increasing"|"decreasing"|"increasing-once"|"deccreasing-once"|"oscillating" 
	 * @see #setAnimMode(String)
	 */
	public void setAnimMode(String animmode){
		
	}
	
	/**Returns the animation mode of slider
	 * @return {String}
	 */
	public String getAnimMode(){
		return null;
	}
	
}
