package widgets;

/**
 * Widget wrapper for label, button, cell(table), choice(combo) ,menuItem
 * @author mahesh
 *
 */
public class Dialog extends Panel{

	

	/**set icon of widget
	 *@param icon{String} Name of Icon 
	 * */
	public void setIcon(String icon){
		
	}
	
	/**
	 * returns name of icon if set else null
	 * @return
	 */
	public String getIcon(){
		return null;
	}

	/**
	 * Sets title text of the dialog
	 * @param text
	 */
	public void setText(String text){
		
	}
	/**
	 * Returns title text of dialog
	 * @return
	 */
	public String getText(){
		return "";
	}
	
	/**
	 * Sets dialog as modal or non modal.
	 * A modal dialog grabs all the input to the components behind the dialog from the user.
	 * @param modal
	 */
	public void setModal(boolean modal){
		
	}
	
	/**
	 * Returns true of dialog is modal 
	 * A modal dialog grabs all the input to the components behind the dialog from the user.
	 * @return
	 */
	public boolean isModal(){
		return false;
	}
	
	
	/**
	 * Set whether the dialog can be resized.
	 * @param resizable
	 */
	public void setResizable(boolean resizable){
		
	}
	
	/**
	 * returns whether the dialog can be resized.
	 * @return
	 */
	public boolean isResizable(){
		return false;
	}
	
	/**
	 * Set whether the dialog can be closed by a close button. if set true  close button is added to its title bar
	 * @param closable
	 * @see #setOnClose(String)
	 */
	public void setClosable(boolean closable){
		
	}
	
	/**
	 * returns whether the dialog can be closed by a button.
	 * @return
	 */
	public boolean isClosable(){
		return false;
	}
	
	/**
	 * Set whether the dialog can be maximized by a button.
	 * @param maximizable
	 */
	public void setMaximizable(boolean maximizable){
		
	}
	/**
	 * returns whether the dialog can be maximized by a button.
	 * @return
	 */
	public boolean isMaximizable(){
		return false;
	}
	
	/**
	 * Set whether the dialog can be iconified by a button.
	 * @param iconifiable
	 */
	public void isIconifiable(boolean iconifiable){
		
	}
	/**
	 * returns whether the dialog can be iconified by a button.
	 * @return
	 */
	public boolean setIconifiable(){
		return false;
	}
	
   	/**
	 * Sets method to be invoked when dialog's close utton is pressed <br>
	 * @param methodText {String} method in specific format as <strong> MethodName(parameters) </strong>
	 * <h3>MathodName:</h3> Name of Global method already defined in script
	 * <h3>parameters:</h3> The event description may contain parameters (in brackets, separated by comma or whitespace characters) as follows:
	 * <ul>
	 * <li> <b> this </b> =The source widget (the object on which the event occurred)
	 * <li> <b> widget name </b> =Another widget in gui identified by the given name
	 * <li> <b> item </b> =The component part on which the event occurred, valid for list item, tree node, table row, combobox choice, and tabbedpane tab
	 * <li> <b> this/name/item .attribute </b> =component's or item's attribute value, defined by the this, widget name, or item string, dot, and the attribute key. 
			Ex. <code> onSelectionChange(this, item.text, this.value) </code>
	 * <li> <b> constant string </b> =The source widget (the object on which the event occurred)
	 * <li> <b> constant value </b> =The source widget (the object on which the event occurred)
	 * <li> <b> constant number </b> =Long numbers end with 'L' character (it ignors case), floats width 'F', doubles have to include a dot character, otherwise it is expected as integer.	 * </ul>
	 * 
	 * <b>Note:</b> To avoid closing dialog simply return true in method (useful for closing dialog based on condition)
	 */
	public void setOnClose(String methodText){
	}
 
	/**
	 * Returns method text associated with 'action' for this widget
	 * @return Method Text if assigned else null
	 */
	public String getOnClose(){
		return null;
	}
}
