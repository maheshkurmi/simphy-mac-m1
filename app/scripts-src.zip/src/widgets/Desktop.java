package widgets;

/**
 * Widget wrapper for Desktop
 * @author mahesh
 *
 */
public class Desktop extends ContainerWidget{

	
	  /**
     * set background image of desktop
     * @param icon
     */
    public void setBackgroundImage(String icon){
		
	}
	
	/**
     * return background image of widget
     * @return
     */
	public String getBackgroundImage(){
		return null;
	}
}
