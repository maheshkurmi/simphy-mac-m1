package widgets;

/**
 * Wrapper Widget for [slider, Progressbar, SpinBox]
 * @author mahesh
 *
 */
public class ProgressBar extends Widget implements Actionable{


	
	/**
	 * minimum value of widget
	 * @param min {Double} by default 0
	 */
	public void setMinimum(double min){
		
	}
	
	
	public double getMinimum(){
		return 0;
	}

	/**
	 * Maximum value
	 * @param max {double} by default 100
	 */
	public void setMaximum(double max){
		
	}

	public double getMaximum(){
		return 0;
	}

	/**
	 * The value is always between the minimum and maximum values, inclusive. By default, the value equals the minimum.
	 * @param value {double}
	 */
	public void setValue(double value){
		
	}
	
	/**
	 * returns current value of this widget
	 * @param value {double}
	 * @return
	 */
	public double getValue(){
		return 0;
	}
	
	/**
	 * The distance of the value change when using arrow buttons.
	 * @param step
	 */
	public void setStep(double step){
		
	}
	
	/**
	 * The distance of the value change when using arrow buttons.
	 * @return
	 */
	public double getStep(){
		return 0;
	}
	
	/**
	 * Text displayed by widget 
	 * @param text
	 */
	public void setText(String text){
		
	}
	
	/**
	 * returns current text
	 * @return
	 */
	public String getText(){
		return null;
	}
	
	/**
	 * Sets orientation of widget
	 * Possible values are: horizontal, and vertical. The default value, if not set, is horizontal.
	 * @param orientation {String} horizontal|vertical
	 */
	public void setOrientation(String orientation){
		
	}
	
	
	/**
	 * returns orientation of widget
	 */
	public String getOrientation(){
		return null;
	}
	
	

	/**
	 * Sets method to be invoked whenever value of widges changes <br>
	 * @param methodText {String} method in specific format as <strong> MethodName(parameters) </strong>
	 * <h3>MathodName:</h3> Name of Global method already defined in script
	 * <h3>parameters:</h3> The event description may contain parameters (in brackets, separated by comma or whitespace characters) as follows:
	 * <ul>
	 * <li> <b> this </b> =The source widget (the object on which the event occurred)
	 * <li> <b> widget name </b> =Another widget in gui identified by the given name
	 * <li> <b> item </b> =The component part on which the event occurred, valid for list item, tree node, table row, combobox choice, and tabbedpane tab
	 * <li> <b> this/name/item .attribute </b> =component's or item's attribute value, defined by the this, widget name, or item string, dot, and the attribute key. 
			Ex. <code> onSelectionChange(this, item.text, this.value) </code>
	 * <li> <b> constant string </b> =The source widget (the object on which the event occurred)
	 * <li> <b> constant value </b> =The source widget (the object on which the event occurred)
	 * <li> <b> constant number </b> =Long numbers end with 'L' character (it ignors case), floats width 'F', doubles have to include a dot character, otherwise it is expected as integer.	 * </ul>
	 */

	public void setAction(String methodText) {
	}

	@Override
	public String getAction() {
		return null;
	}


}
