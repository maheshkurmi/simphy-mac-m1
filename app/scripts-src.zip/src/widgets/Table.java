package widgets;

/**
 * A table presents data in a two-dimensional table format, allows to select rows, has header, and internally handles scrolling.
 * Table contains data in row and each row can contain one or more cells
 * table may also contain columns which have additional properties like sort, resizable etc
 * If table has columns defined then the maximum number of visible cells in row are restricted to number of columns
 * @author mahesh
 *
 */
public class Table extends Widget implements Actionable{


	/**
	 * 
	 * @param columnName
	 * @return
	 */
	public ItemWidget addColumn(String columnName){
		return addColumn(columnName,false,0);
	}
	
	/**
	 * 
	 * @param columnName
	 * @param sortable 	
	 * @param preferredWidth
	 * @return
	 */
	public ItemWidget addColumn(String columnName,boolean sortable,int preferredWidth){
		return null;
	}
	

	/**
	 * The preferred width of the column. 
	 * The last (rightmost) column always extends to fill in the remaining width of the table, as determined by the parent container.
	 * @param width
	 */
	public void setColumnWidth(int colIndex,int width){
		
	}

	/**
	 * Returns the preferred width of the column. 
	 */
	public int getColumnWidth(int colIndex,int width){
		return 0;
	}
	/**
	 * If present, and set to either "ascent" or "descent", an arrow is drawn near right end of the column, as a visual indication of sorting order. 
	 * NOTE: for now this is just a visual decoration, application still needs to do the sorting.
	 * @param colIndex index of column to be sorted
	 * @param sortable if true column entries are sortable
	 */
	public void setColumnSortable(int colIndex,boolean sortable){

	}
	
	
	/**
	 * returns true if columns in table can be manually resized by drag
	 */
	public boolean isColumnSortable(int colIndex){
		return false;
	}
	
	/**
	 * sets columns in table (if exist) manually resizable by drag
	 * @see 
	 */
	public void setColumnsResizable(boolean resizable){
	
	}
	
	
	
	/**
	 * returns true if columns in table can be manually resized by drag
	 */
	public boolean isColumnsResizable(){
		return false;
	}
	
	/**
	 * Return number of columns in table in its header
	 * If table does't contain header it returns zero irrespective of actual number of columns in individual rows
	 * @return
	 */
	public int getColumnCount(){
		return 0;
	}
	
	/*
	/**
	 * Returns column at specified index
	 * @param index
	 * @return column Widget which can be used to change appearance of column
	 */
	public ItemWidget getColumn(int index){
		return null;
	}
	
	/**
	 * Returns column at specified index
	 * @param index
	 * @return column Widget which can be used to change appearance of column
	 */
	public ItemWidget[] getColumns(){
		return null;
	}
	
	/**
	 * Removes Columns at specified index from the table
	 * Note that on removing column, data in rows remain unaltered although some cell may become non visible on removing column
	 * @param index
	 */
	public void removeColumn(int index){
		return;
	}
	
	/**
	 * Removes all the items from this list. 
	 */
	public void removeAll(){
		
	}
	/**
	 * Return number of columns in table in its header
	 * If table does't contain header it returns zero irrespective of actual number of columns in individual rows
	 * @return
	 */
	public int getRowCount(){
		return 0;
	}
	
	
	/**
	 * get row widget at specified index
	 * @param index
	 * @return row Widget which can be used to change appearance of row
	 * @see #getItem(int, int)
	 */
	private ItemWidget getRow(int index){
		return null;
	}
	
	/*
	 * return array of rows in this table
	 * @return
	public SelectableItemWidget[] getRows(){
		int count=1;
		Object header = gui.getWidget(component, "header");
		if(header==null){
			count= 0;
		}
		Object[] rows=Gui.getItems(component);
		if(rows==null ||rows.length==count){
			rows=new Object[0];
			return new SelectableItemWidget[0];
		}
		SelectableItemWidget[] r=new SelectableItemWidget[rows.length-count];
		for(int i=count;i<rows.length;i++){
			r[i]=new SelectableItemWidget(gui, rows[i]);
		}
		return r;

	}
	*/
	
	/**
	 * Removes Row at specified index from the table
	 * @param index
	 */
	public void removeRow(int index){
		return;
	}
	
	
	/**
	 * returns cell at specified index
	 * @param colIndex
	 * @param rowIndex
	 * @return
	 */
	public ItemWidget getItemAt(int colIndex, int rowIndex ){
		return null;
	}
	
	/**
	 * returns cell at specified index
	 * @param colIndex
	 * @param rowIndex
	 * @return
	 */
	public Object getValueAt(int colIndex, int rowIndex ){
		return null;
	}
	
	/**
	 * creates new row
	 * Add items added after call to {@link #row()} are added to this row
	 * To add items to new row call it again
	 * @see addItem
	 */
	public void row(){
		
	}
	
	/**
 	 * Adds the item to the the table in current row
 	 * <pre>
 	 * <b>example to create table with three rows with some empty cells</b>
 	 *    var table=gui.createTable();
 	 *    table.row()
 	 *    table.addItem("row1-col1");
 	 *    table.addItem("row2-col2");
 	 *    table.row();
 	 *    table.addItem("row2-col1");
 	 *    table.row();
 	 *    table.addItem("row3-col1");
 	 * </pre>
  	 * @param value toString() method of value is used to display item in table
 	 * @return added item
 	 * @see #row()
 	 */
	public ItemWidget addItem(Object value){
		return null;
	}
 	/**
 	 * Adds the item to the the table in current row
 	 * <pre>
 	 * <b>example to create table with three rows with some empty cells</b>
 	 *    var table=gui.createTable();
 	 *    table.row()
 	 *    table.addItem("row1-col1");
 	 *    table.addItem("row2-col2");
 	 *    table.row();
 	 *    table.addItem("row2-col1");
 	 *    table.row();
 	 *    table.addItem("row3-col1");
 	 * </pre>
   	 * @param value toString() method of value is used to display ite on table
 	 * @param icon
 	 * @return added item cell
 	 * @see #row()
 	 */
	public ItemWidget addItem(Object value,String icon){
		return null;
	}
	

	
	
  	/**
	 * Sets selection mode of list
	 * The default single value allows to select one list item at a time, the interval value to select one contiguous range of items, 
	 * and the multiple value to select one or more contiguous ranges of items.
	 * @param multiSelect single|interval|multiple
	 */
	public void setSelectionMode(String multiSelect){
		
	}
	
	/**
	 * Returns selection mode of the list
	 * @return
	 */
	public String getSelectionMode(){
		return null;
	}
	
	/**
	 * Sets if lines are drawn separating the list items.
	 * @param lines {Boolean} separator lines are drawn if true
	 */
	public void setDrawSeparatorLines(boolean lines){
		return ;
	}
	
	/**
	 * return if lines are drawn separating the list items.
	 */
	public boolean isDrawSeparatorLines(){
		return true;
 	}
	
	/**
	 * Sets method to be invoked when table is double clicked <br>
	 * @param methodText {String} method in specific format as <strong> MethodName(parameters) </strong>
	 * <h3>MathodName:</h3> Name of Global method already defined in script
	 * <h3>parameters:</h3> The event description may contain parameters (in brackets, separated by comma or whitespace characters) as follows:
	 * <ul>
	 * <li> <b> this </b> =The source widget (the object on which the event occurred)
	 * <li> <b> widget name </b> =Another widget in gui identified by the given name
	 * <li> <b> item </b> =The component part on which the event occurred, valid for list item, tree node, table row, combobox choice, and tabbedpane tab
	 * <li> <b> this/name/item .attribute </b> =component's or item's attribute value, defined by the this, widget name, or item string, dot, and the attribute key. 
			Ex. <code> onSelectionChange(this, item.text, this.value) </code>
	 * <li> <b> constant string </b> =The source widget (the object on which the event occurred)
	 * <li> <b> constant value </b> =The source widget (the object on which the event occurred)
	 * <li> <b> constant number </b> =Long numbers end with 'L' character (it ignors case), floats width 'F', doubles have to include a dot character, otherwise it is expected as integer.	 * </ul>
	 */
	public void setOnPerform(String methodText){
		
	}
 
	/**
	 * Returns method text associated with 'action' for this widget
	 * @return Method Text if assigned else null
	 */
	public String getOnPerform(){
		return null;
	}
	
	/**
	 * Sets method to be invoked whenever selection is changedin table <br>
	 * @param methodText {String} method in specific format as <strong> MethodName(parameters) </strong>
	 * <h3>MathodName:</h3> Name of Global method already defined in script
	 * <h3>parameters:</h3> The event description may contain parameters (in brackets, separated by comma or whitespace characters) as follows:
	 * <ul>
	 * <li> <b> this </b> =The source widget (the object on which the event occurred)
	 * <li> <b> widget name </b> =Another widget in gui identified by the given name
	 * <li> <b> item </b> =The component part on which the event occurred, valid for list item, tree node, table row, combobox choice, and tabbedpane tab
	 * <li> <b> this/name/item .attribute </b> =component's or item's attribute value, defined by the this, widget name, or item string, dot, and the attribute key. 
			Ex. <code> onSelectionChange(this, item.text, this.value) </code>
	 * <li> <b> constant string </b> =The source widget (the object on which the event occurred)
	 * <li> <b> constant value </b> =The source widget (the object on which the event occurred)
	 * <li> <b> constant number </b> =Long numbers end with 'L' character (it ignors case), floats width 'F', doubles have to include a dot character, otherwise it is expected as integer.	 * </ul>
	 */
	public void setAction(String methodText) {
	}

	@Override
	public String getAction() {
		return null;
	}

}
