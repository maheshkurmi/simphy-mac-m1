package widgets;

/**
 * Widget for ListBox, ComboBox, Menu and Popup
 * @author mahesh
 *
 */
  public class ComboBox extends TextField{
    	
    	/**
    	 * Adds item to the list at its end
    	 * @param text Text displayed
    	 */
    	public ItemWidget addItem(String text){
    		return addItem(text,null);
    	}
    	
    	/**
    	 * Adds item to the list at its end
    	 * @param text
    	 * @param icon
    	 */
     	public ItemWidget addItem(String text,String icon){
    		return addItem(text,icon,-1);
    	}
    	
     	/**
     	 * Adds the specified item to the the scrolling list at the position indicated by the index. The index is zero-based.
     	 * If the value of the index is less than zero, or if the value of the index is greater than or equal to the number of items in the list, then the item is added to the end of the list.
     	 * @param text
     	 * @param icon
     	 * @param index
     	 * @return
     	 */
    	public ItemWidget addItem(String text,String icon, int index){
    		return null;
    	}
    	
      	
    	/**
    	 * Removes the item, specified by index, from this list. 
    	 * @param index {Number} the index of the item to be removed
    	 */
    	public void removeItem(int index) throws ArrayIndexOutOfBoundsException{
    		
    	}
    		
    	/**
    	 * Removes all the items from this list. 
    	 */
    	public void removeAll(){
    		
    	}
    	

    	/**
         * Gets the number of items in this list.
         * @return   
         * @see       #getItem
         */
        public int getItemCount() {
            return 0;
        }
        
      	  /**
         * Gets the nth item in this list.
         * @param      n   the index of the item to get.
         * @return     the n<sup>th</sup> item in this container.
         * @exception  ArrayIndexOutOfBoundsException
         *                 if the n<sup>th</sup> value does not exist.
         * @see #getItemCount()
         */
        public ItemWidget getItem(int n) {
        	return null;
        }
        
        /**
         * Gets the index of the first selected item in this list
         * @param n
         * @return
         */
        public int getSelectedIndex() {
        	return 0;
        }
        
        /**
         * Gets the index of the first selected item in this list
         * @param n
         * @return
         */
        public void setSelectedIndex(int index) {
        	
        }
        
        /**
         * Gets the first selected item in this list
         * @return selected item widget
         */
        public ItemWidget getSelectedItem() {
        	return null;
         }
        
           
         /**
         * Gets all the items in this list.
         * @return    an array of all the components in this container.
         * @see #getComponent(int)
         */
        public Widget[] getAllItems() {
        	return null;
        }
        
    
    	
    
    }
