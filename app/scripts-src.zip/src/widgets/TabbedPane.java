package widgets;
  
/**
 * TabbedPane contains tabs and components. The first tab (has an index equal to 0) is associated with the first component.
 * @author mahesh
  */
public class TabbedPane extends Widget{
    	

    	 /**
         * Returns the currently selected index for this tabbedpane.
         * Returns -1 if there is no currently selected tab.
         *
         * @return the index of the selected tab
         * @see #setSelectedIndex
         */
       	public int getSelectedIndex(){
       		return 0;
    	}
    	
        /**
         * Sets the selected index for this tabbedpane. The index must be
         * a valid tab index 
         * @param index  the index to be selected
         * @exception IndexOutOfBoundsException if index is out of range
         *            {@code (index < -1 || index >= tab count)}
         * @return active tab index (0 corresponds to first tab, 1 corresponds to secos tab and so on..)
    	 */
    	public void setSelectedIndex(int index){
    		
    	}
    	
    	/**
    	 * returns number of tabs currently added to this widget
    	 * @return
    	 */
    	public int getTabCount(){
    		return 0;
    	}
    	
    
   	 	/**
         * Adds a <code>component</code> and <code>tip</code>
         * represented by a <code>title</code> and/or <code>icon</code>,
         * either of which can be <code>null</code>.
         * Cover method for <code>insertTab</code>.
         *
         * @param title the title to be displayed in this tab
         * @param icon the icon to be displayed in this tab
         * @param Widget the component to be displayed when this tab is clicked
         * @param tip the tooltip to be displayed for this tab
         *
         * @see #insertTab
         * @see #removeTabAt
         */
        public ItemWidget addTab(String title, String icon, Widget component, String tooltip, int index) {
        	return null;
        }
        
    	 /**
         * Adds a <code>component</code> and <code>tip</code>
         * represented by a <code>title</code> and/or <code>icon</code>,
         * either of which can be <code>null</code>.
         * Cover method for <code>insertTab</code>.
         *
         * @param title the title to be displayed in this tab
         * @param icon the icon to be displayed in this tab
         * @param Widget the component to be displayed when this tab is clicked
         * @param tip the tooltip to be displayed for this tab
         *
         * @see #insertTab
         * @see #removeTabAt
         */
        public ItemWidget addTab(String title, String icon, Widget component, String tooltip) {
        	return null;
        }

        /**
         * Adds a <code>component</code> represented by a <code>title</code>
         * and/or <code>icon</code>, either of which can be <code>null</code>.
         * Cover method for <code>insertTab</code>.
         *
         * @param title the title to be displayed in this tab
         * @param icon the icon to be displayed in this tab
         * @param Widget the component to be displayed when this tab is clicked
         *
         * @see #insertTab
         * @see #removeTabAt
         */
        public ItemWidget addTab(String title, String icon, Widget component) {
        	return null;
        }

        /**
         * Adds a <code>component</code> represented by a <code>title</code>
         * and no icon.
         * Cover method for <code>insertTab</code>.
         *
         * @param title the title to be displayed in this tab
         * @param component the component to be displayed when this tab is clicked
         *
         * @see #insertTab
         * @see #removeTabAt
         */
        public ItemWidget addTab(String title, Widget component) {
        	return null;
        }


        /**
         * Removes the tab at <code>index</code>.
         * After the component associated with <code>index</code> is removed,
         * @param index the index of the tab to be removed
         * @exception IndexOutOfBoundsException if index is out of range
         *            {@code (index < 0 || index >= tab count)}
         * @see #addTab
         * @see #insertTab
         */
        public void removeTabAt(int index) {

        }
        
        
       	/**
    	 * Removes all the tabs from this tabbedpane. 
    	 */
    	public void removeAll(){
    		
    	}
    	
    	
    	 /**
         * Returns the placement of the tabs for this tabbedpane.
         * @see #setTabPlacement
         */
        public String getTabPlacement() {
        	return null;
        }

        /**
         * Sets the tab placement for this tabbedpane.
         * Possible values are:<ul>
         * <li><code>'top'</code>
         * <li><code>'bottom'</code>
         * <li><code>'left'</code>
         * <li><code>'right'</code>
         * <li><code>'stacked'</code>
         * </ul>
         * The default value, if not set, is <code>'top'</code>.
         *
         * @param tabPlacement the placement for the tabs relative to the content
         * @exception IllegalArgumentException if tab placement value isn't one
         */
        public void setTabPlacement(String tabPlacement) {
            
        }

        /**
         * Sets Title of the tab at specified index
         * @param index must be between  and tabCount-1
         * @param title {String} title to be displayed at tab
         */
    	public void setTitleAt(int index,String title){
    		

    	}
    	
    	 /**
         * Sets icon of the tab at specified index
         * @param index must be between  and tabCount-1
         * @param icon {String} title to be displayed at tab
         */
    	public void setIconAt(int index,String icon){
    		
    	}

    	 /**
         * Replaces the component of tab at specified index
         * @param index must be between  and tabCount-1
         * @param component {Widget} new component to be added to tab
         */
    	public void setWidgetAt(int index,Widget component){
    		
    	}
    	
    	/**
    	 * Returns title of tab at specified index
    	 * @param index must be between 0 and tabcount-1
    	 * @return
    	 */
    	public String getTitleAt(int index){
    		return null;
    	}
    	
    	/**
    	 * Returns icon of tab at specified index
    	 * @param index must be between 0 and tabcount-1
    	 * @return
    	 */
    	public String getIconAt(int index){
    		return null;
    	}
    	
    	/**
    	 * Returns component of tab at specified index
    	 * @param index must be between 0 and tabcount-1
    	 * @return component {Widget} widget on tab if index is valid else null
    	 */
    	public Widget getWidgetAt(int index){
    		return null;
    	}
    	
    
    	

    }
