package widgets;

/**
 * Widget wrapper for label, button, cell(table), choice(combo) ,menuItem
 * @author mahesh
 *
 */
public class ItemWidget extends Widget{

	
	/**set icon of widget
	 *@param icon{String} Name of Icon 
	 * */
	public void setIcon(String icon){
		
	}
	
	/**
	 * returns name of icon if set else null
	 * @return
	 */
	public String getIcon(){
		return null;
	}

	/**
	 * The alignment of the label's content along the X axis, vertically is centered. Possible values are: left, center, and right. The default value, if not set, is left. 
	 * The image position horizontally left, above, and right relative to the text.
	 * @param alignment left|center|right
	 */
	public void setAlignment(String alignment){
	}
	
	/**
	 * returns horizontal alignemnet of text and icon
	 * @return
	 */
	public String getAlignment(){
		return  "";
	}

	/**
	 * Sets text displayed on item
	 * @param text
	 */
	public void setText(String text){
		
	}
	
	/**
	 * returns text displayed on item
	 * @return
	 */
	public String getText(){
		return "";
	}
}
