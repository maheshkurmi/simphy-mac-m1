package widgets;

import script.Color;

/**
 * Wrapper class for gui widgets, Widgets in actual gui are accessed through this wrapper object in scripting
 * @author mahesh
 *
 */
public  class Widget {
	

	/**
	 * Returns type of widget (ex 'button', 'slider', 'textfield' etc)
	 * @return
	 */
	public String getWidgetType(){
		return null;
	}
	
	/**
	 * Returns name of the widget used as identifier 
	 * @return
	 */
	public String getName(){
		return null;
	}
	
	@Override
	public boolean equals(Object obj){
		
		return false;
	}
	
	@Override
	public String toString(){
		return null;
	}
	

	/**
	 * Sets Attribute for this widget
	 * Please refer allowed attribute in the documentation
	 * @param attribute
	 * @param value
	 */
	public void setAttribute(String attribute,Object value){
		
	}
	
	/**
	 * Returns current value of the attribute for this widget
	 * @param attribute
	 * @return
	 */
	public Object getAttribute(String attribute){
		return null;
	}
	
	/**
	 * Sets widget enabled or disabled. Disabled widget no longer respond to mouse of keyboard events
	 * @param enabled
	 */
	public void setEnabled(Boolean enabled){
		return ;
	}

	/**
	 * returns true if widget is enabled and thus can receive mouse and keyboard events
	 * @return
	 */
	public boolean isEnabled(){
		return false;
	}
	
	/**
	 * Hides of shows widget, invisible visits are neither drawn nor receive any mouse or keyboard events
	 * @param visible
	 */
	public void setVisible(Boolean visible){
		return ;
	}

	/**
	 * returns true of widget is visible
	 * @return
	 */
	public boolean isVisible(){
		return true;
	}
	

	/**
	 * Sets Foreground Color of the widget (pass null to use theme default)
	 * @param color {Color|String} Color Object or css color string  ex.<br>
	 * 	<ol> 
	 * 	<li> Common color name "red", "green" </li>
	 *	<li> Hexadecimal representation of color such as #FF0096 or 0xFF0096 </li>
	 * 	<li> Color functions "rgb(255,0,0)","hsl(180, 50%, 50%)","rgba(255,255,120,1)" </li>
	 * </ol>
	 * @throws IllegalArgumentException if color is null or invalid
	 */
	public void setForeground(Color color){
		
	}
	
	/**
	 * Sets fore ground color of widget
     * @param r the red component  in the range (0.0 - 1.0).  
	 * @param g the green component  in the range (0.0 - 1.0).  
	 * @param b the blue component  in the range (0.0 - 1.0).  
	 * @param a the alpha component  in the range (0.0 - 1.0).  
	 */
	public void setForeground(float r, float g,float b,float a){
		
	}
	
	
	/**
	 * Returns foreground color used to render widget
	 * @return {Color} color as string in hex format
	 */
	public Color getForeground(){
		return null;
	}
	

	/**
	 * Sets Fill Color of the widget (pass null to use theme default)
	 * @param color {Color|String} Color Object or css color string  ex.<br>
	 * 	<ol> 
	 * 	<li> Common color name "red", "green" </li>
	 *	<li> Hexadecimal representation of color such as #FF0096 or 0xFF0096 </li>
	 * 	<li> Color functions "rgb(255,0,0)","hsl(180, 50%, 50%)","rgba(255,255,120,1)" </li>
	 * </ol>
	 * @throws IllegalArgumentException if color is null or invalid
	 */
	public void setBackground(Color color){
		
	}
	
	/**
	 * Sets background color of widget
     * @param r the red component  in the range (0.0 - 1.0).  
	 * @param g the green component  in the range (0.0 - 1.0).  
	 * @param b the blue component  in the range (0.0 - 1.0).  
	 * @param a the alpha component  in the range (0.0 - 1.0).  
	 */
	public void setBackground(float r, float g,float b,float a){
		
	}
	
	/**
	 * Returns background color used to render widget
	 * @return {Color} color as string in hex format
	 */
	public Color getBackground(){
		return null;
	}
	
	 /**
     * set background image of widget
     * @param imageName {String] name of background  image     */
    public void setBackgroundImage(String imageName){
	}
	
	/**
     * return Name of background image of widget
     * @return {String}
     */
	public String getBackgroundImage(){
		return null;
	}
	
	
	/**
	 * Sets the text that pops up when the mouse lingers inside the component.
	 * @param tooltip {String} text to be shown as tooltip
	 */
	public void setToolTip(String tooltip){
		
	}
	
	/**
	 * Returns the text that pops up when the mouse lingers inside the component.
	 */
	public String getToolTip(){
		return "";
	}
	
	/**
	 * sets font used to render text for the widget
	 * @param fontName {Sting} Name of font used to render text for the widget (note that font must already be loaded)
	 */
	public void setFont(String fontName){
			
	}
	
	/**
	 * returns font for the widget
	 * @return
	 */
	public String getFont(){
		return null;
	}

	/**
	 * Sets preferred width and height of widget, 
	 * Note that actual size may differ based on layout although preferred size is taken in account while doing layout
	 * @param width {Number} Width in pixels (if set as 0 widgets width is calculated based on its content and children)
	 * @param height {Number} Height in pixels (if set as 0 widgets height is calculated based on its content and children)
	 */
	public void setPreferredSize(int width,int height){
		
	}
	
	/**
	 * Fixed preferred width of the component irrespectively of its content. If it is 0, the component will be asked for the preferred width.
	 * @return
	 */
	public int getPreferredWidth(){
		return 0;
	}
	
	/**
	 * Fixed preferred height of the component irrespectively of its content. If it is 0, the component will be asked for the preferred height.
	 * @return
	 */
	public int getPreferredHeight(){
		return 0;
	}
	
	/**
	 * Specifies the number of cells in a row occupied by the component.
	 * @param rowspan
	 */
	public void setRowspan(int rowspan){
		
	}
	
	/**
	 * Specifies the number of cells in a column in the component's display area.
	 * @param rowspan
	 */
	public void setColspan(int colspan){
		
	}
	
	/**
	 * Used to determine how to distribute horizontal space among grid cells when more space is available for its parent component than required.
	 * @param rowspan
	 */
	public void setWeightX(int weightx){
		
	}
	
	
	/**
	 * The extra vertical space is distributed to each cell height in proportion to its weight. Default value is 0. The row contains 0 weighted components remains the calculated preferred size.
	 * @param rowspan
	 */
	public void setWeightY(int weighty){
		
	}
	
	
	/**
	 * Horizontal alignment of the component when more space available in the cell. Possible values are: fill, center, left, and right.
	 * @param halign {String} fill|center|left|right.
	 */
	public void setHalign(String halign){
	}
	
	/**
	 * The extra vertical space is distributed to each cell height in proportion to its weight. Default value is 0. The row contains 0 weighted components remains the calculated preferred size.
	 * @param valign {String} fill|center|top|bottom.
	 */
	public void setValign(String valign){
	}
	
	
	/**
	 * Binds an arbitrary key/value client property (or properties).
	 * set null as property value to remove property
	 * @param key
	 * @param value
	 */
	public void setProperty(String key,Object value){
		
	}
	
	/**
	 * returns property value for the specified key
	 * @param key
	 */
	public Object getProperty(String key){
		return null;
	}
	
	/**
	 * Requests focus on this widget, Having the focus means that you are the element that key events get handed to.
	 */
	public void requestFocus(){
	}
	
 	/**
	 * Sets method to be invoked when a Invoked when a component gains the keyboard focus, thus it is now the focus owner.<br>
	 * @param methodText {String} method in specific format as <strong> MethodName(parameters) </strong>
	 * <h3>MathodName:</h3> Name of Global method already defined in script
	 * <h3>parameters:</h3> The event description may contain parameters (in brackets, separated by comma or whitespace characters) as follows:
	 * <ul>
	 * <li> <b> this </b> =The source widget (the object on which the event occurred)
	 * <li> <b> widget name </b> =Another widget in gui identified by the given name
	 * <li> <b> item </b> =The component part on which the event occurred, valid for list item, tree node, table row, combobox choice, and tabbedpane tab
	 * <li> <b> this/name/item .attribute </b> =component's or item's attribute value, defined by the this, widget name, or item string, dot, and the attribute key. 
			Ex. <code> onSelectionChange(this, item.text, this.value) </code>
	 * <li> <b> constant string </b> =The source widget (the object on which the event occurred)
	 * <li> <b> constant value </b> =The source widget (the object on which the event occurred)
	 * <li> <b> constant number </b> =Long numbers end with 'L' character (it ignors case), floats width 'F', doubles have to include a dot character, otherwise it is expected as integer.	 * </ul>
	 */
	public void setOnFocus(String methodText){
	}
 
	/**
	 * Returns method text associated with 'focusgained' event for this widget
	 * 
	 * @return Method Text if assigned else null
	 */
	public String getOnFocus() {
		return null;
	}
	
 	/**
	 * Sets method to be invoked when a component loses the keyboard focus, thus it is no longer the focus owner.<br>
	 * @param methodText {String} method in specific format as <strong> MethodName(parameters) </strong>
	 * <h3>MathodName:</h3> Name of Global method already defined in script
	 * <h3>parameters:</h3> The event description may contain parameters (in brackets, separated by comma or whitespace characters) as follows:
	 * <ul>
	 * <li> <b> this </b> =The source widget (the object on which the event occurred)
	 * <li> <b> widget name </b> =Another widget in gui identified by the given name
	 * <li> <b> item </b> =The component part on which the event occurred, valid for list item, tree node, table row, combobox choice, and tabbedpane tab
	 * <li> <b> this/name/item .attribute </b> =component's or item's attribute value, defined by the this, widget name, or item string, dot, and the attribute key. 
			Ex. <code> onSelectionChange(this, item.text, this.value) </code>
	 * <li> <b> constant string </b> =The source widget (the object on which the event occurred)
	 * <li> <b> constant value </b> =The source widget (the object on which the event occurred)
	 * <li> <b> constant number </b> =Long numbers end with 'L' character (it ignors case), floats width 'F', doubles have to include a dot character, otherwise it is expected as integer.	 * </ul>
	 */
	public void setOnBlur(String methodText){
	}
 
	/**
	 * Returns method text associated with 'onblur' event for this widget
	 * 
	 * @return Method Text if assigned else null
	 */
	public String getOnBlur() {
		return null;
	}
	
}
