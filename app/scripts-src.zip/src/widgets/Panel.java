	package widgets;

/**
 * Widget for ListBox, ComboBox, Menu and Popup
 * @author mahesh
 *
 */
  public class Panel extends ContainerWidget{
    	
    	 /**
         * Returns the number of available cells in a row. 
         * Default 0 value specifies 1 row and unlimited cell columns.
         * @param columns must be >=0
         */
        public void setColumns(int columns) {
        	
        }
        
        /**
         * sets the blank space around the widget
         */
        public void setPadding(int top,int left,int bottom,int right) {
        	
        }
        
        /**
         * The horizontal and vertical gap between child components.
         * @param gap
         */
        public void setGaps(int gap){
        	
        }
        
        
        /**
         * Border painted if true.
         * @param border
         */
        public void setBorder(boolean border) {
        	
        }
        
        /**
         * If present and set to true, add scrollbars to the panel if its contents is bigger than the panel's bounds.
         * @param scollabel
         */
        public void setScrollable(boolean scrollable) {
        	
        }

        /**
         * set background image of widget
         * @param icon
         */
        public void setBackgroundImage(String icon){
    		
    	}
    	
        /**
         * return background image of widget
         * @return
         */
    	public String getBackgroundImage(){
    		return null;
    	}
    }
