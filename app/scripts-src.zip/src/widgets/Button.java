package widgets;

/**
 * Widget wrapper for button 
 * 
 * @author mahesh
 *
 */
public class Button extends ActionItemWidget {



	/**
	 * Set type of appearance button has
	 * Possible values are: normal, default, cancel, and link. The default value is normal. Default, and cancel values are for dialog control. 
	 * Link changes the appearance of button so that it resembles HTML link.
	 * @param type {String} normal|default|cancel|link
	 */
	public void setType(String type){
		
	}
	
	/**
	 * returns type of button normal|default|cancel|link
	 * @return
	 */
	public String getType(){
		return "";
	}
	

}
