package script;

import canvas.Canvas;
import canvas.Transform;

public class World {
	/**
	 * Import all bodies as script variables identified by name of the body
	 * Bodies with invalid javascript Name are discarded
	 */
	public void importAllBodies(){
	}
	
	/**
	 * Import world bodies as script variables identified by name of the body
	 * Bodies with invalid javascript Name are discarded
	 * @param {String[] } array of names of bodies
	 * @ 
	 */
	public void importBodies(String... bodyNames) {
	}
	
	/**
	 * Import all joints as script variables identified by name of the joint
	 * joints with invalid javascript Name are discarded
	 */
	public void importAllJoints(){
	}
	
	/**
	 * Import world joints as script variables identified by name of the joint
	 * Joints with invalid javascript Name are discarded
	 * {String[] } array of name of joints
	 * @ 
	 */
	public void importJoints(String... jointNames) {
	}
	
		
	/**
	 * Clears all Dynamically generated objects  by script
	 */
	public void clear(){
	}
	
	/**
	 * Clears all bodies and joints (created manually or via script) in the simulation
	 */
	public void clearAll(){
	}
	
	/**
	 * returns body recognized by its names
	 * @param {String}name Name of body in as in tree view/properties
	 * @return {Body} body if exists with this name else null
	 * @ 
	 */
	public Body getBody(String name) {
		return null;
	}
	
	/**
	 * returns joint recognized by its names
	 * @param {String}name Name of Joint in as in tree view/properties
	 * @return {Joint}joint if exists with this name else null
	 * @ 
	 */
	public Joint getJoint(String name) {
		return null;
	}
	
	/**
	 * Creates an empty group of bodies,bodies can be added to the group using {@link COMBody#addBody(Body)}
	 * @return {COMBody} created Group
	 */
	public COMBody createGroup(){
		return null;
	}
	
	/**
	 * Removes the group from simulation, bodies in the group are not removed
	 * @param {COMBody} group
	 */
	public void removeGroup(COMBody group){
	}
	/**
	 * adds {@link Body} to the simulation
	 * @param  body {Body}
	 */
	public void addBody(Body body){

	}
	
	/**
	 * removes a body from the simulation
	 * @param {Body} body
	 */
	public void removeBody(Body body){
	}
	/**
	 * Removes joint from the simulation
	 * @param {Joint} joint
	 */
	public void removeJoint(Joint joint){
	}

	/**
	 * adds {@link Joint} to the simulation
	 * @param jt
	 */
	public void addJoint(Joint jt){
	}
	
	/**
	 * Creates copy of {@link Body}  and adds it to world
	 * @param {Body} body
	 * @return {Body} copy of body
	 */
	public Body createCopy(Body body){
		return null;
	}


	/**
	 * Adds disc {@link Body}  to the world
	 * @param radius
	 * @return {Body}added body
	 * @ 
	 */
	public Body addDisc(double radius) {
		return null;
	}
	
	/**
	 * Adds rectangle {@link Body}  to the world
	 * @param {Number} width
	 * @param {Number} height
	 * @return {Body} added body
	 * @ 
	 */
	public Body addRectangle(double width,double height) {
		return null;
	}
	
	/**
	 * Creates polygonal {@link Body} to the simulation 
	 * @param vertices Array of {@link Vector2}
	 * @return created body
	 * @throws SimphyScriptException
	 */
	public Body addPolygon(Vector2[] vertices) {
		return null;
	}


	
	/**
	 * adds {@link SpringJoint} between bodies
	 * @param body1 {Body} first body, Pass <code>null</code> to add anchor point to world
	 * @param body2 {Body} second body, Pass <code>null</code>  to add anchor point to world
	 * @param p1 {Vector2} first anchor point in world coordinates , Pass <code>null</code>  to add to center of mass of body
	 * @param p2 {Vector2} second anchor point in world coordinates , Pass <code>null</code>  to add to center of mass of body
	 * @param k {Number} Force constant of spring in N/m , must be (>0)
	 * @param b {Number} damping coefficient as per equation <code>Force=kx-bv</code>, must be >=0
	 * @return {SpringJoint} added joint with natural length set as distance between anchor points
	 */
	public SpringJoint addSpringJoint(Body body1,Body body2,Vector2 p1, Vector2 p2,double k,double b) {
		return null;
	}
	
	/**
	 * adds {@link DistanceJoint} between bodies 
 	 * @param body1 {Body} first body, Pass <code>null</code> to add anchor point to
	 *              world
	 * @param body2 {Body} second body, Pass <code>null</code> to add anchor point
	 *              to world
	 * @param p1    {Vector2} first anchor point in world coordinates , Pass
	 *              <code>null</code> to add to center of mass of body
	 * @param p2    {Vector2} second anchor point in world coordinates , Pass
	 *              <code>null</code> to add to center of mass of body
	 * @return {DistanceJoint} added joint with natural length set as distance
	 *         between anchor points
	 * @see DistanceJoint#setFrequency(double)
	 */
	public DistanceJoint addDistanceJoint(Body body1,Body body2,Vector2 p1, Vector2 p2) {
		return null;
	}
	
	/**
	 * adds {@link RopeJoint} between bodies
	 * @param body1 {Body} first body, Pass <code>null</code> to add anchor point to world
	 * @param body2 {Body} second body, Pass <code>null</code>  to add anchor point to world
	 * @param p1 {Vector2} first anchor point in world coordinates , Pass <code>null</code>  to add to center of mass of body
	 * @param p2 {Vector2} second anchor point in world coordinates , Pass <code>null</code>  to add to center of mass of body
	 * @return {RopeJoint} added joint with natural length set as distance between anchor points
	 */
	public RopeJoint addRopeJoint(Body body1,Body body2,Vector2 p1, Vector2 p2) {
		return null;
	}
	
	/**
	 * Adds {@link RevoluteJoint} (hinge) 
	 * @param body1 {Body} first body, Pass <code>null</code> to add anchor point to
	 *              world
	 * @param body2 {Body} second body, Pass <code>null</code> to add anchor point
	 *              to world
	 * @param p     {Vector2} the anchor point in world coordinates , must not be
	 *              <code>null</code>
	 * @return {RevoluteJoint} added joint
	 */
	public Joint addRevoluteJoint(Body body1,Body body2,Vector2 v){
		return null;
	}
	
	/**
	 * adds {@link PrismaticJoint} between bodies 
	 * @param body1  {Body} first body, Pass <code>null</code> to add anchor point
	 *               to world
	 * @param body2  {Body} second body, Pass <code>null</code> to add anchor point
	 *               to world
	 * @param anchor {Vector2} first anchor point in world coordinates , must not be
	 *               <code>null</code>
	 * @param axis   {Vector2} the axis of allowed motion in world space, must not
	 *               be <code>null</code>
	 * @return {PrismaticJoint} added joint
	 */
	public PrismaticJoint addPrismaticJoint(Body body1,Body body2,Vector2 anchor, Vector2 axis) {
		return null;
	}
	
	/**
	 * adds {@link WheelJoint} between bodies 
	 * @param body1  {Body} first body, Pass <code>null</code> to add anchor point
	 *               to world
	 * @param body2  {Body} second body, Pass <code>null</code> to add anchor point
	 *               to world
	 * @param anchor {Vector2} first anchor point in world coordinates , must not be
	 *               <code>null</code>
	 * @param axis   {Vector2} the axis of allowed motion in world space, must not
	 *               be <code>null</code>
	 * @return {WheelJoint} added joint
	 */
	public WheelJoint addWheelJoint(Body body1,Body body2,Vector2 anchor, Vector2 axis) {
		return null;
	}
	
	/**
	 * adds {@link WeldJoint} between bodies 
	 * @param body1 {Body} first body, Pass <code>null</code> to add anchor point to
	 *              world
	 * @param body2 {Body} second body, Pass <code>null</code> to add anchor point
	 *              to world
	 * @param p     {Vector2} anchor point in world coordinates , Pass
	 *              <code>null</code> to add to center of mass of body
	 * @return {WeldJoint} added joint
	 */
	public WeldJoint addWeldJoint(Body body1,Body body2,Vector2 p) {
		return null;
	}
	
	/**
	 * adds {@link PulleyJoint} between bodies
	 * @param body1        {Body} first body, Pass <code>null</code> to add anchor
	 *                     point to world
	 * @param body2        {Body} second body, Pass <code>null</code> to add anchor
	 *                     point to world
	 * @param pullyAnchor1 {Vector2} the first pulley anchor point, must not be
	 *                     <code>null</code>
	 * @param pullyAnchor2 {Vector2} the first pulley anchor point, must not be
	 *                     <code>null</code>
	 * @param bodyAnchor1  {Vector2} the first Body's anchor point , Pass
	 *                     <code>null</code> to add to center of mass of body
	 * @param bodyAnchor2  {Vector2} the second Body's anchor point , Pass
	 *                     <code>null</code> to add to center of mass of body
	 * @return {PulleyJoint} added joint with natural length set as sum of distance between anchor points
	 */
	public PulleyJoint addPulleyJoint(Body body1,Body body2,Vector2 pullyAnchor1, Vector2 pullyAnchor2,Vector2 bodyAnchor1, Vector2 bodyAnchor2) {
		return null;
	}
	
	/**
	 * adds {@link SpindleJoint} between bodies
	 * @param body1        {Body} first body, Pass <code>null</code> to add anchor
	 *                     point to world
	 * @param body2        {Body} second body, Pass <code>null</code> to add anchor
	 *                     point to world
	 * @param pullyAnchor1 {Vector2} the first Body's anchor point , Pass
	 *                     <code>null</code> to add to center of mass of body
	 * @param pullyAnchor2 {Vector2} the second Body's anchor point , Pass
	 *                     <code>null</code> to add to center of mass of body
	 * @return {SpindleJoint} added joint
	 */
	public SpindleJoint addSpindleJoint(Body body1,Body body2,Vector2 p1, Vector2 p2) {
		return null;
	}
	
	/**
	 * adds  {@link MotorJoint} between bodies
	 * 
	 * @param body1 {Body} first body, Pass <code>null</code> to add anchor point to
	 *              world
	 * @param body2 {Body} second body, Pass <code>null</code> to add anchor point
	 *              to world
	 * @return {MotorJoint} added joint
	 */
	public MotorJoint addMotorJoint(Body body1,Body body2) {
		return null;
	}
	
	
	/**
	 * adds {@link AngleJoint} between bodies
	 * @param body1 {Body} first body, Pass <code>null</code> to add anchor point to
	 *              world
	 * @param body2 {Body} second body, Pass <code>null</code> to add anchor point
	 *              to world
	 * @return {AngleJoint} added joint
	 * @see {@link AngleJoint#setLimits(double, double)}
	 * @see {@link AngleJoint#setLimitEnabled(boolean)}
	 */
	public AngleJoint addAngleJoint(Body body1,Body body2,Vector2 p1, Vector2 p2) {
		return null;
	}
	
	/**
	 * Adds  {@link FrictionJoint} between bodies
	 * @param body1 {Body} first body, Pass <code>null</code> to add anchor point to world
	 * @param body2 {Body} second body, Pass <code>null</code>  to add anchor point to world
	 * @param p {Vector2} the anchor point , must not be <code>null</code> 
	 * @return {FrictionJoint} added joint 
	 */
	public FrictionJoint addFrictionJoint(Body body1,Body body2,Vector2 p) {
		return null;
	}
	
	/**
	 * Adds  {@link PinJoint} to the Body.
	 * @param body   {Body} the body to attach the joint to, must not be <code>null</code> 
	 * @param anchor {Vector2} the anchor point in world coordinates , Pass <code>null</code> to add to center of mass of body
	 * @param frequency {Number} the oscillation frequency in hz (must be >0)
	 * @param dampingRatio {Number}  the damping ratio in [0,1]
	 * @param maximumForce {Number} the maximum force this constraint can apply in newtons
	 * @return {PinJoint} added joint
	 * @see {@link PinJoint#setTarget(Vector2)}
	 */
	public PinJoint addPinJoint(Body body,Vector2 anchor, double frequency, double dampingRatio, double maximumForce) {
		return null;
	}
	

	/**
	 * Sets gravity for simulation (in m/s2)
	 * @param {Number}x x-component of gravity
	 * @param {Number}y y-component of gravity
	 */
	public void setGravity(double x, double y){
	}
	
	/**
	 * returns gravity {@link Vector} for simulation (in m/s2)
	 * @return Vector2
	 */
	public Vector2 getGravity(){
		return null;
	}
	
	/**
	 * returns electric field {@link Vector}  at a point
	 * @param {Vector2} pt Point in world coordinates
	 * @return {Vector2}
	 */
	public Vector2 getElectricFieldAt(Vector2 pt){
		return null;
	}
	
	/**
	 * returns magnetic field intensity at a point in Tesla
	 * @param {Vector2} pt Point in world coordinates
	 * @return {Number}
	 */
	public double getMagneticFieldAt(Vector2 pt){
		return 0;
	}
	
	/**
	 * Returns Electric potential due to charges at a point
	 * @param pt  {Vector2} pt Point in world coordinates
	 * @return Potential in Volts
	 */
	public double getElectricPotentialAt(Vector2 pt){
		return 0;
	}
		
	/**
	 * returns {@link Body} located at a point
	 * @param {Vector2} pt Point in world coordinates
	 * @return {Body} returns null if no body s found at the point
	 */
	public Body getBodyAt(Vector2 pt){
		return null;
	}
	
	/**
	 * Attaches camera to the body, now the body will behave as world origin and camera will follow it
	 * @param {Body}body
	 * @param {boolean} allowRotation if true then camera axis rotates with rotation of body
	 */
	public void setCameraBody(Body body,boolean allowRotation){
	}
	
	/**
	 * Returns {@link WorldCamera} Object for the simulation
	 * @return
	 */
	public WorldCamera getCamera(){
		return null;
	}
	
	/**
	 * returns  vector (velocity, force etc) as seen in camera frame
	 * @param {Vector2} v vector in ground frame
	 * @return {Vector2}
	 */
	public Vector2 getVectorInCameraFrame(Vector2 v){
		return null;
	}

	/**
	 * returns  point/position  in camera reference frame
	 * @param {Vector2}v point/position in ground frame
	 * @return{Vector2} Vector2
	 */
	public Vector2 getPointInCameraFrame(Vector2 v){
		return null;
	}
	
	/**
	 * returns  vector (velocity, force etc) in ground frame
	 * @param v vector in camera frame
	 * @return Vector2
	 */
	public Vector2 getVectorInGroundFrame(Vector2 v){
		return null;
	}

	/**
	 * returns  point/position  in in ground frame
	 * @param  {Vector2}v point/position in camera frame
	 * @return {Vector2}Vector2
	 */
	public Vector2 getPointInGroundFrame(Vector2 v){
		return null;
	}
	
	
	/**
	 * Returns body if exists, to which the camera is following, else returns null
	 * @param {Body}body
	 */
	public static Body getCameraBody() {
		return null;
	}

	
	/**
	 * returns time elapsed in seconds (instantaneous time) since the beginning of simulation
	 * @return{String}
	 */
	public double getSimulationTime(){
		return 0;
	}
	
	/**
	 * returns body controller by name
	 * @param name
	 * @return
	 */
	public AbstractBodyController getController(String name){
		return null;
	}
	
	/**
	 * removes body controller from simulation
	 * @param c
	 */
	public void removeController(AbstractBodyController c){
	}
	
	/**
	 * returns field from name 
	 * @param {String} name of field
	 */
	public Field getField(String name){
		return null;
	}
	

	/**
	 * removes field from simulation
	 * @param c
	 */
	public void removeField(Field field){
	}
	

	/**
	 * Adds trajectory {@link Tracer} to a body
	 * @param {Body} body 
	 * @param {Vector2} localPt Point in local coordinates of body (if null then used COM of body)
	 * @param returns added tracer
	 */
	public Tracer addTracer(Body body , Vector2 localPt){
		return null;
	}
	

	/**
	 * returns array of {@link Tracer}s attached to body
	 * @param {Body} body 
	 * @return Array if body has tracers else returns null 
	 */
	public Tracer[] getTracers(Body body){
		return null;
	}
	
	/**
	 * removes tracer from body
	 * @param {Body} body 
	 */
	public void removeTracer(Tracer tracer){
	}
	
	/**
	 * removes tracer from body
	 * @param {Body} body 
	 */
	public void removeTracers(Body body){
	}
	
	/**
	 * Removes all tracers attached to bodies
	 */
	public void removeAllTracers(){
	} 
	
	/**
	 * Resets tracers attached to body
	 */
	public void resetTracers(Body body){
	}
	
	/**
	 * Resets all tracers attached to bodies
	 */
	public void resetAllTracers(){
	}
	
	/**
	 * Adds {@link Grapher} attached to the body in simulation
	 * @param {Body} body 
	 * @param {Grapher} returns added graph object
	 */
	public Grapher addGraph(Body body){
		return null;
	}
	
	/**
	 * Adds {@link Grapher} attached to the joint in simulation
	 * @param {Joint} joint 
	 * @param {Grapher} returns added graph object
	 */
	public Grapher addGraph(Joint joint){
		return null;
	}
	
	
	/**
	 * Resets graphs attached to body
	 * @param body
	 */
	public void resetGraphs(Body body){
	}
	

	/**
	 * Resets {@link Grapher}s attached to joint
	 * @param joint
	 */
	public void resetGraphs(Joint joint){
	}
	
	/**
	 * Resets all {@link Grapher}s attached to bodies
	 */
	public void resetAllGraphs(){
	}
	
	/**
	 * Adds {@link Timer} to the simulation
	 * @param {Timer} returns added timer object
	 */
	public Timer addTimer(){
		return null;
	}
	
	
	/**
	 * Resets all {@link Timer}s currently added to the simulation
	 */
	public void resetAllTimers(){
	}
	
	
	/**
	 * returns context associated with world canvas
	 */
	public Canvas getCanvas(){
		return null;
	}
		
	
	/**
	 * returns current transform
	 * @retun {Transform} transform object 
	 */
	public Transform getTransform(){
		return null;
	}

	
	/**
	 * returns worldPoint corresponding to point in screen coordinates
	 * @param screenPt point in pixel coordinates with top left as origin and y axis downwards
	 * @return returns point in world coordinates
	 */
	public Vector2 screenToWorld(Vector2 screenPt){
		return null;
	}
	
	/**
	 * returns point on screen corresponding to point in world coordinates
	 * @param worldPt point in world coordinates
	 * @return returns point in pixel coordinates with top left as origin and y axis downwards
	 */
	public Vector2 worldToScreen(Vector2 worldPt){
		return null;
	}

	/**
	 * returns current width of canvas screen in pixels
	 * @return
	 */
	public double getScreenWidth(){
		return 0;
	}
	
	/**
	 * returns current height of canvas screen in pixels
	 * @return
	 */
	public double getScreenHeight(){
		return 0;
	}
	
	/**
	 * Set range of E
	 * @param rangleE Vector to keep track of min and max range of Electric field, x==minValue and y=maxValue
	 * @param rangleB Vector to keep track of min and max range of Magnetic field, x==minValue and y=maxValue
	 */
	public void setMinMaxField(Vector2 rangleE,Vector2 rangleB) {
	}
}
