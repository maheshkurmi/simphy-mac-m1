package script;


/**
 * Class to trace locus of a point on body
 */
public class Tracer {
	/** Returns Pixel size of tracer */
	public int getPtSize() {
		return 0;
	}

	/** Sets pixel size of tracer */
	public void setPtSize(int ptSize) {
		
	}

	/** Returns Maximum Number of points in tracer array */
	public int getPtsCount() {
		return 0;
	}

	/** Sets Maximum Number of points in tracer array */
	public void setPtsCount(int count) {
		
	}

	/** Returns Mode Used to draw Tracer can be Solid[0] or dotted [1] */
	public int getMode() {
		return 0;
	}

	/** Sets Mode Used to draw Tracer can be Solid[0] or dotted [1] */
	public void setMode(int mode) {
		
	}

	
	/**
	 * Creates trajectory tracer for the point on body
	 * 
	 * @param body
	 *            SandboxBody containing point whose trajectory is to be traced
	 * @param bodyPt
	 *            Point on body (in bodySapce) whose trajectory is to be traced
	 */
	public Tracer(Body body, Vector2 bodyPt) {

	}


	/**
	 * Reinitializes the tracer
	 */
	public void reset() {
		
	}



	/**
	 * returns body to which tracer is associated
	 * 
	 * @return {body}
	 */
	public Body getBody() {
		return null;
	}

	/**
	 * Sets the body at which trace point lies (it also sets trace point as body
	 * centre i.e. (0,0) in body space)
	 * 
	 * @param body {Body}
	 */
	public void setBody(Body body) {
		
	}

	/**
	 * returns point in world space whose trajectory is to be traced
	 * 
	 * @return{vector2}
	 */
	public Vector2 getWorldPoint() {
		return null;
	}

	/**
	 * returns Velocity in world space of point whose trajectory is to be traced
	 * 
	 * @return {vector2}
	 */
	public Vector2 getVelocity() {
		return null;
	}

	/**
	 * returns point in body space whose trajectory is to be traced
	 * 
	 * @return {Vector2} point in body coordiantes
	 */
	public Vector2 getBodyPt() {
		return null;
	}

	/**
	 * Sets trace point on the body associated with tracer
	 * 
	 * @param bodyPt {Vector2}
	 *            Point in local body space (where (0,0) lies at body's Center of mass)
	 */
	public void setBodyPt(Vector2 bodyPt) {
		
	}

		
	/**
	 * @return the tracer Color
	 */
	public Color getColor() {
		return null;
	}

	/**
	 * Sets Fill Color of the body (to disable filling shape pass null ar arguement)
	 * @param color {Color|String} Color Object or css color string  ex.<br>
	 * 	<ol> 
	 * 	<li> Common color name "red", "green" </li>
	 *	<li> Hexadecimal representation of color such as #FF0096 or 0xFF0096 </li>
	 * 	<li> Color functions "rgb(255,0,0)","hsl(180, 50%, 50%)","rgba(255,255,120,1)" </li>
	 * </ol>
	 * @throws IllegalArgumentException if color is null or invalid
	 */
	public void setColor(Color color) {
		
	}

	/**
	 * True if linear velocity is to be shown in tracer
	 * @return {boolean}
	 */
	public boolean isShowVelocity() {
		return false;
	}

	/**
	 * Sets if linear veclocity of tracer point is displayed
	 * @param showVelocity {boolean}
	 */
	public void setShowVelocity(boolean showVelocity) {
		
	}
	
	/**
	 * Returns true if angular velocity is to be dispalyed
	 * @return {boolean}
	 */
	public boolean isShowAngularVelocity() {
		return false;
	}

	/**
	 * Sets if angular velocity is to be dispalyed
	 * @param showAnglurVel {boolean}
	 */
	public void setShowAngularVelocity(boolean showAnglurVel) {
		
	}
	
	/**
	 * Returns true if linear acceleration is shown in tracers
	 * @return {boolean}
	 */
	public boolean isShowAcceleration() {
		return false;
	}
	
	/**
	 * Sets if linear acceleration is to be displayed in tracer
	 * @param showAcceleration {boolean}
	 */
	public void setShowAcceleration(boolean showAcceleration) {
		
	}
	
	/**
	 * returns acceleration of tracer point in ground frame
	 * @return {Vector2}
	 */
	public Vector2 getAcceleration(){
		return null;
	}
	
	/**
	 * returns angular acceleration of body in radian/s2 w.r.t. tracer point in ground frame
	 * @return {Number}
	 */
	public double getAngAcceleration(){
		return 0;
	}
	
}

