package script;


/** Base class for actions that transition over time using the percent complete.
*/
abstract public class TemporalAction extends Action {


	public boolean act (float delta) {
		return false;
	}

	/** Skips to the end of the transition. */
	public void finish () {
		
	}

	public void restart () {

	}

	/** Resets the optional state of this action to as if it were newly created,
	 *  Setting action and interpolation to be null
	 * */
	public void reset () {
	}

	/** Gets the transition time so far. */
	public float getTime () {
		return 0;
	}

	/** Sets the transition time so far. */
	public void setTime (float time) {
		//this.time = time;
	}

	public float getDuration () {
		return 0;
	}

	/** Sets the length of the transition in seconds. */
	public void setDuration (float duration) {
		//this.duration = duration;
	}

	/**
	 * Returns current interpolation name
	 * @return
	 */
	public String getInterpolation () {
		return "";
	}

	/**
	 * Sets interpolation
	 * @param String interpolation Name
	 */
	public void setInterpolation (String name) {
	}
	
	/** Returns true if, the action's progress is reversed i.e. goes from 100% to 0%. */
	public boolean isReverse () {
		return false;
	}

	/** When true, the action's progress will go from 100% to 0%. */
	public void setReverse (boolean reverse) {
		//this.reverse = reverse;
	}
}
