package script;

/**
 * Wrapper Class used in Scripting for fileResource Class 
 * @author mahesh
 *
 */
public class File {
	/**
	 * Do not allow its instance creation
	 */
	private File() {
		
	}

	/**
	 * Returns identifier name of file
	 * @return
	 */
	public String getName(){
		return "";
	}
	
	/**
	 * Returns location of file on disc
	 * @return
	 */
	public String getPath(){
		return "";
	}
	
	
	@Override
	public String toString(){
		return "";
	}
	
	/**
	 * returns text content of the file
	 * @return
	 */
	public String getFileContent(){
		return "";
	}

	/**
	 * sets content of file
	 * @param text
	 */
	public void setFileContent(String text) {
		
	}
	
}
