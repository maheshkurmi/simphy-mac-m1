package script;

public class Preferences{
		
	/**
	 * @return the backColor
	 */
	public  Color getBackGroundColor() {
		return null;
	}
	
	/**
	 * @param backColor the backColor to set
	 */
	public  void setBackGroundColor(Color backColor) {
		
	}
	
	/**
	 * /**
	 * Sets BackGround Color of world
	 * @param color {Color|String} Color Object or css color string  ex.<br>
	 * 	<ol> 
	 * 	<li> Common color name "red", "green" </li>
	 *	<li> Hexadecimal representation of color such as #FF0096 or 0xFF0096 </li>
	 * 	<li> Color functions "rgb(255,0,0)","hsl(180, 50%, 50%)","rgba(255,255,120,1)" </li>
	 * </ol>
	 * @throws IllegalArgumentException if color is null or invalid
	 */
	public  void setBackGroundColor(Object color) throws Exception {
		
	}
	
	/**
	 * @return the foreColor
	 */
	public  Color getForeGroundColor() {
		return null;
	}
	
	/**
	 * Sets foreground Color of world
	 * @param color {Color|String} Color Object or css color string  ex.<br>
	 * 	<ol> 
	 * 	<li> Common color name "red", "green" </li>
	 *	<li> Hexadecimal representation of color such as #FF0096 or 0xFF0096 </li>
	 * 	<li> Color functions "rgb(255,0,0)","hsl(180, 50%, 50%)","rgba(255,255,120,1)" </li>
	 * </ol>
	 * @throws IllegalArgumentException if color is null or invalid
	 */
	public  void setForeGroundColor(Color foreColor) {
		
	}

	/**
	 * @param foreColor the foreColor to set
	 * @throws Exception 
	 */
	public  void setForeGroundColor(String cssColor) throws Exception {
		
	}
	

	/**Order "Mg","f","N","T","R","kx","E", "F","Fps","Fcf","Fcori"
	 * @return
	 * */
    public  Boolean isForceEnabled(int index){
    	return false;
    }
    
    /**Order "Mg","f","N","T","R","kx","E", "F","Fps","Fcf","Fcori"
	 * */
    public  void setForceEnabled(int index,boolean enabled){
    	
    }
    /**Order "Mg","f","N","T","R","kx","E", "F","Fps","Fcf","Fcori"
	 * @return
	 * */
    public  Color getForceColor(int index){
    	return null;
    }
    
    /**Order "Mg","f","N","T","R","kx","E", "F","Fps","Fcf","Fcori"
	 * */
    public  void setForceColor(int index,Color color){
    	
    }
    /**Order "Mg","f","N","T","R","kx","E", "F","Fps","Fcf","Fcori"
	 * @return
	 * */
    public  String getForceName(int index){
    	return null;
    }
    
    /**Order "Mg","f","N","T","R","kx","E", "F","Fps","Fcf","Fcori"
	 * */
    public  void setForceName(int index,String name){
    	
    }
	
	/**
	 * Sets number of significant figures used in calculations
	 * @param n
	 */
	public  void setMaxSignificantFigures(int n) {
		
	}
	
	/**
	 * Returns number of significant figures used in calculations
	 */
	public  int getMaxSignifucantFigures() {
		return 0;
	}
	
	/**
	 * Returns true if body labels should be shown.
	 * @return boolean
	 */
	public  boolean isBodyLabeled() {
		return false;
	}
	
	/**
	 * Sets the body labels flag.
	 * @param flag true if body labels should be shown
	 */
	public  void setBodyLabeled(boolean flag) {
		return ;
	}
	
	/**
	 * Returns true if the origin and origin label should be shown.
	 * @return boolean
	 */
	public   boolean isOriginLabeled() {
		return false;
	}
	
	/**
	 * Sets the origin label flag.
	 * @param flag true if the origin and origin label should be shown
	 */
	public   void setOriginLabeled(boolean flag) {
		
	}
	
	/**
	 * Returns true if the simulation time should be shown.
	 * @return boolean
	 */
	public static  boolean isTimeShown() {
		return false;
	}
	
	/**
	 * Sets the time label flag.
	 * @param {Boolean} flag true if the simulation time should be shown
	 */
	public static  void setTimeShown(boolean flag) {
	}
	
	/**
	 * Sets the gravity rendered flag.
	 * @param flag true if the gravity should be shown
	 */
	public   void setGravityRendered(boolean flag) {
		
	}
	
	/**
	 * Returns true if gravity should be rendered on screen
	 * @return boolean
	 */
	public  boolean isGravityRendered() {
		return false;
	}
	
	/**
	 * Returns true if the center of mass should be rendered for bodies.
	 * @return boolean
	 */
	public  boolean isBodyCenterEnabled() {
		return false;
	}
	
	/**
	 * Enables or disables the rendering of the center of mass for bodies.
	 * @param flag true if the center of mass should be rendered
	 */
	public  void setBodyCenterEnabled(boolean flag) {
		
	}
	
	
	/**
	 * Returns true if the Grids should be rendered.
	 * @return boolean
	 */
	public  boolean isGridEnabled() {
		return false;
	}
	
	/**
	 * Enables or disables the rendering of the grid.
	 * @param flag true if the scale should be rendered
	 */
	public  void setGridEnabled(boolean flag) {
		
	}
	
	/**
	 * Returns true if the scale should be rendered.
	 * @return boolean
	 */
	public  boolean isScaleEnabled() {
		return false;
	}
	
	/**
	 * Enables or disables the rendering of the scale.
	 * @param flag true if the scale should be rendered
	 */
	public  void setScaleEnabled(boolean flag) {
		
	}
	
	
	/**
	 * Returns true if the body charge should be rendered.
	 * @return boolean
	 */
	public  boolean isBodyChargeDisplayed() {
		return false;
	}
	
	/**
	 * Enables or disables the rendering of body charge
	 * @param flag true if body charge should be rendered
	 */
	public  void setBodyChargeDisplayed(boolean flag) {
		
	}
	
	
	/**
	 * Returns true if body velocities should be rendered.
	 * @return boolean
	 */
	public  boolean isBodyVelocityEnabled() {
		return false;
	}
	
	/**
	 * Enables or disables the rendering of body velocity vectors.
	 * @param flag true if velocities should be rendered
	 */
	public  void setBodyVelocityEnabled(boolean flag) {
		
	}
	
	/**
	 * @return the forceScale in m/N
	 */
	public  double getForceScale() {
		return 0;
	}

	/**
	 * @param forceScale the forceScale to set in m/N
	 */
	public  void setForceScale(double forceScale) {
		
	}

	/**
	 * returns velocity scale m/(m/s)
	 * @return
	 */
	public  double getVelocityScale() {
		return 0;
	}

	/**
	 * Sets force scale in m/(m/s)
	 * @param velocityScale
	 */
	public  void setVelocityScale(double velocityScale) {
		
	}

	/**
	 * returns min force that can be shown in free body diagrams
	 * @return
	 */
	public  double getMinForceDisplayed() {
		return 0;
	}

	/**
	 * Sets min force that can be shown in free body diagrams
	 * @param minForceDisplayed
	 */
	public  void setMinForceDisplayed(double minForceDisplayed) {
		
	}

	/**
	 * returns min speed that can be shown in tracer
	 * @return
	 */
	public  double getMinVelocityDisplayed() {
		return 0;
	}

	/**
	 * Sets min speed that can be shown in tracer
	 * @param minvelocity
	 */
	public  void setMinVelocityDisplayed(double minvelocity) {
		
	}

	/**
	 * Returns true if position of body is displayed
	 * @return
	 */
	public  boolean isPositionInfoEnabled() {
		return false;
	}

	/**
	 * if position of body is displayed
	 * @param posInfoEnabled
	 */
	public  void setPositionInfoEnabled(boolean posInfoEnabled) {
		
	}

	/**
	 * Returns true if electric field lines are drawn else false
	 * @return {boolean}
	 */
	public boolean isElectricFieldDrawn() {
		return false;
	}

	/**
	 * Enables rendering of electric field lines for existing electric fields
	 * @param magneticFieldDrawn {boolean}
	 */
	public void setElectricFieldDrawn(boolean electricFieldDrawn) {
		
	}

	/**
	 * Returns true if electric field due to charges is rendered else false
	 * @param electricFieldForChargeDrawn {boolean}
	 */
	public  void setElectricFieldForChargeDrawn(boolean electricFieldForChargeDrawn) {
		
	}
	
	/**
	 * Returns true if magnetic field lines are drawn 
	 * @return {boolean}
	 */
	public  boolean isMagneticFieldDrawn() {
		return false;
	}

	/**
	 * Enables rendering of magnetic field lines for existing magnetic fields
	 * @param magneticFieldDrawn {boolean}
	 */
	public  void setMagneticFieldDrawn(boolean magneticFieldDrawn) {
		
	}
	
	/**
	 * Returns if simulation can be edited by user
	 * @return
	 */
	public boolean isSimulationLocked() {
		return false;
	}

	/**
	 * Sets if simulation can be edited by user
	 * @param simulationLocked
	 */
	public  void setSimulationLocked(boolean simulationLocked) {
		
	}
	
	/**
	 * Returns Number of pixels represented by 1 unit on canvas
	 * @return {Number}
	 */
	public double getPixelPerUnitFactor(){
		return 0;
	}


}
