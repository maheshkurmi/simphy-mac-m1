package script;
import canvas.Canvas;
import widgets.ActionItemWidget;
import widgets.Widget;
import widgets.Button;
import widgets.CheckBox;
import widgets.ComboBox;
import widgets.Desktop;
import widgets.Dialog;
import widgets.ItemWidget;
import widgets.Label;
import widgets.ListBox;
import widgets.MenuBar;
import widgets.Menu;
import widgets.Node;
import widgets.Panel;
import widgets.PasswordField;
import widgets.SelectableItemWidget;
import widgets.ProgressBar;
import widgets.Slider;
import widgets.SpinBox;
import widgets.SplitPane;
import widgets.TabbedPane;
import widgets.Table;
import widgets.TextArea;
import widgets.TextField;
import widgets.ToggleButton;
import widgets.TreeView;
/**
 * Class to manage gui in simphy via scripting Actual gui is not exposed to
 * scripting. All gui related tasks are done through this wrapper class
 * @author mahesh
 */
public class Widgets {

	
	/**
	 * Parse gui from XML configuration file and returns widget root widget, so make sure there is only one root widget in xml definition
	 * Note that widget is not added to gui, ti add widget call {@link #addWidget(Widget)}
	 * @param xml XML configuration file for gui definition
	 * @return {Widget} parsed widget if done successfully else null
	 * @throws SimphyScriptException 
	 */
	
	public Widget parse(String xml) throws Exception{
		return null;
	}
	/**
	 * Adds the specified component to the root desktop
	 * 
	 * @param widget
	 */
	public void addWidget(Widget widget) {
		
	}

	/**
	 * Remove the specified component from its parent list
	 * 
	 * @param widget
	 */
	public void removeWidget(Widget widget) {
		
	}

	/**
	 * removes all widgets from gui except built-in toolbars and navigation bar
	 */
	public void removeAll(){
		
	}
	
	/**
	 * Returns currently focused gui widget (widget recieving current keyboard events)
	 * @return {Widget} focused widget if any else returns null
	 */
	public Widget getFocusedWidget(){
		return null;
	}
	
	/**
	 * Request focus for the given component
	 * @param widget {Widget} widget requesting focus
	 */
	public void setFocusedWidget(Widget widget){
		
	}
	
	/**
	 * Sets App toolbars  visible or hidden
	 * @param index {Integer} index of toolbar [0 to 3]
	 * @param visible
	 */
	public  void setToolBarShown(int index, boolean visible){
		
	}

	/**
	 * returns true of toolbar at specified index is visible
	 * @param index
	 * @return
	 */
	public boolean isToolBarShown(int index) {
		return false;
	}
	
	/**
	 * Sets Navigation bar at bottom of app visible or hidden
	 * @param navBarShown
	 */
	public  void setSimulationControlsShown(boolean navBarShown) {
		
	}
	
	/**
	 * returns true if navigation bar at bottom of app is visible
	 * @return
	 */
	public  boolean isSimulationControlsShown() {
		return false;
	}

	/**
	 * Refreshes whole gui, should be called whenever layout needs to be calculated again ex. setting font etc
	 */
	public void reValidateGui() {
		

	}

	/**
	 * Finds the first component from the root desktop by a specified name value
	 * 
	 * @param name
	 *            Name of the widget
	 * @return the first suitable widget, or null
	 */
	public Widget getWidget(String name) {
		return null;
	}

	
	/**
	 * Searches Label widget in gui identified by name
	 * @param name
	 * @return {Label} widget if found else returns null
	 */
	public Label getLabel(String name) {
		return null;
	}
	
	/**
	 * Searches Button widget in gui identified by name
	 * @param name
	 * @return {Button} widget if found else returns null
	 */
	public Button getButton(String name) {
		return null;
	}
		
	/**
	 * Searches Slider widget in gui identified by name
	 * @param name
	 * @return {Slider} widget if found else returns null
	 */
	public Slider getSlider(String name) {
		return null;
	}

	/**
	 * Searches Progressbar widget in gui identified by name
	 * @param name
	 * @return {Progressbar} widget if found else returns null
	 */
	public ProgressBar getProgressBar(String name) {
		return null;
	}
	
	/**
	 * Searches Spinbox widget in gui identified by name
	 * @param name
	 * @return {Spinbox} widget if found else returns null
	 */
	public SpinBox getSpinBox(String name) {
		return null;
	}

	/**
	 * Searches Togglebutton widget in gui identified by name
	 * @param name
	 * @return {Togglebutton} widget if found else returns null
	 */
	public ToggleButton getToggleButton(String name) {
		return null;
	}

	/**
	 * Searches Checkbox widget in gui identified by name
	 * @param name
	 * @return {Checkbox} widget if found else returns null
	 */
	public CheckBox getCheckBox(String name) {
		return null;
	}

	/**
	 * Searches TextField widget in gui identified by name
	 * @param name
	 * @return {TextField} widget if found else returns null
	 */
	public TextField getTextField(String name) {
		return null;
	}

	/**
	 * Searches PasswordField widget in gui identified by name
	 * @param name
	 * @return {PasswordField} widget if found else returns null
	 */
	public PasswordField getPasswordField(String name) {
		return null;
	}
	
	/**
	 * Searches TextArea widget in gui identified by name
	 * @param name
	 * @return {TextArea} widget if found else returns null
	 */
	public TextArea getTextArea(String name) {
		return null;
	}
	
	/**
	 * Searches ListBox widget in gui identified by name
	 * @param name
	 * @return {ListBox} widget if found else returns null
	 */
	public ListBox getListBox(String name) {
		return null;
	}
	
	/**
	 * Searches ComboBox widget in gui identified by name
	 * @param name
	 * @return {ComboBox} widget if found else returns null
	 */
	public ComboBox getComboBox(String name) {
		return null;
	}
	
	/**
	 * Searches Node widget in gui identified by name
	 * @param name
	 * @return {Node} widget if found else returns null
	 */
	public Node getNode(String name) {
		return null;
	}
	
	/**
	 * Searches TreeView widget in gui identified by name
	 * @param name
	 * @return {TreeView} widget if found else returns null
	 */
	public TreeView getTreeView(String name) {
		return null;
	}
	
	/**
	 * Searches Table widget in gui identified by name
	 * @param name
	 * @return {Table} widget if found else returns null
	 */
	public Table getTable(String name) {
		return null;
	}
	
	/**
	 * Searches SplitPane widget in gui identified by name
	 * @param name
	 * @return {SplitPane} widget if found else returns null
	 */
	public Panel getPanel(String name) {
		return null;
	}
	
	/**
	 * Searches SplitPane widget in gui identified by name
	 * @param name
	 * @return {SplitPane} widget if found else returns null
	 */
	public SplitPane getSplitPane(String name) {
		return null;
	}
	
	/**
	 * Searches TabbedPane widget in gui identified by name
	 * @param name
	 * @return {TabbedPane} widget if found else returns null
	 */
	public TabbedPane getTabbedPane(String name) {
		return null;
	}
	
	/**
	 * Searches Dialog widget in gui identified by name
	 * @param name
	 * @return {Dialog} widget if found else returns null
	 */
	public Dialog getDialog(String name) {
		return null;
	}
	
	/**
	 * Searches Desktop widget in gui identified by name
	 * @param name
	 * @return {Desktop} widget if found else returns null
	 */
	public Desktop getDesktop(String name) {
		return null;
	}
	
	/**
	 * Searches MenuBar widget in gui identified by name
	 * @param name
	 * @return {MenuBar} widget if found else returns null
	 */
	public MenuBar getMenuBar(String name) {
		return null;
	}
	
	/**
	 * Searches Menu widget in gui identified by name
	 * @param name
	 * @return {Menu} widget if found else returns null
	 */
	public Menu getMenu(String name) {
		return null;
	}
	
	/**
	 * Searches MenuItem widget in gui identified by name
	 * @param name
	 * @return {MenuItem} widget if found else returns null
	 */
	public ActionItemWidget getMenuItem(String name) {
		return null;
	}
	
	/**
	 * Searches Canvas widget in gui identified by name
	 * @param name
	 * @return {Canvas} widget if found else returns null
	 */
	public Canvas getCanvas(String name) {
		return null;
	}
	
	/**
	 * Returns Graph Window identified by name
	 * @param name
	 * @return {Grapher} widget if found else returns null
	 */
	public Grapher getGraph(String name) {
		
		return null;
	}
	
	/**
	 * Returns Timer Window identified by name
	 * @param name
	 * @return {Timer} widget if found else returns null
	 */
	public Timer getTimer(String name) {
		
		return null;
	}
	
	/**
	 * Create short one liner display for text 
	 * @param text
	 * @return
	 */
	public ItemWidget createLabel(String text) {
		return null;
	}

	/**
	 * Creates push button with texton it
	 * @param text {String}
	 * @return
	 */
	public Button createButton(String text) {
		return null;
	}

	/**
	 * Creates a two state push button will can toggled on or off
	 * @param text
	 * @return
	 */
	public ToggleButton createToggleButton(String text) {
		return null;
	}
	
	/**
	 * Creates tick box that can toggled by the user to indicate an affirmative or negative choice.
	 * You can set group property for check box to behave like radio button
	 * @param text
	 * @return
	 */
	public SelectableItemWidget createCheckBox(String text) {
		return null;
	}

	/**
	 * Creates horizontal Slider with given min and max values
	 * @param value
	 * @param min
	 * @param max
	 * @return
	 */
	public ProgressBar createSlider(double value, double min, double max) {
		return null;
	}

	/**
	 * Creates Spinner widget which is a textbox that accepts a range of values
	 * @param value
	 * @param min
	 * @param max
	 * @return
	 */
	public ProgressBar createSpinBox(double value, double min, double max) {
		return null;
	}

	/**
	 * creates progressbar which contains a bar visually indicating progress.
	 * @param value
	 * @param min
	 * @param max
	 * @return
	 */
	public ProgressBar createProgressBar(double value, double min, double max) {
		return null;
	}

	/**
	 * creates one line text input box which allows the editing of a single line of text
	 * @param text
	 * @return
	 */
	public TextField createTextField(String text) {
		return null;
	}

	/**
	 * Creates TextField component, but does not show the original characters.
	 * @param text
	 * @return
	 */
	public TextField createPasswordField(String text) {
		return null;
	}

	/**
	 * Creates multi-line area that displays plain text, and internally handles scrolling.
	 * @param text
	 * @return
	 */
	public TextArea createTextArea(String text) {
		return null;
	}

	/**
	 * creates list which allows the user to select one or more objects from a list, and internally handles scrolling.
	 * @return
	 */
	public ListBox createListBox() {
		return null;
	}

	/**
	 * Creates Empty list which allows the user to select one or more objects from a list, and internally handles scrolling.
	 * @param arr {Array} array of objects to be added as items of list
	 * @return
	 */
	public ListBox createListBox(Object[] arr) {
		return null;
	}
	
	/**
	 * Creates empty comboBox, a combination of a text field and drop-down list
	 * @return
	 */
	public ComboBox createComboBox() {
		return null;
	}

	/**
	 * Creates ComboBox, a combination of a text field and drop-down list
	 * @param arr {Array} array of objects to be added as items in drop down list of combobox
	 * @return
	 */
	public ComboBox createComboBox(Object[] arr) {
		return null;
	}
	
	/**
	 * Creates Panel, a container with a layout manager used to contain other elements
	 * @return
	 */
	public Panel createPanel() {
		return null;
	}

	/**
	 * Create horizontal SplitPane which is used to divide two components with draggable divider
	 * @return
	 */
	public SplitPane createSplitPane() {
		return null;
	}

	/**
	 * Creates draggable Dialog window
	 * @param title
	 * @return
	 */
	public Dialog createDialog(String title) {
		return null;
	}

	/**
	 * Desktop is the root pane, it contains components (mainly panels, these fill the available space), dialogs (centered), combolists, popupmenus, and tooltips. 
	 * You can add only components and dialogs to desktop, the last will be on the top.
	 * @return
	 */
	public Desktop createDesktop() {
		return null;
	}

	/**
	 * Creates is a horizontal or a vertical separator line. generally used in menu
	 * @return
	 */
	public Widget createSeparator() {
		return null;
	}

	/**
	 * Creates TabbePane which has several components, such as panels, share the same space.
	 * The user chooses which component to view by selecting the tab corresponding to the desired component
	 * @return
	 */
	public TabbedPane createTabbedPane() {
		return null;
	}

	/**
	 * Creates an empty table which presents data in a two-dimensional table format, allows to select rows, has header/column, and internally handles scrolling
	 * @return
	 */
	public Table createTable() {
		return null;
	}

	/**
	 * /**
	 * Creates  table which presents data in a two-dimensional table format, allows to select rows, has header/column, and internally handles scrolling
	 * @param data {Array[][]} 2D array of objects to be dispalyed in table
	 * @param columns {String[]} Array with name of columns
	 * @return
	 */
	public Table createTable(Object[][] data, String[] columns) {
		return null;
	}
	
	/**
	 * Creates Tree which displays a set of hierarchical data, contains nodes and a node could have subnodes. It internally handles scrolling	
	 * @return
	 */
	public TreeView createTree() {
		return null;
	}

	/**
	 * Creates menu bar which can be added to top or botton of panel or dialog
	 * @return
	 */
	public MenuBar createMenuBar() {
		return null;
	}

	/**
	 * Creates popup menu ready to be used with widgets
	 * @return
	 */
	public Menu createPopUpMenu() {
		return null;
	}

	/*
	 * Creates new Canvas Element which has several methods for drawing over it
	 * @param name
	 * @return

	public Canvas createCanvas(String name) {
		return null;
	}
		 */
	
	/**
	 * Converts widget to  Label if possible else returns null
	 * @param widget
	 * @return {Label} 
	 */
	public Label asLabel(Widget widget) {
		return null;
	}
	
	/**
	 * Converts widget to  Button if possible else returns null
	 * @param widget
	 * @return {Button} 
	 */
	public Button asButton(Widget widget) {
		return null;
	}
		
	/**
	 * Converts widget to  Slider if possible else returns null
	 * @param widget
	 * @return {Slider} 
	 */
	public Slider asSlider(Widget widget) {
		return null;
	}

	/**
	 * Converts widget to  Progressbar if possible else returns null
	 * @param widget
	 * @return {Progressbar} 
	 */
	public ProgressBar asProgressBar(Widget widget) {
		return null;
	}
	
	/**
	 * Converts widget to  Spinbox if possible else returns null
	 * @param widget
	 * @return {Spinbox} 
	 */
	public SpinBox asSpinBox(Widget widget) {
		return null;
	}

	/**
	 * Converts widget to  Togglebutton if possible else returns null
	 * @param widget
	 * @return {Togglebutton} 
	 */
	public ToggleButton asToggleButton(Widget widget) {
		return null;
	}

	/**
	 * Converts widget to  Checkbox if possible else returns null
	 * @param widget
	 * @return {Checkbox} 
	 */
	public CheckBox asCheckBox(Widget widget) {
		return null;
	}

	/**
	 * Converts widget to  TextField if possible else returns null
	 * @param widget
	 * @return {TextField} 
	 */
	public TextField asTextField(Widget widget) {
		return null;
	}

	/**
	 * Converts widget to  PasswordField if possible else returns null
	 * @param widget
	 * @return {PasswordField} 
	 */
	public PasswordField asPasswordField(Widget widget) {
		return null;
	}
	
	/**
	 * Converts widget to  TextArea if possible else returns null
	 * @param widget
	 * @return {TextArea} 
	 */
	public TextArea asTextArea(Widget widget) {
		return null;
	}
	
	/**
	 * Converts widget to  ListBox if possible else returns null
	 * @param widget
	 * @return {ListBox} 
	 */
	public ListBox asListBox(Widget widget) {
		return null;
	}
	
	/**
	 * Converts widget to  ComboBox if possible else returns null
	 * @param widget
	 * @return {ComboBox} 
	 */
	public ComboBox asComboBox(Widget widget) {
		return null;
	}
	
	/**
	 * Converts widget to  Node if possible else returns null
	 * @param widget
	 * @return {Node} 
	 */
	public Node asNode(Widget widget) {
		return null;
	}
	
	/**
	 * Converts widget to  TreeView if possible else returns null
	 * @param widget
	 * @return {TreeView} 
	 */
	public TreeView asTreeView(Widget widget) {
		return null;
	}
	
	/**
	 * Converts widget to  Table if possible else returns null
	 * @param widget
	 * @return {Table} 
	 */
	public Table asTable(Widget widget) {
		return null;
	}
	
	/**
	 * Converts widget to  SplitPane if possible else returns null
	 * @param widget
	 * @return {SplitPane} 
	 */
	public Panel asPanel(Widget widget) {
		return null;
	}
	
	/**
	 * Converts widget to  SplitPane if possible else returns null
	 * @param widget
	 * @return {SplitPane} 
	 */
	public SplitPane asSplitPane(Widget widget) {
		return null;
	}
	
	/**
	 * Converts widget to  TabbedPane if possible else returns null
	 * @param widget
	 * @return {TabbedPane} 
	 */
	public TabbedPane asTabbedPane(Widget widget) {
		return null;
	}
	
	/**
	 * Converts widget to  Dialog if possible else returns null
	 * @param widget
	 * @return {Dialog} 
	 */
	public Dialog asDialog(Widget widget) {
		return null;
	}
	
	/**
	 * Converts widget to  Desktop if possible else returns null
	 * @param widget
	 * @return {Desktop} 
	 */
	public Desktop asDesktop(Widget widget) {
		return null;
	}
	
	/**
	 * Converts widget to  MenuBar if possible else returns null
	 * @param widget
	 * @return {MenuBar} 
	 */
	public MenuBar asMenuBar(Widget widget) {
		return null;
	}
	
	/**
	 * Converts widget to  Menu if possible else returns null
	 * @param widget
	 * @return {Menu} 
	 */
	public Menu asMenu(Widget widget) {
		return null;
	}
	
	/**
	 * Converts widget to  MenuItem if possible else returns null
	 * @param widget
	 * @return {MenuItem} 
	 */
	public ActionItemWidget asMenuItem(Widget widget) {
		return null;
	}
	
	/*
	 * Converts widget to  Canvas if possible else returns null
	 * @param widget
	 * @return {Canvas} 
	
	public Canvas asCanvas(Widget widget) {
		return null;
	}
	 */

}
