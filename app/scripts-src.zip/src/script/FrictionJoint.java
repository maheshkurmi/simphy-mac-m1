package script;

/**
 * Implementation of a friction joint.
 * <p>
 * A friction joint is a constraint that drives both linear and angular 
 * velocities to zero.
 * <p>
 * This joint is typically used with one dynamic and one static body.  In this
 * context, the joint will apply linear and angular friction to stop the body's motion.
 * <p>
 * Setting the maximum force and torque values will determine the rate at which the motion
 * is stopped.
 */
public class FrictionJoint extends Joint  {
	/**
	 * Returns the maximum torque this constraint will apply in newton-meters.
	 * @return double
	 */
	public double getMaximumTorque() {
		return 0;
	}
	
	/**
	 * Sets the maximum torque this constraint will apply in newton-meters.
	 * @param maximumTorque the maximum torque in newton-meters; in the range [0, &infin;]
	 * @throws IllegalArgumentException if maxTorque is less than zero
	 */
	public void setMaximumTorque(double maximumTorque) {
		
	}

	/**
	 * Returns the maximum force this constraint will apply in newtons.
	 * @return double
	 */
	public double getMaximumForce() {
		return 0;
	}
	
	/**
	 * Sets the maximum force this constraint will apply in newtons.
	 * @param maximumForce the maximum force in newtons; in the range [0, &infin;]
	 * @throws IllegalArgumentException if maxForce is less than zero
	 */
	public void setMaximumForce(double maximumForce) {
	}
	

}
