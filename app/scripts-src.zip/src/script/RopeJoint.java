package script;

/**
 * Implementation a maximum and/or minimum length distance joint.
 * <p>
 * A rope joint contains the distance between two bodies.  The bodies can 
 * rotate freely about the anchor points.  The system as a whole can rotate and
 * translate freely as well.
 * <p>
 * This joint is like the {@link DistanceJoint}, but includes an upper and 
 * lower limit and does not include a spring-damper system.
 * <p>
 * By default the lower and upper limits are set to the current distance
 * between the given anchor points and will function identically like a
 * {@link DistanceJoint}.  The upper and lower limits can be enabled
 * separately.
 */
public class RopeJoint extends Joint  {
	/**
	 * Returns the upper limit in meters.
	 * @return double
	 */
	public double getUpperLimit() {
		return 0;
	}
	
	/**
	 * Sets the upper limit in meters.
	 * @param upperLimit the upper limit in meters; must be greater than or equal to zero
	 * @throws IllegalArgumentException if upperLimit is less than zero or less than the current lower limit
	 */
	public void setUpperLimit(double upperLimit) {
		
	}
	
	/**
	 * Sets whether the upper limit is enabled.
	 * @param flag true if the upper limit should be enabled
	 */
	public void setUpperLimitEnabled(boolean flag) {
		
	}
	
	/**
	 * Returns true if the upper limit is enabled.
	 * @return boolean true if the upper limit is enabled
	 */
	public boolean isUpperLimitEnabled() {
		return false;
	}
	
	/**
	 * Returns the lower limit in meters.
	 * @return double
	 */
	public double getLowerLimit() {
		return 0;
	}
	
	/**
	 * Sets the lower limit in meters.
	 * @param lowerLimit the lower limit in meters; must be greater than or equal to zero
	 * @throws IllegalArgumentException if lowerLimit is less than zero or greater than the current upper limit
	 */
	public void setLowerLimit(double lowerLimit) {
	}

	/**
	 * Sets whether the lower limit is enabled.
	 * @param flag true if the lower limit should be enabled
	 */
	public void setLowerLimitEnabled(boolean flag) {
	}

	/**
	 * Returns true if the lower limit is enabled.
	 * @return boolean true if the lower limit is enabled
	 */
	public boolean isLowerLimitEnabled() {
		return false;
	}
	
	/**
	 * Sets both the lower and upper limits.
	 * @param lowerLimit the lower limit in meters; must be greater than or equal to zero
	 * @param upperLimit the upper limit in meters; must be greater than or equal to zero
	 * @throws IllegalArgumentException if lowerLimit is less than zero, upperLimit is less than zero, or lowerLimit is greater than upperLimit
	 */
	public void setLimits(double lowerLimit, double upperLimit) {
	}

	/**
	 * Sets both the lower and upper limits and enables both.
	 * @param lowerLimit the lower limit in meters; must be greater than or equal to zero
	 * @param upperLimit the upper limit in meters; must be greater than or equal to zero
	 * @throws IllegalArgumentException if lowerLimit is less than zero, upperLimit is less than zero, or lowerLimit is greater than upperLimit
	 */
	public void setLimitsEnabled(double lowerLimit, double upperLimit) {
	}
	
	/**
	 * Enables or disables both the lower and upper limits.
	 * @param flag true if both limits should be enabled
	 */
	public void setLimitsEnabled(boolean flag) {
	}
	
	/**
	 * Sets both the lower and upper limits to the given limit.
	 * <p>
	 * This makes the joint a fixed length joint.
	 * @param limit the desired limit
	 * @throws IllegalArgumentException if limit is less than zero
	 */
	public void setLimits(double limit) {
	}
	
	/**
	 * Sets both the lower and upper limits to the given limit and
	 * enables both.
	 * <p>
	 * This makes the joint a fixed length joint.
	 * @param limit the desired limit
	 * @throws IllegalArgumentException if limit is less than zero
	 */
	public void setLimitsEnabled(double limit) {
	}

	/**
	 * Returns the current state of the limit.
	 * @return {@link LimitState}
	 */
	public LimitState getLimitState() {
		return null;
	}
	

}
