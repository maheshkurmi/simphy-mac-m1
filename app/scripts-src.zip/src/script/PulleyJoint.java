package script;

/**
 * Implementation of a pulley joint.
 * <p>
 * A pulley joint joins two bodies in a pulley system with a fixed length zero
 * mass rope.  The bodies are allowed to rotate freely.  The bodies are allowed
 * to translate freely up to the total length of the "rope."
 * <p>
 * The length of the "rope" connecting the two bodies is computed by distance
 * from the pulley anchors to the body anchors including the ratio (if any)
 * when the joint is created.  The length can be changed dynamically by calling
 * the {@link #setLength(double)} method.
 * <p>
 * The pulley anchor points represent the "hanging" points for the respective 
 * bodies and can be any world space point.
 * <p>
 * This joint can also model a block-and-tackle system by setting the ratio
 * using the {@link #setRatio(double)} method.  A value of 1.0 indicates no
 * ratio.  Values between 0 and 1 exclusive indicate that the first body's
 * rope length will be 1/x times longer than the second body's rope length.
 * Values between 1 and infinity indicate that the second body's rope length
 * will be x times longer than the first body's rope length.
 * <p>
 * By default this joint acts very similar to two {@link DistanceJoint}s in
 * that the bodies are forced to be their respective rope-distance away from 
 * the pulley anchors (i.e. not behaving like a rope).  To have the bodies 
 * behave as if connected by flexible rope pass in <code>true</code> to the 
 * {@link #setSlackEnabled(boolean)} method.
 */
public class PulleyJoint extends Joint {
	
	/**
	 * Returns the pulley anchor point for the first {@link Body}
	 * in world coordinates.
	 * @return {@link Vector2}
	 */
	public Vector2 getPulleyAnchor1() {
		return null;
	}
	
	/**
	 * Returns the pulley anchor point for the second {@link Body}
	 * in world coordinates.
	 * @return {@link Vector2}
	 */
	public Vector2 getPulleyAnchor2() {
		return null;
	}
	
	/**
	 * Returns the total length of the pulley "rope."
	 * @return double
	 * @see #setLength(double)
	 */
	public double getLength() {
		return 0;
	}
	
	/**
	 * Sets the total length of the pulley "rope."
	 * <p>
	 * Typically this is computed when the joint is created by adding the distance from the
	 * first body anchor to the first pulley anchor with the distance from the second body anchor
	 * to the second pulley anchor.
	 * @param length the length
	 */
	public void setLength(double length) {
		
	}
	
	/**
	 * Returns the current length from the first pulley anchor point to the
	 * anchor point on the first {@link Body}.
	 * <p>
	 * This is used, in conjunction with length2, to compute the total length
	 * when the ratio is changed.
	 * @return double
	 */
	public double getLength1() {
		return 0;
	}

	/**
	 * Returns the current length from the second pulley anchor point to the
	 * anchor point on the second {@link Body}.
	 * <p>
	 * This is used, in conjunction with length1, to compute the total length
	 * when the ratio is changed.
	 * @return double
	 */
	public double getLength2() {
		return 0;
	}
	
	/**
	 * Returns the pulley ratio.
	 * @return double
	 */
	public double getRatio() {
		return 0;
	}
	
	/**
	 * Sets the pulley ratio.
	 * <p>
	 * The ratio value is used to simulate a block-and-tackle.  A ratio of 1.0 is the default
	 * and indicates that the pulley is not a block-and-tackle.
	 * <p>
	 * This method recomputes the total length of the pulley system.
	 * @param ratio the ratio; must be greater than zero
	 * @throws IllegalArgumentException if ratio is less than or equal to zero
	 */
	public void setRatio(double ratio) {
		
	}
	
	/**
	 * Returns true if slack in the rope is enabled.
	 * @return boolean
	 */
	public boolean isSlackEnabled() {
		return false;
	}
	
	/**
	 * Toggles the slack in the rope.
	 * <p>
	 * If slack is not enabled the rope length is fixed to the total length of the rope, acting like the {@link DistanceJoint}.
	 * @param flag true to enable slack
	 */
	public void setSlackEnabled(boolean flag) {
		
	}

	/**
	 * Returns the current state of the limit.
	 * @return {@link LimitState}
	 */
	public LimitState getLimitState() {
		return null;
	}
}
