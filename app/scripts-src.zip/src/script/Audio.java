package script;

public class Audio {
	/**
	 * returns name of the Audio
	 * 
	 * @return {String} name of sound
	 */
	public String getName() {
		return null;
	}

	/**
	 * plays sound with full volume and returns
	 * 
	 * @return {Number} sourceId for the sound
	 */

	public long play() {
		return 0;
	};

	/**
	 * plays sound with specified volume
	 * 
	 * @param volume
	 * @return {Number} sourceId for the sound
	 */
	public long play(float volume) {
		return 0;
	};

	/** @return {boolean} whether this audio is playing */
	public boolean isPlaying() {
		return false;
	};

	/**
	 * Pauses the play back. If the music stream has not been started yet or has
	 * finished playing a call to this method will be ignored.
	 */
	public void pause() {
	};

	/**
	 * Resumes sound if previously playing. If the sound is not paused, this has
	 * no effect.
	 */
	public void resume() {
	};

	/**
	 * Stops a playing or paused Music instance. Next time play() is invoked the
	 * Music will start from the beginning.
	 */
	public void stop() {
	};

	/**
	 * Sets whether the music stream is looping. This can be called at any time,
	 * whether the stream is playing.
	 * 
	 * @param isLooping
	 *            whether to loop the stream
	 */
	public void setLooping(boolean isLooping) {
	};

	/** @return {boolean} whether the music stream is playing. */
	public boolean isLooping() {
		return false;
	};

	/**
	 * Sets the volume of this music stream. The volume must be given in the
	 * range [0,1] with 0 being silent and 1 being the maximum volume.
	 * 
	 * @param volume
	 *            {Number}
	 */
	public void setVolume(float volume) {
	};

	/** @return {Number} the volume of this music stream in [0,1]. */
	public float getVolume() {
		return 0;
	};

	/**
	 * Sets the panning and volume of this music stream.
	 * 
	 * @param pan
	 *            panning in the range -1 (full left) to 1 (full right). 0 is
	 *            center position.
	 * @param volume
	 *            the volume in the range [0,1].
	 */
	public void setPan(float pan, float volume) {
	};

	/** Set the playback position in seconds. */
	public void setPosition(float position) {
	};

	/** @return {Number} Returns the playback position in seconds. */
	public float getPosition() {
		return 0;
	};

	/**
	 * Returns the duration in seconds. returns -1 if duration can not be
	 * calculated
	 * 
	 * @return {Number}
	 */
	public float getDuration() {
		return 0;
	};

	/**
	 * Returns size in KB
	 * 
	 * @return {Number}
	 */
	public float getSize() {
		return 0;
	};

	/**
	 * Returns Sample rate/frequency in Hz
	 * 
	 * @return {Number}
	 */
	public int getSampleRate() {
		return 0;
	};

	/** Needs to be called when the audio is no longer needed. */
	public void dispose() {
	};

}
