package script;

import java.util.function.Function;

/**
 * Graph Widget ready to plot variation of one parameter of object or joint with
 * respect to other
 */

public class Grapher {

	/**
	 * pauses/resumes updation of graph, Graph in paused state does't update its
	 * data
	 * 
	 * @param flag
	 */
	public void pause(boolean flag) {
	}

	/**
	 * reinitializes graph panel for the body and starts timer
	 * 
	 * @param body
	 */
	public void reset() {

	}

	/**
	 * Sets the evaluator function used for custom parameter (script1, script2,
	 * script3). The function should have current time (Number) as one and only
	 * argument which is updated every time the function is invoked For example<br>
	 * The following code will plot variation of distance of body from origin with
	 * time
	 * 
	 * <pre>
	 *  function getDistance(body){ 
	 * 	 return body.getPosition().getMagnitude();
	 * }
	 * grapher.setCustomScriptFunction(getDistance, "distance","r","m",0);
	 * grapher.setParams([0],[26]);
	 * </pre>
	 * 
	 * @param evaluatorFunction {Function} function which accepts body as parameter
	 *                          and returns a double value
	 * @param name              {String} Name of parameter displayed in graph
	 * @param symbol            {String} Symbol used for the parameter
	 * @param unit              {String} Unit used for the parameter
	 * @param index             {Integer} index of script parameter to set, can be
	 *                          [0, 1 or 2]
	 */
	public void setCustomScriptFunction(Function<Body, Double> evaluatorFunction, String name, String symbol,
			String unit, int index) {

	}

	/**
	 * returns the object for which graph is being drawn
	 * 
	 * @return associated body or joint
	 */
	public Object getGrpahObject() {
		return null;
	}

	/**
	 * @return type [0=> body, 1=>joint]
	 */
	public int getType() {
		return 0;
	}

	/**
	 * Returns array of integer indices (Position of item starting with 0, in
	 * parameter selection box in Grapher) used for plotting x parameters
	 * 
	 * @return {Array}
	 * @see #setParams(int[], int[])
	 */
	public int[] getParamsY() {
		return null;
	}

	/**
	 * Returns array of integer indices (Position of item starting with 0, in
	 * parameter selection box in Grapher) used for plotting y parameters
	 * 
	 * @return {Array}
	 * @see #setParams(int[], int[])
	 */
	public int[] getParamsX() {
		return null;
	}

	/**
	 * Set the parameters to be plotted
	 * 
	 * @param paramY {Array} array of integer indices to be plotted as x parameter
	 * @param paramX {Array} array of integer indices to be plotted as x parameter
	 *               <br>
	 *               Note: indices are positions of items starting with 0, in
	 *               parameter selection box in Grapher (Note that separators are
	 *               also counted), <br>
	 *               <b>for example </b> 'X Velocity' has index 5 and 'Script1' has
	 *               index 26
	 */
	public void setParams(int[] paramX, int[] paramY) {
	}

	/**
	 * Sets the maximum time span in seconds for which graph plots data
	 * 
	 * @param timeSpan {Number} time in seconds
	 */
	public void setTimeSpan(double timeSpan) {
	}

	/**
	 * Returns the maximum time span in seconds for which graph plots data
	 */
	public double getTimeSpan() {
		return 0;
	}

	/** Returns name of widget */
	public String getName() {
		return null;
	}
	
	/**
	 * Returns if the widget is visible or not
	 * @return
	 */
	public boolean isVisible(){
		return false;
	}
	
	/**
	 * Set the widget to visible or not
	 * @return
	 */
	public void setVisible(boolean visible){
	}
	

}