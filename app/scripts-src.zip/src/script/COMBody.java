package script;


import java.util.List;

/**
 * Body representing centre of mass of  multiple bodies
 * @author mahesh
 *
 */
public class COMBody extends Body{
	/**
	 * Creates an Empty group of bodies
	 */
	private COMBody(){
	}
	

	/**
	 * Adds body to the group
	 * @param body
	 */
	public void addBody(Body body){
	}
	
	/**
	 * Removes body from the group
	 * @param body
	 */
	public void removeBody(Body body){
	}
	
	/**
	 * Calculates com of list of bodies
	 * @param bodies
	 * @return com in world coordinates
	 */
	public  void update(){
	}
	
	@Override
	public void setVelocity(double vx, double vy){
	}
	

	/**
	 * Returns 
	 * @return
	 */
	public List<Body> getBodies(){
		return null;
	}
	

	/* (non-Javadoc)
	 * @see org.dyn4j.collision.Collidable#contains(org.dyn4j.geometry.Vector2)
	 */
	public boolean contains(Vector2 point) {
		return false;
	}
	
	/**
	 * returns true if group contains the body
	 * @param b
	 * @return
	 */
	public boolean containsBody(Body b) {
		return false;
	}
	
	/**
	 * returns true if atleast one of body is dynamic
	 */
	public boolean isDynamic(){
		return false;
	}
	

	/**
	 * returns true if all bodies are static
	 */
	public boolean isStatic(){
		return false;
	}
	

}
