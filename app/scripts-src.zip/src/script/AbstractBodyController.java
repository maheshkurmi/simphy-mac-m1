package script;


/**
 * Class to control body on each update
 * It can have expressions for each component x and y in terms of 
 * instantaneous variables related to body
 * @author mahesh
 *
 */
public abstract class AbstractBodyController {
    
    /**
     * returns true if the controller is enabled
     * @return {boolean}
     */
    public boolean isEnabled() {
		return false;
	}

    /**
     * Sets controller enabled or disabled
     * A disable controlller does't affect body
     * @param enabled {boolean}
     */
	public void setEnabled(boolean enabled) {
		
	}

	/**
	 * returns true of controller is rendered (Ex. Force Controller is dispalyed as a vector if visible)
	 * @return {boolean}
	 */
	public boolean isVisible() {
		return false;
	}
			
	/**
	 * Sets controller visible. Note that an invisible controller still affects bodies motion
	 * @param visible {boolean}
	 * @see #setEnabled(boolean)
	 */
	public void setVisible(boolean visible) {
		
	}


	/**
	 * returns name/identifier of the controller
	 * @return {String}
	 */
	public String getName(){
		return "";
	}

	/**
	 * Sets name of the controller, ame is used as identifier for controller in script
	 * @param name {String}
	 */
	public void setName(String name){
		
	}
	
	

	/**
	 * returns body to which force is associated
	 * @return {Body} 
	 */
	public Body getBody() {
		return null;
	}

	/**
	 * Returns expression for x component of controller 
	 * @return {String}
	 */
	public String getxExpr() {
		return "";
	}
	
	/**
	 * Returns expression for x component of controller 
	 * @return {String}
	 */
	public String getyExpr() {
		return "";
	}

	
	/**
	 * Sets the body to which force is applied
	 * 
	 * @param body {Body} 
	 */
	public void setBody(Body body) {
		
	}

	/**
	 * Set expressions for each component
	 * 
	 * @param xExpr {String} expression for x component , pass null or empty string if x component always remains zero
	 * @param yExpr {String} expression for x component , pass null or empty string if y component always remains zero
	 */
	public void setExpressions(String xExpr,String yExpr){
		
	}
	

	/**
	 * returns true if expression set is parsable
	 * @return {boolean}
	 */
	public final boolean isValidExpr() {
		return false;
	}

	/**
	 * returns current expression string
	 * @return {String}
	 */
	public  String getExpressionString() {
		return "";
	}
	
	/**
	 * returns instantaneous value 
	 * @return {Vector2}
	 */
	public Vector2 getInstantValue(){
		return null;
	}

	/**
	 * returns SI unit string for the controller
	 * @return {String}
	 */
	public abstract String getUnit();

	/**
	 * Returns error in expression if any
	 * @return {String}
	 */
	public String getParseErrorMessage() {
		return "";
	}

}
