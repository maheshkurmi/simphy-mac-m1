package script;

/**
 * Represents a self adjustable distance joint, two bodies are connected by thread which is wounded over each body
 * around centre of mass. used to create real pulley system
 * <p>
 * Given the two world space anchor points, the {@link Body}s are not allowed to 
 * slip over the the thread connecting them.
 * <p>
 */
public class SpindleJoint extends Joint {
	/**
	 * Returns the upper limit in meters.
	 * @return double
	 */
	public double getUpperLimit() {
		return 0;
	}
	
	/**
	 * Returns the radius of spindle of first body in meters.
	 * @return double
	 */
	public double getRadius1() {
		return 0;
	}
	
	/**
	 * Returns the radius of spindle of second body in meters.
	 * @return double
	 */
	public double getRadius2() {
		return 0;
	}
	/**
	 * Sets the upper limit in meters.
	 * @param upperLimit the upper limit in meters; must be greater than or equal to zero
	 * @throws IllegalArgumentException if upperLimit is less than zero or less than the current lower limit
	 */
	public void setUpperLimit(double upperLimit) {
	}
	
	/**
	 * Sets whether the upper limit is enabled.
	 * @param flag true if the upper limit should be enabled
	 */
	public void setUpperLimitEnabled(boolean flag) {
	}
	
	/**
	 * Returns true if the upper limit is enabled.
	 * @return boolean true if the upper limit is enabled
	 */
	public boolean isUpperLimitEnabled() {
		return false;
	}
	
	/**
	 * Returns the lower limit in meters.
	 * @return double
	 */
	public double getLowerLimit() {
		return 0;
	}
	
	/**
	 * Sets the lower limit in meters.
	 * @param lowerLimit the lower limit in meters; must be greater than or equal to zero
	 * @throws IllegalArgumentException if lowerLimit is less than zero or greater than the current upper limit
	 */
	public void setLowerLimit(double lowerLimit) {
	}

	/**
	 * Sets whether the lower limit is enabled.
	 * @param flag true if the lower limit should be enabled
	 */
	public void setLowerLimitEnabled(boolean flag) {
	}

	/**
	 * Returns true if the lower limit is enabled.
	 * @return boolean true if the lower limit is enabled
	 */
	public boolean isLowerLimitEnabled() {
		return false;
	}
	
	/**
	 * Sets both the lower and upper limits.
	 * @param lowerLimit the lower limit in meters; must be greater than or equal to zero
	 * @param upperLimit the upper limit in meters; must be greater than or equal to zero
	 * @throws IllegalArgumentException if lowerLimit is less than zero, upperLimit is less than zero, or lowerLimit is greater than upperLimit
	 */
	public void setLimits(double lowerLimit, double upperLimit) {
	}

	/**
	 * Sets both the lower and upper limits and enables both.
	 * @param lowerLimit the lower limit in meters; must be greater than or equal to zero
	 * @param upperLimit the upper limit in meters; must be greater than or equal to zero
	 * @throws IllegalArgumentException if lowerLimit is less than zero, upperLimit is less than zero, or lowerLimit is greater than upperLimit
	 */
	public void setLimitsEnabled(double lowerLimit, double upperLimit) {
	}
	
	/**
	 * Enables or disables both the lower and upper limits.
	 * @param flag true if both limits should be enabled
	 */
	public void setLimitsEnabled(boolean flag) {
	}
	
	/**
	 * Sets both the lower and upper limits to the given limit.
	 * <p>
	 * This makes the joint a fixed length joint.
	 * @param limit the desired limit
	 * @throws IllegalArgumentException if limit is less than zero
	 */
	public void setLimits(double limit) {
	}
	
	/**
	 * Sets both the lower and upper limits to the given limit and
	 * enables both.
	 * <p>
	 * This makes the joint a fixed length joint.
	 * @param limit the desired limit
	 * @throws IllegalArgumentException if limit is less than zero
	 */
	public void setLimitsEnabled(double limit) {
		// enable the limits
	}

	
	
}
